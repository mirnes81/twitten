# Twitten – évolution autonomie supervisée

## Ajouts
- Moteur de règles intelligent `AutomationEngine`.
- Détection automatique : factures échues, devis sans réponse, projets en retard, grosses factures ouvertes.
- File de décisions persistante avec anti-doublon.
- Niveaux de risque et validation humaine.
- Actions faibles auto-approuvées, actions moyennes/fortes bloquées jusqu'à validation.
- Journal des analyses, validations et exécutions.
- Interface complète `automation-center.php`.
- Centre IA désormais alimenté par les données Dolibarr.

## Sécurité
Le système est volontairement en **autonomie supervisée**. Il ne modifie pas directement un statut sensible ou n'envoie pas un e-mail sans passer par les protections existantes du bridge.

## Prochaine architecture recommandée
1. Connecteur n8n signé (HMAC) pour les e-mails et notifications.
2. Gestion des permissions par utilisateur Dolibarr.
3. Exécution idempotente des actions Dolibarr via API native.
4. Apprentissage à partir des validations/refus, sans entraîner un modèle sur des données sensibles.
5. Planificateur CRON toutes les heures.
