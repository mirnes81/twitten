# Twitten – Cockpit devis V3

Cette version transforme la fiche devis en cockpit opérationnel connecté aux données Dolibarr.

## Fonctions intégrées

- En-tête complet : client, références, dates, validité, livraison, projet, règlement, disponibilité, origine.
- Lecture et modification des notes publique et privée.
- Chargement automatique des extrafields du devis et sauvegarde de leurs valeurs.
- Tableau de lignes moderne avec ajout, modification, duplication, suppression et déplacement.
- Totaux HT, TVA et TTC.
- Validation, acceptation, refus et réouverture selon le statut.
- Génération PDF avec le modèle configuré dans Dolibarr.
- Liste des PDF et fichiers déjà générés.
- Commandes et factures liées au devis.
- Contacts et activités Dolibarr liés à la proposition.
- Notes et tâches depuis Twitten.
- Accès direct aux fiches Dolibarr du devis, client, projet, commande et facture.

## Installation

1. Copier `twittenbridge` dans `htdocs/custom/` de Dolibarr.
2. Remplacer les fichiers du site Twitten par le contenu de `public_html`.
3. Conserver la clé Bridge déjà configurée.
4. Ouvrir `object.php?type=propal&id=ID_DOLIBARR`.

## Sécurité et compatibilité

Les opérations métiers principales utilisent les classes Dolibarr lorsque cela est nécessaire. Les mises à jour de métadonnées et d’extrafields utilisent les tables Dolibarr avec contrôle des colonnes disponibles, afin de rester tolérantes aux différences de configuration.

Avant la production, effectuer une sauvegarde de la base et tester sur un devis brouillon.
