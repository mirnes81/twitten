<?php
include_once DOL_DOCUMENT_ROOT.'/core/modules/DolibarrModules.class.php';
class modTwittenBridge extends DolibarrModules
{
    public function __construct($db)
    {
        global $langs,$conf;
        $this->db=$db;
        $this->numero=502340;
        $this->rights_class='twittenbridge';
        $this->family='interface';
        $this->module_position=500;
        $this->name=preg_replace('/^mod/i','',get_class($this));
        $this->description='Bridge API sécurisé pour connecter Twitten à Dolibarr';
        $this->version='2.0';
        $this->const_name='MAIN_MODULE_'.strtoupper($this->name);
        $this->picto='generic';
        $this->config_page_url=array('setup.php@twittenbridge');
        $this->depends=array();
        $this->requiredby=array();
        $this->phpmin=array(7,4);
        $this->need_dolibarr_version=array(15,0);
        $this->langfiles=array('twittenbridge@twittenbridge');
        $this->dirs=array();
    }
}
