<?php
$res = 0;
if (!$res && file_exists("../../../main.inc.php")) $res = @include "../../../main.inc.php";
if (!$res && file_exists("../../../../main.inc.php")) $res = @include "../../../../main.inc.php";
if (!$res) die('main.inc.php introuvable');

$langs->load('admin');
llxHeader('', 'Twitten Bridge');

if (!$user->admin) accessforbidden();

$action = GETPOST('action', 'alpha');
if ($action === 'generate') {
    $key = 'TWB_' . bin2hex(random_bytes(18));
    dolibarr_set_const($db, 'TWITTENBRIDGE_API_KEY', $key, 'chaine', 0, '', $conf->entity);
    setEventMessages('Clé API générée.', null, 'mesgs');
}
if ($action === 'save') {
    $key = GETPOST('api_key', 'restricthtml');
    dolibarr_set_const($db, 'TWITTENBRIDGE_API_KEY', $key, 'chaine', 0, '', $conf->entity);
    setEventMessages('Configuration enregistrée.', null, 'mesgs');
}

$key = !empty($conf->global->TWITTENBRIDGE_API_KEY) ? $conf->global->TWITTENBRIDGE_API_KEY : '';
$apiUrl = DOL_MAIN_URL_ROOT . '/custom/twittenbridge/api/api.php';
print '<div class="fichecenter"><div class="underbanner clearboth"></div>';
print '<h1>Twitten Bridge V3</h1>';
print '<p>Bridge API pour connecter Twitten à Dolibarr.</p>';
print '<form method="post">';
print '<input type="hidden" name="token" value="'.newToken().'">';
print '<input type="hidden" name="action" value="save">';
print '<table class="noborder centpercent">';
print '<tr class="liste_titre"><td>Paramètre</td><td>Valeur</td></tr>';
print '<tr><td>URL API</td><td><input style="width:70%" readonly value="'.dol_escape_htmltag($apiUrl).'"></td></tr>';
print '<tr><td>Clé API</td><td><input style="width:70%" name="api_key" value="'.dol_escape_htmltag($key).'"></td></tr>';
print '</table><br>';
print '<input class="button button-save" type="submit" value="Enregistrer"> ';
print '<a class="button" href="?action=generate&token='.newToken().'">Générer une nouvelle clé</a>';
if ($key) {
    print '<br><br><strong>Test ping :</strong><br><a target="_blank" href="'.dol_escape_htmltag($apiUrl.'?action=ping&key='.urlencode($key)).'">'.dol_escape_htmltag($apiUrl.'?action=ping&key='.$key).'</a>';
    print '<br><br><strong>Test dashboard :</strong><br><a target="_blank" href="'.dol_escape_htmltag($apiUrl.'?action=dashboard&key='.urlencode($key)).'">'.dol_escape_htmltag($apiUrl.'?action=dashboard&key='.$key).'</a>';
}
print '</form></div>';
llxFooter();
$db->close();
