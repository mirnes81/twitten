<?php
// Compatibilité ancienne URL: /custom/twittenbridge/api.php
// Le vrai bridge moderne est dans /custom/twittenbridge/api/api.php
require __DIR__ . '/api/api.php';
