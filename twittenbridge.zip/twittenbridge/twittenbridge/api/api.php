<?php
// Twitten Bridge V10 - API Dolibarr JSON only
// Install in htdocs/custom/twittenbridge/api/api.php
if (!defined('NOLOGIN')) define('NOLOGIN', 1);
if (!defined('NOCSRFCHECK')) define('NOCSRFCHECK', 1);
if (!defined('NOREQUIREMENU')) define('NOREQUIREMENU', 1);
if (!defined('NOREQUIREHTML')) define('NOREQUIREHTML', 1);
if (!defined('NOREQUIREAJAX')) define('NOREQUIREAJAX', 1);
if (!defined('NOTOKENRENEWAL')) define('NOTOKENRENEWAL', 1);

$main = __DIR__ . '/../../../main.inc.php';
if (!file_exists($main)) $main = __DIR__ . '/../../../../htdocs/main.inc.php';
if (!file_exists($main)) {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['ok'=>false,'error'=>'main.inc.php introuvable']); exit;
}
require_once $main;

header('Content-Type: application/json; charset=utf-8');

function tw_json($arr, $code=200){ http_response_code($code); echo json_encode($arr, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); exit; }
function tw_key_ok(){
    global $conf;
    $k = GETPOST('key','alphanohtml');
    $expected = !empty($conf->global->TWITTENBRIDGE_API_KEY) ? $conf->global->TWITTENBRIDGE_API_KEY : 'TWB_df6d55963d5c6b4ba2c7c67dfac86a30d9b4';
    return $k && hash_equals((string)$expected, (string)$k);
}
if (!tw_key_ok()) tw_json(['ok'=>false,'error'=>'Clé API invalide'], 403);

$action = GETPOST('action','aZ09');

function qcount($table, $where='1=1') { global $db; $sql='SELECT COUNT(*) as c FROM '.MAIN_DB_PREFIX.$table.' WHERE '.$where; $res=$db->query($sql); if(!$res) return 0; $o=$db->fetch_object($res); return (int)$o->c; }
function fetch_all($sql){ global $db; $out=[]; $res=$db->query($sql); if(!$res) tw_json(['ok'=>false,'error'=>$db->lasterror(),'sql'=>$sql],500); while($o=$db->fetch_object($res)) $out[]=(array)$o; return $out; }
function entity_where($alias=''){ global $conf; $p=$alias?$alias.'.':''; return $p.'entity IN ('.getEntity('',1).')'; }

if ($action==='ping') tw_json(['ok'=>true,'bridge'=>'twittenbridge','version'=>'10.0','dolibarr_version'=>DOL_VERSION,'time'=>dol_print_date(dol_now(),'dayhourrfc')]);

if ($action==='dashboard') {
    tw_json(['ok'=>true,'data'=>[
        'counts'=>[
            'clients'=>qcount('societe','client IN (1,2,3) AND '.entity_where()),
            'prospects'=>qcount('societe','client IN (2,3) AND '.entity_where()),
            'invoices'=>qcount('facture',entity_where()),
            'unpaid_invoices'=>qcount('facture','paye=0 AND fk_statut > 0 AND '.entity_where()),
            'propals'=>qcount('propal',entity_where()),
            'orders'=>qcount('commande',entity_where()),
            'products'=>qcount('product',entity_where()),
            'projects'=>qcount('projet',entity_where())
        ],
        'latest_clients'=>fetch_all('SELECT rowid, nom as name, code_client, email, town FROM '.MAIN_DB_PREFIX.'societe WHERE client IN (1,2,3) AND '.entity_where().' ORDER BY rowid DESC LIMIT 8'),
        'latest_invoices'=>fetch_all('SELECT rowid, ref, total_ttc, paye, datef FROM '.MAIN_DB_PREFIX.'facture WHERE '.entity_where().' ORDER BY rowid DESC LIMIT 8'),
        'latest_propals'=>fetch_all('SELECT rowid, ref, total_ttc, fk_statut as status, datep FROM '.MAIN_DB_PREFIX.'propal WHERE '.entity_where().' ORDER BY rowid DESC LIMIT 8')
    ]]);
}


// ================= TWITTEN PROPAL COCKPIT V3 =================
function tw_pc_table_exists($table){ global $db; $r=$db->query("SHOW TABLES LIKE '".$db->escape(MAIN_DB_PREFIX.$table)."'"); return $r && $db->num_rows($r)>0; }
function tw_pc_columns($table){ static $cache=[]; global $db; if(isset($cache[$table])) return $cache[$table]; $cache[$table]=[]; $r=$db->query('SHOW COLUMNS FROM '.MAIN_DB_PREFIX.$table); if($r){ while($o=$db->fetch_object($r)) $cache[$table][$o->Field]=true; } return $cache[$table]; }
function tw_pc_column($table,$candidates){ $cols=tw_pc_columns($table); foreach((array)$candidates as $candidate){ if(isset($cols[$candidate])) return $candidate; } return ''; }
function tw_pc_select_fields($alias,$table,$fields){ $cols=tw_pc_columns($table); $out=[]; foreach($fields as $f=>$as){ if(isset($cols[$f])) $out[]=$alias.'.'.$f.' AS '.$as; } return $out; }
function tw_pc_date($v){ if(!$v) return null; if(is_numeric($v)) return date('Y-m-d',(int)$v); return substr((string)$v,0,10); }
function tw_pc_status($s){ $map=[0=>['code'=>'draft','label'=>'Brouillon','class'=>'secondary'],1=>['code'=>'validated','label'=>'Validé / ouvert','class'=>'primary'],2=>['code'=>'signed','label'=>'Signé / accepté','class'=>'success'],3=>['code'=>'refused','label'=>'Refusé','class'=>'danger'],4=>['code'=>'billed','label'=>'Facturé','class'=>'info']]; return $map[(int)$s]??['code'=>'unknown','label'=>'Statut '.(int)$s,'class'=>'dark']; }
function tw_pc_document_url($modulepart,$file){ return dol_buildpath('/document.php?modulepart='.$modulepart.'&file='.urlencode($file),2); }

if ($action==='propal_cockpit') {
    global $db,$conf;
    $id=(int)GETPOST('id','int'); if(!$id) tw_json(['ok'=>false,'error'=>'ID du devis manquant'],400);
    $fields=tw_pc_select_fields('p','propal',[
        'rowid'=>'id','ref'=>'ref','ref_client'=>'ref_client','fk_soc'=>'fk_soc','fk_projet'=>'fk_project','fk_statut'=>'status',
        'datec'=>'date_creation','datep'=>'date_propal','fin_validite'=>'date_validity','date_livraison'=>'date_delivery',
        'total_ht'=>'total_ht','total_tva'=>'total_tva','total_ttc'=>'total_ttc','remise'=>'discount_amount','remise_percent'=>'discount_percent',
        'note_public'=>'note_public','note_private'=>'note_private','model_pdf'=>'model_pdf','multicurrency_code'=>'currency',
        'multicurrency_total_ht'=>'currency_total_ht','multicurrency_total_ttc'=>'currency_total_ttc','fk_cond_reglement'=>'fk_payment_term',
        'fk_mode_reglement'=>'fk_payment_mode','fk_availability'=>'fk_availability','fk_input_reason'=>'fk_input_reason','source'=>'source'
    ]);
    $projectCol=tw_pc_column('propal',['fk_projet','fk_project']);
    $projectJoin=$projectCol ? ' LEFT JOIN '.MAIN_DB_PREFIX.'projet pj ON pj.rowid=p.'.$projectCol : ' LEFT JOIN '.MAIN_DB_PREFIX.'projet pj ON 1=0';
    $sql='SELECT '.implode(',',$fields).',s.nom AS thirdparty,s.email,s.phone,s.address,s.zip,s.town,s.code_client,pj.ref AS project_ref,pj.title AS project_title'
        .' FROM '.MAIN_DB_PREFIX.'propal p LEFT JOIN '.MAIN_DB_PREFIX.'societe s ON s.rowid=p.fk_soc'.$projectJoin
        .' WHERE p.rowid='.$id.' AND '.entity_where('p').' LIMIT 1';
    $rows=fetch_all($sql); if(!$rows) tw_json(['ok'=>false,'error'=>'Devis introuvable'],404); $doc=$rows[0];
    foreach(['date_creation','date_propal','date_validity','date_delivery'] as $k) if(isset($doc[$k])) $doc[$k]=tw_pc_date($doc[$k]);
    $doc['status_info']=tw_pc_status($doc['status']??0);
    $doc['dolibarr_url']=dol_buildpath('/comm/propal/card.php?id='.$id,2);
    $doc['thirdparty_url']=!empty($doc['fk_soc'])?dol_buildpath('/societe/card.php?socid='.(int)$doc['fk_soc'],2):'';
    $doc['project_url']=!empty($doc['fk_project'])?dol_buildpath('/projet/card.php?id='.(int)$doc['fk_project'],2):'';

    $lines=fetch_all('SELECT l.rowid,l.fk_product,l.description,l.qty,l.subprice,l.remise_percent,l.tva_tx,l.total_ht,l.total_tva,l.total_ttc,l.product_type,l.rang,pr.ref AS product_ref,pr.label AS product_label'
        .' FROM '.MAIN_DB_PREFIX.'propaldet l LEFT JOIN '.MAIN_DB_PREFIX.'product pr ON pr.rowid=l.fk_product WHERE l.fk_propal='.$id.' ORDER BY l.rang,l.rowid');

    $extraDefs=[]; $extraValues=[];
    if(tw_pc_table_exists('extrafields')){
        $extraDefs=fetch_all("SELECT name,label,type,param,required,pos,enabled,default_value FROM ".MAIN_DB_PREFIX."extrafields WHERE elementtype='propal' ORDER BY pos,rowid");
    }
    if(tw_pc_table_exists('propal_extrafields')){
        $ev=fetch_all('SELECT * FROM '.MAIN_DB_PREFIX.'propal_extrafields WHERE fk_object='.$id.' LIMIT 1'); $extraValues=$ev?$ev[0]:[];
    }
    $extrafields=[]; foreach($extraDefs as $def){ $name=$def['name']; $extrafields[]=['name'=>$name,'label'=>$def['label']?:$name,'type'=>$def['type']?:'varchar','required'=>(int)$def['required'],'value'=>$extraValues[$name]??'']; }
    if(!$extraDefs){ foreach($extraValues as $k=>$v){ if(!in_array($k,['rowid','tms','fk_object','import_key'],true)) $extrafields[]=['name'=>$k,'label'=>$k,'type'=>'varchar','required'=>0,'value'=>$v]; } }

    $contacts=[];
    if(tw_pc_table_exists('element_contact')){
        $contacts=fetch_all("SELECT ec.rowid,sp.rowid AS contact_id,sp.lastname,sp.firstname,sp.email,sp.phone,ct.libelle AS role FROM ".MAIN_DB_PREFIX."element_contact ec LEFT JOIN ".MAIN_DB_PREFIX."socpeople sp ON sp.rowid=ec.fk_socpeople LEFT JOIN ".MAIN_DB_PREFIX."c_type_contact ct ON ct.rowid=ec.fk_c_type_contact WHERE ec.element_id=$id AND ct.element='propal' ORDER BY ct.libelle,sp.lastname");
    }
    $events=[];
    if(tw_pc_table_exists('actioncomm')){
        $events=fetch_all("SELECT rowid,label,note_private,note_public,datec,datep,datef,percent FROM ".MAIN_DB_PREFIX."actioncomm WHERE fk_element=$id AND elementtype IN ('propal','proposal') ORDER BY rowid DESC LIMIT 30");
    }

    $linked=['orders'=>[],'invoices'=>[]];
    if(tw_pc_table_exists('element_element')){
        $links=fetch_all("SELECT rowid,fk_source,sourcetype,fk_target,targettype FROM ".MAIN_DB_PREFIX."element_element WHERE (fk_source=$id AND sourcetype='propal') OR (fk_target=$id AND targettype='propal') ORDER BY rowid DESC");
        foreach($links as $ln){
            $otype=''; $oid=0;
            if($ln['sourcetype']==='propal'){ $otype=$ln['targettype']; $oid=(int)$ln['fk_target']; } else { $otype=$ln['sourcetype']; $oid=(int)$ln['fk_source']; }
            if(in_array($otype,['commande','order'],true)){ $r=fetch_all('SELECT rowid AS id,ref,total_ttc,fk_statut AS status,date_commande AS date_doc FROM '.MAIN_DB_PREFIX.'commande WHERE rowid='.$oid.' LIMIT 1'); if($r){$r[0]['url']=dol_buildpath('/commande/card.php?id='.$oid,2);$linked['orders'][]=$r[0];} }
            if(in_array($otype,['facture','invoice'],true)){ $r=fetch_all('SELECT rowid AS id,ref,total_ttc,fk_statut AS status,paye,datef AS date_doc FROM '.MAIN_DB_PREFIX.'facture WHERE rowid='.$oid.' LIMIT 1'); if($r){$r[0]['url']=dol_buildpath('/compta/facture/card.php?facid='.$oid,2);$linked['invoices'][]=$r[0];} }
        }
    }
    // Compatibilité supplémentaire: documents issus de ce devis par origine.
    foreach([['commande','orders','/commande/card.php?id='],['facture','invoices','/compta/facture/card.php?facid=']] as $m){
        [$tb,$key,$path]=$m; $cols=tw_pc_columns($tb); if(isset($cols['fk_origin'])&&isset($cols['origin'])){
            $rs=fetch_all("SELECT rowid AS id,ref,total_ttc,fk_statut AS status FROM ".MAIN_DB_PREFIX.$tb." WHERE fk_origin=$id AND origin='propal' ORDER BY rowid DESC");
            foreach($rs as $r){ $r['url']=dol_buildpath($path.(int)$r['id'],2); $linked[$key][]=$r; }
        }
    }
    foreach($linked as $k=>$arr){ $seen=[];$clean=[];foreach($arr as $r){if(isset($seen[$r['id']]))continue;$seen[$r['id']]=1;$clean[]=$r;}$linked[$k]=$clean; }

    $documents=[]; $root='';
    if(!empty($conf->propal->multidir_output[$conf->entity])) $root=$conf->propal->multidir_output[$conf->entity]; elseif(!empty($conf->propal->dir_output)) $root=$conf->propal->dir_output;
    $dir=rtrim((string)$root,'/').'/'.dol_sanitizeFileName($doc['ref']);
    if($root && is_dir($dir)){
        foreach(scandir($dir)?:[] as $f){ if($f==='.'||$f==='..'||is_dir($dir.'/'.$f))continue; $documents[]=['name'=>$f,'size'=>filesize($dir.'/'.$f),'modified'=>date('c',filemtime($dir.'/'.$f)),'url'=>tw_pc_document_url('propal',$doc['ref'].'/'.$f)]; }
        usort($documents,fn($a,$b)=>strcmp($b['modified'],$a['modified']));
    }

    $settings=[
        'payment_terms'=>tw_pc_table_exists('c_payment_term')?fetch_all('SELECT rowid AS id,libelle AS label,code FROM '.MAIN_DB_PREFIX.'c_payment_term WHERE active=1 ORDER BY sortorder,rowid'):[],
        'payment_modes'=>tw_pc_table_exists('c_paiement')?fetch_all('SELECT id,libelle AS label,code FROM '.MAIN_DB_PREFIX.'c_paiement WHERE active=1 ORDER BY libelle'):[],
        'availability'=>tw_pc_table_exists('c_availability')?fetch_all('SELECT rowid AS id,label,code FROM '.MAIN_DB_PREFIX.'c_availability WHERE active=1 ORDER BY position,rowid'):[],
        'input_reasons'=>tw_pc_table_exists('c_input_reason')?fetch_all('SELECT rowid AS id,label,code FROM '.MAIN_DB_PREFIX.'c_input_reason WHERE active=1 ORDER BY rang,rowid'):[],
    ];
    tw_json(['ok'=>true,'doc'=>$doc,'lines'=>$lines,'extrafields'=>$extrafields,'contacts'=>$contacts,'events'=>$events,'linked'=>$linked,'documents'=>$documents,'settings'=>$settings]);
}

if ($action==='propal_update_header') {
    global $db; $id=(int)GETPOST('id','int'); if(!$id) tw_json(['ok'=>false,'error'=>'ID manquant'],400);
    $cols=tw_pc_columns('propal'); $map=['ref_client'=>'ref_client','date_propal'=>'datep','date_validity'=>'fin_validite','date_delivery'=>'date_livraison','fk_projet'=>'fk_project','fk_payment_term'=>'fk_cond_reglement','fk_payment_mode'=>'fk_mode_reglement','fk_availability'=>'fk_availability','fk_input_reason'=>'fk_input_reason','note_public'=>'note_public','note_private'=>'note_private'];
    $set=[]; foreach($map as $in=>$col){ if(!$col || !isset($cols[$col]) || !array_key_exists($in,$_POST)) continue; $v=$_POST[$in]; if(in_array($in,['fk_project','fk_payment_term','fk_payment_mode','fk_availability','fk_input_reason'],true)) $set[]=$col.'='.(($v===''||$v==='0')?'NULL':(int)$v); elseif(str_starts_with($in,'date_')) $set[]=$col.'='.($v===''?'NULL':"'".$db->escape($v)."'"); else $set[]=$col."='".$db->escape((string)$v)."'"; }
    if($set){ $db->begin(); $r=$db->query('UPDATE '.MAIN_DB_PREFIX.'propal SET '.implode(',',$set).' WHERE rowid='.$id.' AND '.entity_where()); if(!$r){$db->rollback();tw_json(['ok'=>false,'error'=>$db->lasterror()],500);} $db->commit(); }
    tw_json(['ok'=>true,'message'=>'Informations du devis enregistrées']);
}

if ($action==='propal_update_extrafields') {
    global $db; $id=(int)GETPOST('id','int'); if(!$id) tw_json(['ok'=>false,'error'=>'ID manquant'],400); if(!tw_pc_table_exists('propal_extrafields')) tw_json(['ok'=>false,'error'=>'Table des extrafields absente'],400);
    $cols=tw_pc_columns('propal_extrafields'); $values=[]; foreach($_POST as $k=>$v){ if(strpos($k,'ef_')!==0)continue; $name=substr($k,3); if(isset($cols[$name])) $values[$name]=$v; }
    $exists=fetch_all('SELECT rowid FROM '.MAIN_DB_PREFIX.'propal_extrafields WHERE fk_object='.$id.' LIMIT 1');
    if($exists){ $set=[];foreach($values as $k=>$v)$set[]=$k.'='.(($v==='')?'NULL':"'".$db->escape((string)$v)."'"); if($set&&!$db->query('UPDATE '.MAIN_DB_PREFIX.'propal_extrafields SET '.implode(',',$set).' WHERE fk_object='.$id))tw_json(['ok'=>false,'error'=>$db->lasterror()],500); }
    else { $names=['fk_object'];$vals=[$id];foreach($values as $k=>$v){$names[]=$k;$vals[]=($v==='')?'NULL':"'".$db->escape((string)$v)."'";} if(!$db->query('INSERT INTO '.MAIN_DB_PREFIX.'propal_extrafields ('.implode(',',$names).') VALUES ('.implode(',',$vals).')'))tw_json(['ok'=>false,'error'=>$db->lasterror()],500); }
    tw_json(['ok'=>true,'message'=>'Champs complémentaires enregistrés']);
}

if ($action==='propal_line_move') {
    global $db; $id=(int)GETPOST('id','int');$lineid=(int)GETPOST('lineid','int');$direction=GETPOST('direction','alpha'); if(!$id||!$lineid||!in_array($direction,['up','down'],true))tw_json(['ok'=>false,'error'=>'Paramètres invalides'],400);
    $lines=fetch_all('SELECT rowid,rang FROM '.MAIN_DB_PREFIX.'propaldet WHERE fk_propal='.$id.' ORDER BY rang,rowid'); $idx=null;foreach($lines as $i=>$l)if((int)$l['rowid']===$lineid){$idx=$i;break;} if($idx===null)tw_json(['ok'=>false,'error'=>'Ligne introuvable'],404); $target=$direction==='up'?$idx-1:$idx+1; if(!isset($lines[$target]))tw_json(['ok'=>true,'message'=>'Ligne déjà en limite']);
    $db->begin(); $a=$lines[$idx];$b=$lines[$target];$ra=(int)$a['rang'];$rb=(int)$b['rang']; if($ra===$rb){$ra=$idx+1;$rb=$target+1;} $ok=$db->query('UPDATE '.MAIN_DB_PREFIX.'propaldet SET rang='.$rb.' WHERE rowid='.(int)$a['rowid'])&&$db->query('UPDATE '.MAIN_DB_PREFIX.'propaldet SET rang='.$ra.' WHERE rowid='.(int)$b['rowid']); if(!$ok){$db->rollback();tw_json(['ok'=>false,'error'=>$db->lasterror()],500);} $db->commit(); tw_json(['ok'=>true,'message'=>'Ligne déplacée']);
}

if ($action==='propal_line_duplicate') {
    global $db,$user; $id=(int)GETPOST('id','int');$lineid=(int)GETPOST('lineid','int'); if(!$id||!$lineid)tw_json(['ok'=>false,'error'=>'Paramètres manquants'],400);
    require_once DOL_DOCUMENT_ROOT.'/comm/propal/class/propal.class.php'; $obj=new Propal($db);if($obj->fetch($id)<=0)tw_json(['ok'=>false,'error'=>'Devis introuvable'],404);$src=fetch_all('SELECT * FROM '.MAIN_DB_PREFIX.'propaldet WHERE rowid='.$lineid.' AND fk_propal='.$id.' LIMIT 1');if(!$src)tw_json(['ok'=>false,'error'=>'Ligne introuvable'],404);$l=$src[0];
    $res=$obj->addline($l['description'],(float)$l['subprice'],(float)$l['qty'],(float)$l['tva_tx'],0,0,(int)$l['fk_product'],(float)$l['remise_percent'],'HT'); if($res<0)tw_json(['ok'=>false,'error'=>$obj->error,'errors'=>$obj->errors],500);tw_json(['ok'=>true,'message'=>'Ligne dupliquée','lineid'=>$res]);
}

if ($action==='propal_status_action') {
    global $db,$user; $id=(int)GETPOST('id','int');$operation=GETPOST('operation','alpha');$note=GETPOST('note','restricthtml');if(!$id)tw_json(['ok'=>false,'error'=>'ID manquant'],400);
    require_once DOL_DOCUMENT_ROOT.'/comm/propal/class/propal.class.php';$obj=new Propal($db);if($obj->fetch($id)<=0)tw_json(['ok'=>false,'error'=>'Devis introuvable'],404);$res=-1;
    if($operation==='validate')$res=$obj->validate($user);
    elseif($operation==='reopen' && method_exists($obj,'reopen'))$res=$obj->reopen($user,1);
    elseif(in_array($operation,['accept','refuse'],true) && method_exists($obj,'closeProposal'))$res=$obj->closeProposal($user,$operation==='accept'?2:3,$note);
    else tw_json(['ok'=>false,'error'=>'Action de statut indisponible ou inconnue'],400);
    if($res<0)tw_json(['ok'=>false,'error'=>$obj->error?:'Échec du changement de statut','errors'=>$obj->errors],500);tw_json(['ok'=>true,'message'=>'Statut du devis mis à jour']);
}
// ================= FIN PROPAL COCKPIT V3 =================


if ($action==='propal_detail' || $action==='invoice_detail') {
    $id=(int)GETPOST('id','int'); if(!$id) tw_json(['ok'=>false,'error'=>'id manquant'],400);
    $isProp=$action==='propal_detail';
    $table=$isProp?'propal':'facture'; $line=$isProp?'propaldet':'facturedet'; $date=$isProp?'datep':'datef';
    $head=fetch_all('SELECT d.rowid,d.ref,d.fk_soc,d.total_ht,d.total_tva,d.total_ttc,d.fk_statut as status,d.'.$date.' as date_doc,s.nom as thirdparty,s.email,s.phone,s.town FROM '.MAIN_DB_PREFIX.$table.' d LEFT JOIN '.MAIN_DB_PREFIX.'societe s ON s.rowid=d.fk_soc WHERE d.rowid='.$id.' AND '.entity_where('d').' LIMIT 1');
    if(!$head) tw_json(['ok'=>false,'error'=>'Document introuvable'],404);
    $lines=fetch_all('SELECT rowid, fk_product, description, qty, subprice, remise_percent, tva_tx, total_ht, total_tva, total_ttc, rang FROM '.MAIN_DB_PREFIX.$line.' WHERE fk_'.$table.'='.$id.' ORDER BY rang,rowid');
    $notes=fetch_all("SELECT rowid, note as note, datec FROM ".MAIN_DB_PREFIX."actioncomm WHERE elementtype='".($isProp?'propal':'invoice')."' AND fk_element=".$id." ORDER BY rowid DESC LIMIT 20");
    tw_json(['ok'=>true,'type'=>$isProp?'propal':'invoice','doc'=>$head[0],'lines'=>$lines,'notes'=>$notes]);
}

if (in_array($action, ['propal_line_add','propal_line_update','propal_line_delete','invoice_line_add','invoice_line_update','invoice_line_delete'])) {
    $id=(int)GETPOST('id','int'); if(!$id) tw_json(['ok'=>false,'error'=>'id document manquant'],400);
    $isProp=strpos($action,'propal_')===0;
    if($isProp) { require_once DOL_DOCUMENT_ROOT.'/comm/propal/class/propal.class.php'; $obj=new Propal($db); }
    else { require_once DOL_DOCUMENT_ROOT.'/compta/facture/class/facture.class.php'; $obj=new Facture($db); }
    if($obj->fetch($id)<=0) tw_json(['ok'=>false,'error'=>'Document introuvable'],404);
    if(!$isProp && (int)$obj->status>0 && strpos($action,'delete')===false) tw_json(['ok'=>false,'error'=>'Facture validée: modification lignes bloquée par sécurité'],400);
    $lineid=(int)GETPOST('lineid','int');
    if(strpos($action,'_add')!==false){
        $desc=GETPOST('description','restricthtml'); $qty=(float)GETPOST('qty','alpha'); $pu=(float)GETPOST('subprice','alpha'); $tva=(float)GETPOST('tva_tx','alpha');
        if($desc==='') $desc='Nouvelle ligne Twitten'; if(!$qty) $qty=1;
        $res=$isProp ? $obj->addline($desc,$pu,$qty,$tva,0,0,0,0,'HT',0,0,0,0,0,0,0,0,0,'',0,0,null,0,'',0,0) : $obj->addline($desc,$pu,$qty,$tva,0,0,0,0,'HT');
        if($res<0) tw_json(['ok'=>false,'error'=>$obj->error,'errors'=>$obj->errors],500);
        tw_json(['ok'=>true,'message'=>'Ligne ajoutée','lineid'=>$res]);
    }
    if(strpos($action,'_update')!==false){
        if(!$lineid) tw_json(['ok'=>false,'error'=>'lineid manquant'],400);
        $desc=GETPOST('description','restricthtml'); $qty=(float)GETPOST('qty','alpha'); $pu=(float)GETPOST('subprice','alpha'); $tva=(float)GETPOST('tva_tx','alpha');
        $res=$isProp ? $obj->updateline($lineid,$desc,$pu,$qty,0,$tva,0,0,'HT',0,0,0,0,0,0,0,0,0,'',0,0,null,0,'',0,0) : $obj->updateline($lineid,$desc,$pu,$qty,0,$tva,0,0,'HT');
        if($res<0) tw_json(['ok'=>false,'error'=>$obj->error,'errors'=>$obj->errors],500);
        tw_json(['ok'=>true,'message'=>'Ligne modifiée']);
    }
    if(strpos($action,'_delete')!==false){
        if(!$lineid) tw_json(['ok'=>false,'error'=>'lineid manquant'],400);
        $res=$obj->deleteline($lineid);
        if($res<0) tw_json(['ok'=>false,'error'=>$obj->error,'errors'=>$obj->errors],500);
        tw_json(['ok'=>true,'message'=>'Ligne supprimée']);
    }
}

if ($action==='generate_pdf') {
    $type=GETPOST('type','alpha'); $id=(int)GETPOST('id','int'); if(!$id) tw_json(['ok'=>false,'error'=>'id manquant'],400);
    if($type==='propal'){ require_once DOL_DOCUMENT_ROOT.'/comm/propal/class/propal.class.php'; $obj=new Propal($db); $modulepart='propal'; }
    elseif($type==='invoice'){ require_once DOL_DOCUMENT_ROOT.'/compta/facture/class/facture.class.php'; $obj=new Facture($db); $modulepart='facture'; }
    else tw_json(['ok'=>false,'error'=>'type invalide'],400);
    if($obj->fetch($id)<=0) tw_json(['ok'=>false,'error'=>'document introuvable'],404);
    $res=$obj->generateDocument($obj->model_pdf, $outputlangs);
    if($res<0) tw_json(['ok'=>false,'error'=>$obj->error,'errors'=>$obj->errors],500);
    $url=dol_buildpath('/document.php?modulepart='.$modulepart.'&file='.urlencode($obj->ref.'/'.$obj->ref.'.pdf'),2);
    tw_json(['ok'=>true,'message'=>'PDF généré','url'=>$url]);
}

if ($action==='add_note') {
    $type=GETPOST('object_type','alpha') ?: GETPOST('type','alpha'); $id=(int)(GETPOST('object_id','int') ?: GETPOST('id','int')); $note=GETPOST('note','restricthtml');
    if(!$id || !$note) tw_json(['ok'=>false,'error'=>'id/note manquant'],400);
    require_once DOL_DOCUMENT_ROOT.'/comm/action/class/actioncomm.class.php';
    $a=new ActionComm($db); $a->type_code='AC_OTH_AUTO'; $a->label='Twitten note'; $a->note_private=$note; $a->datep=dol_now(); $a->datef=dol_now(); $a->fk_element=$id; $a->elementtype=$type==='propal'?'propal':($type==='invoice'?'invoice':'societe');
    $res=$a->create($user); if($res<0) tw_json(['ok'=>false,'error'=>$a->error],500);
    tw_json(['ok'=>true,'message'=>'Note ajoutée']);
}



// --- Twitten Clean Pro: compatibilité UI moderne (list/detail/search/actions) ---
function tw_clean_type_map($type){
    $type=strtolower((string)$type);
    $map=[
        'client'=>['societe','rowid','nom','client'], 'clients'=>['societe','rowid','nom','client'], 'thirdparty'=>['societe','rowid','nom','client'],
        'propal'=>['propal','rowid','ref','propal'], 'proposal'=>['propal','rowid','ref','propal'], 'devis'=>['propal','rowid','ref','propal'], 'propals'=>['propal','rowid','ref','propal'],
        'invoice'=>['facture','rowid','ref','facture'], 'facture'=>['facture','rowid','ref','facture'], 'invoices'=>['facture','rowid','ref','facture'],
        'order'=>['commande','rowid','ref','commande'], 'commande'=>['commande','rowid','ref','commande'], 'orders'=>['commande','rowid','ref','commande'],
        'project'=>['projet','rowid','ref','projet'], 'projets'=>['projet','rowid','ref','projet'], 'projects'=>['projet','rowid','ref','projet'],
        'product'=>['product','rowid','ref','product'], 'products'=>['product','rowid','ref','product']
    ];
    return $map[$type] ?? null;
}
function tw_clean_money($v){ return number_format((float)$v,2,'.',"'"); }
function tw_clean_fetch_cols($table){ global $db; $cols=[]; $res=$db->query('SHOW COLUMNS FROM '.MAIN_DB_PREFIX.$table); if($res){ while($o=$db->fetch_object($res)) $cols[$o->Field]=true; } return $cols; }
function tw_clean_add_actioncomm($type,$id,$label,$note='',$datep=''){
    global $db,$conf,$user;
    $m=tw_clean_type_map($type); if(!$m) tw_json(['ok'=>false,'error'=>'Type objet inconnu'],400);
    $cols=tw_clean_fetch_cols('actioncomm'); if(!$cols) tw_json(['ok'=>false,'error'=>'Table actioncomm introuvable'],500);
    $date=$datep?:date('Y-m-d',time()+86400); if(strlen($date)===10) $date.=' 09:00:00';
    $vals=[]; $add=function($c,$v)use(&$vals,$cols,$db){ if(!isset($cols[$c])) return; if($v===null || $v==='') $vals[$c]='NULL'; elseif(is_int($v)||is_float($v)) $vals[$c]=(string)$v; else $vals[$c]="'".$db->escape((string)$v)."'"; };
    $add('entity',(int)$conf->entity); $add('datec',date('Y-m-d H:i:s')); $add('datep',$date); $add('datep2',$date); $add('datef',$date); $add('datef2',$date);
    $add('durationp',0); $add('code','AC_TODO'); $add('type_code','AC_TODO'); $add('label',$label); $add('note',$note); $add('note_private',$note);
    $add('fk_element',(int)$id); $add('elementtype',$m[3]); $add('fk_user_author',(int)($user->id??1)); $add('fk_user_action',(int)($user->id??1));
    $add('percentage',0); $add('percent',0); $add('priority',0); $add('fulldayevent',0); $add('transparency',0);
    $sql='INSERT INTO '.MAIN_DB_PREFIX.'actioncomm ('.implode(',',array_keys($vals)).') VALUES ('.implode(',',array_values($vals)).')';
    $res=$db->query($sql); if(!$res) tw_json(['ok'=>false,'error'=>$db->lasterror(),'sql'=>$sql],500);
    tw_json(['ok'=>true,'message'=>'Tâche créée dans Dolibarr']);
}

if ($action==='list') {
    global $db;
    $type=GETPOST('type','alpha'); $limit=max(1,min(200,(int)(GETPOST('limit','int') ?: 80))); $q=trim((string)GETPOST('q','alphanohtml'));
    $m=tw_clean_type_map($type); if(!$m) tw_json(['ok'=>false,'error'=>'Type liste inconnu: '.$type],400);
    [$table,$idcol,$refcol,$elementtype]=$m; $where=entity_where('t');
    $select='t.rowid'; $join=''; $order='t.rowid DESC';
    if($table==='societe') { $select.=', t.nom as name, t.code_client, t.email, t.phone, t.town, t.zip'; $where.=' AND t.client IN (1,2,3)'; if($q!==''){ $like=$db->escape('%'.$q.'%'); $where.=" AND (t.nom LIKE '$like' OR t.code_client LIKE '$like' OR t.email LIKE '$like' OR t.town LIKE '$like')"; } }
    elseif($table==='facture') { $select.=', t.ref, t.total_ht, t.total_ttc, t.paye, t.datef, s.nom as thirdparty'; $join=' LEFT JOIN '.MAIN_DB_PREFIX.'societe s ON s.rowid=t.fk_soc'; if($q!==''){ $like=$db->escape('%'.$q.'%'); $where.=" AND (t.ref LIKE '$like' OR s.nom LIKE '$like')"; } }
    elseif($table==='propal') { $select.=', t.ref, t.total_ht, t.total_ttc, t.fk_statut as status, t.datep, s.nom as thirdparty'; $join=' LEFT JOIN '.MAIN_DB_PREFIX.'societe s ON s.rowid=t.fk_soc'; if($q!==''){ $like=$db->escape('%'.$q.'%'); $where.=" AND (t.ref LIKE '$like' OR s.nom LIKE '$like')"; } }
    elseif($table==='commande') { $select.=', t.ref, t.total_ht, t.total_ttc, t.fk_statut as status, t.date_commande, s.nom as thirdparty'; $join=' LEFT JOIN '.MAIN_DB_PREFIX.'societe s ON s.rowid=t.fk_soc'; if($q!==''){ $like=$db->escape('%'.$q.'%'); $where.=" AND (t.ref LIKE '$like' OR s.nom LIKE '$like')"; } }
    elseif($table==='projet') { $select.=', t.ref, t.title, t.dateo, t.datee, t.fk_statut as status'; if($q!==''){ $like=$db->escape('%'.$q.'%'); $where.=" AND (t.ref LIKE '$like' OR t.title LIKE '$like')"; } }
    else { $select.=', t.ref, t.label, t.price, t.tva_tx, t.tosell'; if($q!==''){ $like=$db->escape('%'.$q.'%'); $where.=" AND (t.ref LIKE '$like' OR t.label LIKE '$like' OR t.description LIKE '$like')"; } }
    tw_json(['ok'=>true,'type'=>$type,'items'=>fetch_all("SELECT $select FROM ".MAIN_DB_PREFIX."$table t $join WHERE $where ORDER BY $order LIMIT $limit")]);
}

if ($action==='detail') {
    $type=GETPOST('type','alpha'); $id=(int)GETPOST('id','int'); if(!$id) tw_json(['ok'=>false,'error'=>'id manquant'],400);
    if(in_array(strtolower($type),['propal','proposal','devis'],true)) {
        $head=fetch_all('SELECT d.rowid,d.ref,d.fk_soc,d.total_ht,d.total_tva,d.total_ttc,d.fk_statut as status,d.datep as date_doc,s.nom as thirdparty,s.email,s.phone,s.town FROM '.MAIN_DB_PREFIX.'propal d LEFT JOIN '.MAIN_DB_PREFIX.'societe s ON s.rowid=d.fk_soc WHERE d.rowid='.$id.' AND '.entity_where('d').' LIMIT 1');
        if(!$head) tw_json(['ok'=>false,'error'=>'Devis introuvable'],404);
        $lines=fetch_all('SELECT rowid, fk_product, description, qty, subprice, remise_percent, tva_tx, total_ht, total_tva, total_ttc, rang FROM '.MAIN_DB_PREFIX.'propaldet WHERE fk_propal='.$id.' ORDER BY rang,rowid');
        tw_json(['ok'=>true,'type'=>'propal','object'=>$head[0],'doc'=>$head[0],'lines'=>$lines]);
    }
    elseif(in_array(strtolower($type),['invoice','facture'],true)) {
        $head=fetch_all('SELECT d.rowid,d.ref,d.fk_soc,d.total_ht,d.total_tva,d.total_ttc,d.fk_statut as status,d.datef as date_doc,d.paye,s.nom as thirdparty,s.email,s.phone,s.town FROM '.MAIN_DB_PREFIX.'facture d LEFT JOIN '.MAIN_DB_PREFIX.'societe s ON s.rowid=d.fk_soc WHERE d.rowid='.$id.' AND '.entity_where('d').' LIMIT 1');
        if(!$head) tw_json(['ok'=>false,'error'=>'Facture introuvable'],404);
        $lines=fetch_all('SELECT rowid, fk_product, description, qty, subprice, remise_percent, tva_tx, total_ht, total_tva, total_ttc, rang FROM '.MAIN_DB_PREFIX.'facturedet WHERE fk_facture='.$id.' ORDER BY rang,rowid');
        tw_json(['ok'=>true,'type'=>'invoice','object'=>$head[0],'doc'=>$head[0],'lines'=>$lines]);
    }
    else {
        $m=tw_clean_type_map($type); if(!$m) tw_json(['ok'=>false,'error'=>'Type détail inconnu'],400);
        [$table]=$m; $rows=fetch_all('SELECT * FROM '.MAIN_DB_PREFIX.$table.' WHERE rowid='.$id.' AND '.entity_where().' LIMIT 1');
        if(!$rows) tw_json(['ok'=>false,'error'=>'Objet introuvable'],404);
        tw_json(['ok'=>true,'type'=>$type,'object'=>$rows[0],'lines'=>[]]);
    }
}

if ($action==='search') {
    global $db; $q=trim((string)GETPOST('q','alphanohtml')); $limit=max(3,min(30,(int)(GETPOST('limit','int') ?: 12)));
    if(function_exists('mb_strlen') ? mb_strlen($q)<2 : strlen($q)<2) tw_json(['ok'=>true,'items'=>[]]);
    $like=$db->escape('%'.$q.'%'); $items=[];
    foreach(fetch_all("SELECT rowid, nom as title, code_client as subtitle, email, town FROM ".MAIN_DB_PREFIX."societe WHERE ".entity_where()." AND client IN (1,2,3) AND (nom LIKE '$like' OR code_client LIKE '$like' OR email LIKE '$like') ORDER BY rowid DESC LIMIT $limit") as $r) $items[]=['type'=>'client','id'=>$r['rowid'],'title'=>$r['title'],'subtitle'=>$r['subtitle'] ?: 'Client','meta'=>trim(($r['email']??'').' '.($r['town']??''))];
    foreach(fetch_all("SELECT rowid, ref, total_ttc FROM ".MAIN_DB_PREFIX."facture WHERE ".entity_where()." AND ref LIKE '$like' ORDER BY rowid DESC LIMIT $limit") as $r) $items[]=['type'=>'invoice','id'=>$r['rowid'],'title'=>$r['ref'],'subtitle'=>'Facture','meta'=>'TTC '.tw_clean_money($r['total_ttc']).' CHF'];
    foreach(fetch_all("SELECT rowid, ref, total_ttc FROM ".MAIN_DB_PREFIX."propal WHERE ".entity_where()." AND ref LIKE '$like' ORDER BY rowid DESC LIMIT $limit") as $r) $items[]=['type'=>'propal','id'=>$r['rowid'],'title'=>$r['ref'],'subtitle'=>'Devis','meta'=>'TTC '.tw_clean_money($r['total_ttc']).' CHF'];
    tw_json(['ok'=>true,'items'=>array_slice($items,0,$limit)]);
}

if ($action==='create_task') {
    $type=GETPOST('object_type','alpha') ?: GETPOST('type','alpha'); $id=(int)(GETPOST('object_id','int') ?: GETPOST('id','int'));
    $label=trim((string)GETPOST('label','restricthtml')); $note=trim((string)GETPOST('note','restricthtml')); $datep=trim((string)GETPOST('datep','alphanohtml'));
    if(!$id || $label==='') tw_json(['ok'=>false,'error'=>'Objet ou titre de tâche manquant'],400);
    tw_clean_add_actioncomm($type,$id,$label,$note,$datep);
}

if ($action==='prepare_reminder') {
    $type=GETPOST('object_type','alpha') ?: GETPOST('type','alpha'); $id=(int)(GETPOST('object_id','int') ?: GETPOST('id','int')); if(!$id) tw_json(['ok'=>false,'error'=>'id manquant'],400);
    $label='Relance préparée depuis Twitten'; $note='Relance à vérifier et envoyer au client. Créé depuis Twitten.'; tw_clean_add_actioncomm($type,$id,$label,$note,date('Y-m-d',time()+86400));
}

tw_json(['ok'=>false,'error'=>'Action inconnue: '.$action],400);
