# Installation Phase 13

Structure conseillée :

```text
/htdocs/crm       -> Dolibarr existant
/htdocs/twitten   -> Twitten
```

Sous-domaine :

```text
twitten.mv-3.ch -> /htdocs/twitten/public
```

Contrôles :

- PHP 8.1+ recommandé.
- Extension PDO MySQL active.
- HTTPS actif.
- Dossier `storage` accessible en écriture.
- Dolibarr non modifié.

La phase 13 est encore en mode sécurité : lecture Dolibarr prioritaire, actions réelles verrouillées.
