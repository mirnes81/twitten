# Twitten Phase 17 — Dashboard intelligent

## Objectif
Transformer le dashboard en cockpit de pilotage : Twitten lit Dolibarr et affiche les priorités d'action.

## Nouveautés
- API `/api/dashboard.php`
- page `/dashboard.php`
- KPI factures ouvertes, montant ouvert, devis ouverts, factures en retard, projets actifs
- alertes prioritaires : factures en retard et devis sans réponse
- encaissements attendus par mois
- liste de relances / suivis
- activité récente

## Installation
1. Copier le dossier `twitten_phase17` dans le dossier du sous-domaine.
2. Pointer le sous-domaine vers `public/`.
3. Ouvrir `/install.php` si la configuration n'est pas encore faite.
4. Ouvrir `/dashboard.php`.

## Sécurité
Cette phase reste en lecture des données Dolibarr pour le dashboard.
Aucune modification du core Dolibarr.
