# Twitten Phase 16 — Moteur de recherche Dolibarr

## Objectif
La barre de recherche existante reste en haut de Twitten, mais elle utilise maintenant un moteur d’indexation local.

## Ce qui est indexé
- clients / tiers
- produits / services
- devis
- factures
- commandes
- projets
- notes publiques et privées
- extrafields
- références client
- projet lié
- montants et prix

## Installation
1. Remplacer le dossier Twitten par cette version, ou copier les nouveaux fichiers dans l’installation existante.
2. Vérifier que le dossier suivant est inscriptible :

```text
/twitten/storage/search_index
```

3. Ouvrir :

```text
https://twitten.mv-3.ch/search-index.php
```

4. Cliquer sur **Reconstruire l’index**.

## Fonctionnement
- Dès 2 lettres, Twitten cherche dans l’index local.
- Si l’index n’existe pas encore, Twitten fait un fallback live sur Dolibarr.
- L’aperçu au survol affiche les métadonnées principales, extrafields et notes disponibles.

## Cron recommandé
Pour garder l’index frais, ajouter un cron toutes les 5 à 15 minutes plus tard. Pour l’instant, la reconstruction manuelle est plus sûre.

## Sécurité
Aucune écriture dans Dolibarr. La Phase 16 lit Dolibarr et écrit uniquement un fichier JSON dans le stockage Twitten.
