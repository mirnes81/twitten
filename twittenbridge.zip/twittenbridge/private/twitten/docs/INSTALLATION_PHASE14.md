# Installation Phase 14

1. Décompresser le dossier `twitten_phase14`.
2. Envoyer le contenu dans `/htdocs/twitten`.
3. Faire pointer `twitten.mv-3.ch` vers `/htdocs/twitten/public`.
4. Vérifier les droits d’écriture :
   - `storage/logs`
   - `storage/queue`
   - `storage/config`
5. Ouvrir `/install.php`.
6. Laisser Twitten détecter `/htdocs/crm/conf/conf.php` ou indiquer le chemin manuellement.
7. Tester le dashboard et la recherche.
8. Tester les actions en simulation.

## Écriture réelle

À activer seulement après test :

```bash
TWITTEN_WRITE_MODE=enabled
```

Même activée, l’interface demande la confirmation `WRITE_DOLIBARR`.
