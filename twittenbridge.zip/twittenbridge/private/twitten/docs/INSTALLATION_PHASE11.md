# Installation Phase 11 sur twitten.mv-3.ch

1. Uploader le contenu sur le serveur dans `/htdocs/twitten`.
2. Dans le manager du domaine, créer le sous-domaine `twitten.mv-3.ch`.
3. Pointer le sous-domaine vers `/htdocs/twitten/public`.
4. Vérifier que PHP 8.1+ est actif.
5. Vérifier que `/htdocs/twitten/storage` est inscriptible.
6. Ouvrir `https://twitten.mv-3.ch/install.php`.
7. Entrer le chemin Dolibarr, normalement `/htdocs/crm`.
8. Cliquer sur tester et installer.
9. Ouvrir `/diagnostic.php`.

## Important

Twitten lit la configuration Dolibarr mais ne modifie pas Dolibarr.
Le mode lecture seule reste activé pour cette phase.
