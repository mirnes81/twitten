# Twitten Phase 15 — Documents & e-mails

## Installation

1. Décompresser `twitten_phase15.zip`.
2. Envoyer le dossier `twitten_phase15` sur le serveur, idéalement en le renommant `twitten`.
3. Pointer le sous-domaine vers :

```text
/htdocs/twitten/public
```

4. Ouvrir :

```text
https://twitten.mv-3.ch/install.php
```

5. Vérifier la détection Dolibarr, puis ouvrir :

```text
https://twitten.mv-3.ch/documents.php
```

## Nouveautés

- Page Documents & e-mails.
- Modèles documents stockés dans `storage/config/document_templates.json`.
- Modèles e-mail stockés dans `storage/config/email_templates.json`.
- Génération HTML imprimable dans `storage/documents`.
- File d’attente e-mail dans `storage/queue`.
- Aucun envoi automatique.

## Sécurité

- CSRF obligatoire pour génération et file e-mail.
- Les e-mails sont préparés, pas envoyés.
- Les documents utilisent les données Dolibarr, sans modifier le core.
