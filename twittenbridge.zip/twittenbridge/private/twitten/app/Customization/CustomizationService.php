<?php
declare(strict_types=1);
namespace Twitten\Customization;

use Twitten\Core\JsonStore;

final class CustomizationService
{
    private JsonStore $store;

    public function __construct(string $storageRoot)
    {
        $this->store = new JsonStore(rtrim($storageRoot, '/').'/customization');
    }

    public function branding(): array
    {
        return $this->store->read('branding.json', [
            'company_name' => 'MV-3 PRO',
            'app_name' => 'Twitten',
            'accent' => '#6d5dfc',
            'logo_text' => 'T',
            'theme' => 'light',
            'compact_mode' => false,
        ]);
    }

    public function saveBranding(array $data): array
    {
        $current = $this->branding();
        $accent = preg_match('/^#[0-9a-fA-F]{6}$/', (string)($data['accent'] ?? '')) ? $data['accent'] : $current['accent'];
        $next = [
            'company_name' => trim((string)($data['company_name'] ?? $current['company_name'])),
            'app_name' => trim((string)($data['app_name'] ?? $current['app_name'])),
            'accent' => $accent,
            'logo_text' => strtoupper(substr(trim((string)($data['logo_text'] ?? $current['logo_text'])), 0, 2)) ?: 'T',
            'theme' => in_array(($data['theme'] ?? $current['theme']), ['light','dark','auto'], true) ? $data['theme'] : 'light',
            'compact_mode' => !empty($data['compact_mode']),
        ];
        $this->store->write('branding.json', $next);
        return $next;
    }

    public function fields(): array
    {
        return $this->store->read('fields.json', [
            'thirdparties' => [], 'products' => [], 'proposals' => [], 'invoices' => [], 'orders' => [], 'projects' => []
        ]);
    }

    public function addField(array $data): array
    {
        $module = $this->safeModule((string)($data['module'] ?? ''));
        $label = trim((string)($data['label'] ?? ''));
        if ($module === '' || $label === '') return $this->fields();
        $fields = $this->fields();
        $key = strtolower(preg_replace('/[^a-zA-Z0-9_]+/', '_', $label));
        $fields[$module][] = [
            'key' => $key.'_'.substr(sha1($label.microtime(true)), 0, 5),
            'label' => $label,
            'type' => in_array(($data['type'] ?? 'text'), ['text','number','date','select','textarea','checkbox'], true) ? $data['type'] : 'text',
            'required' => !empty($data['required']),
            'show_in_search' => !empty($data['show_in_search']),
            'show_in_pdf' => !empty($data['show_in_pdf']),
            'options' => trim((string)($data['options'] ?? '')),
        ];
        $this->store->write('fields.json', $fields);
        return $fields;
    }

    public function views(): array
    {
        return $this->store->read('views.json', [
            'dashboard_widgets' => ['smart_alerts','expected_payments','quotes_to_follow','recent_activity','today_column'],
            'menus' => ['dashboard','search','clients','proposals','invoices','orders','projects','products','documents','ai','customization'],
            'lists' => [
                'invoices' => ['ref','thirdparty','date','total_ttc','status'],
                'proposals' => ['ref','thirdparty','date','total_ttc','status'],
                'products' => ['ref','label','price','stock'],
            ],
        ]);
    }

    public function saveViews(array $data): array
    {
        $views = $this->views();
        foreach (['dashboard_widgets','menus'] as $key) {
            if (isset($data[$key]) && is_array($data[$key])) $views[$key] = array_values(array_map('strval', $data[$key]));
        }
        $this->store->write('views.json', $views);
        return $views;
    }

    public function templates(): array
    {
        return $this->store->read('templates.json', [
            'invoice' => ['name'=>'Facture moderne', 'header'=>'{{company_name}}', 'footer'=>'Merci pour votre confiance.', 'show_extrafields'=>true],
            'proposal' => ['name'=>'Devis moderne', 'header'=>'Offre {{ref}}', 'footer'=>'Validité selon conditions indiquées.', 'show_extrafields'=>true],
            'order' => ['name'=>'Commande moderne', 'header'=>'Commande {{ref}}', 'footer'=>'Document généré par Twitten.', 'show_extrafields'=>true],
        ]);
    }

    public function saveTemplate(array $data): array
    {
        $type = in_array(($data['type'] ?? ''), ['invoice','proposal','order'], true) ? $data['type'] : 'invoice';
        $templates = $this->templates();
        $templates[$type] = [
            'name' => trim((string)($data['name'] ?? $templates[$type]['name'])),
            'header' => trim((string)($data['header'] ?? $templates[$type]['header'])),
            'footer' => trim((string)($data['footer'] ?? $templates[$type]['footer'])),
            'show_extrafields' => !empty($data['show_extrafields']),
        ];
        $this->store->write('templates.json', $templates);
        return $templates;
    }

    public function workflows(): array
    {
        return $this->store->read('workflows.json', [
            ['id'=>'invoice_late_reminder','name'=>'Relance facture en retard','trigger'=>'invoice.overdue','action'=>'prepare_email','enabled'=>true],
            ['id'=>'proposal_no_answer','name'=>'Devis sans réponse','trigger'=>'proposal.no_answer_10d','action'=>'create_followup_task','enabled'=>true],
            ['id'=>'project_missing_docs','name'=>'Documents chantier manquants','trigger'=>'project.missing_documents','action'=>'notify_today_column','enabled'=>false],
        ]);
    }

    public function addWorkflow(array $data): array
    {
        $workflows = $this->workflows();
        $name = trim((string)($data['name'] ?? ''));
        if ($name !== '') {
            $workflows[] = [
                'id' => 'wf_'.substr(sha1($name.microtime(true)), 0, 10),
                'name' => $name,
                'trigger' => trim((string)($data['trigger'] ?? 'manual')),
                'action' => trim((string)($data['action'] ?? 'notify_today_column')),
                'enabled' => !empty($data['enabled']),
            ];
            $this->store->write('workflows.json', $workflows);
        }
        return $workflows;
    }

    public function exportAll(): array
    {
        return [
            'branding' => $this->branding(),
            'fields' => $this->fields(),
            'views' => $this->views(),
            'templates' => $this->templates(),
            'workflows' => $this->workflows(),
            'exported_at' => date('c'),
            'phase' => '19',
        ];
    }

    private function safeModule(string $module): string
    {
        return in_array($module, ['thirdparties','products','proposals','invoices','orders','projects'], true) ? $module : '';
    }
}
