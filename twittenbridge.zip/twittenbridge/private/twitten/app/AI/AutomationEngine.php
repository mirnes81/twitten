<?php
declare(strict_types=1);
namespace Twitten\AI;

use PDO;
use Throwable;

final class AutomationEngine
{
    private string $storage;
    public function __construct(private PDO $pdo, private string $prefix='llx_', private string $root='')
    {
        $this->storage=rtrim($root,'/').'/storage/automation';
        if(!is_dir($this->storage)) @mkdir($this->storage,0775,true);
    }

    public function dashboard(): array
    {
        $rules=$this->rules();
        $runs=$this->readJsonl($this->storage.'/runs.jsonl',30);
        $queue=$this->queue();
        return [
            'mode'=>$this->mode(),
            'rules'=>$rules,
            'stats'=>[
                'enabled'=>count(array_filter($rules,fn($r)=>!empty($r['enabled']))),
                'queued'=>count($queue),
                'waiting_validation'=>count(array_filter($queue,fn($q)=>($q['status']??'')==='pending_validation')),
                'executed_today'=>count(array_filter($runs,fn($r)=>str_starts_with((string)($r['date']??''),date('Y-m-d')) && ($r['status']??'')==='executed')),
            ],
            'queue'=>array_slice($queue,0,40),
            'runs'=>$runs,
        ];
    }

    public function scan(bool $persist=true): array
    {
        $detected=[];
        foreach($this->rules() as $rule){
            if(empty($rule['enabled'])) continue;
            foreach($this->evaluate($rule) as $candidate){
                $candidate['rule_id']=$rule['id'];
                $candidate['rule_name']=$rule['name'];
                $candidate['risk']=$rule['risk'];
                $candidate['created_at']=date('c');
                $candidate['status']=$this->approvalStatus($rule);
                $candidate['fingerprint']=hash('sha256',$rule['id'].'|'.$candidate['object_type'].'|'.$candidate['object_id'].'|'.$candidate['action']);
                if(!$this->alreadyQueued($candidate['fingerprint'])) $detected[]=$candidate;
            }
        }
        if($persist) foreach($detected as $item) $this->saveQueueItem($item);
        $this->logRun('scan','completed',['detected'=>count($detected)]);
        return ['ok'=>true,'detected'=>count($detected),'items'=>$detected,'mode'=>$this->mode()];
    }

    public function approve(string $id): array { return $this->changeStatus($id,'approved'); }
    public function reject(string $id): array { return $this->changeStatus($id,'rejected'); }

    public function executeApproved(): array
    {
        $done=[];
        foreach($this->queue() as $item){
            if(($item['status']??'')!=='approved' && ($item['status']??'')!=='auto_approved') continue;
            $item['status']='prepared';
            $item['executed_at']=date('c');
            $item['execution_note']='Action préparée pour le connecteur Dolibarr/n8n. Les écritures sensibles restent protégées par le bridge.';
            $this->writeQueueItem($item);
            $done[]=$item;
            $this->logRun('execute','executed',['queue_id'=>$item['id'],'action'=>$item['action']]);
        }
        return ['ok'=>true,'executed'=>count($done),'items'=>$done];
    }

    public function updateRule(string $id,array $changes): array
    {
        $rules=$this->rules(); $found=false;
        foreach($rules as &$r){ if($r['id']!==$id) continue; $found=true;
            foreach(['enabled','threshold','days','autonomy'] as $k) if(array_key_exists($k,$changes)) $r[$k]=$changes[$k];
        }
        if(!$found) return ['ok'=>false,'error'=>'Règle introuvable.'];
        file_put_contents($this->storage.'/rules.json',json_encode($rules,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE),LOCK_EX);
        return ['ok'=>true,'rules'=>$rules];
    }

    public function rules(): array
    {
        $file=$this->storage.'/rules.json';
        if(is_file($file)){ $v=json_decode((string)file_get_contents($file),true); if(is_array($v)) return $v; }
        $rules=[
            ['id'=>'invoice_overdue','name'=>'Factures échues','description'=>'Détecte les factures impayées après échéance et prépare une relance.','enabled'=>true,'risk'=>'medium','autonomy'=>'approval','days'=>1,'action'=>'prepare_reminder'],
            ['id'=>'proposal_no_reply','name'=>'Devis sans réponse','description'=>'Détecte les devis ouverts sans réponse depuis plusieurs jours.','enabled'=>true,'risk'=>'low','autonomy'=>'approval','days'=>10,'action'=>'prepare_followup'],
            ['id'=>'project_late','name'=>'Chantiers en retard','description'=>'Signale les projets actifs dont la date de fin est dépassée.','enabled'=>true,'risk'=>'low','autonomy'=>'auto','days'=>0,'action'=>'create_alert'],
            ['id'=>'high_value_invoice','name'=>'Facture importante impayée','description'=>'Escalade les factures impayées dépassant le seuil défini.','enabled'=>true,'risk'=>'high','autonomy'=>'approval','threshold'=>10000,'action'=>'management_review'],
        ];
        file_put_contents($file,json_encode($rules,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE),LOCK_EX);
        return $rules;
    }

    private function evaluate(array $r): array
    {
        try { return match($r['id']) {
            'invoice_overdue'=>$this->rows("SELECT f.rowid object_id,f.ref,s.nom thirdparty,f.total_ttc amount,f.date_lim_reglement due_date FROM {$this->prefix}facture f LEFT JOIN {$this->prefix}societe s ON s.rowid=f.fk_soc WHERE f.fk_statut>0 AND f.paye=0 AND f.date_lim_reglement IS NOT NULL AND f.date_lim_reglement<DATE_SUB(CURDATE(),INTERVAL ".(int)($r['days']??1)." DAY) ORDER BY f.date_lim_reglement ASC LIMIT 100",'invoice',$r['action']),
            'proposal_no_reply'=>$this->rows("SELECT p.rowid object_id,p.ref,s.nom thirdparty,p.total_ttc amount,p.datep due_date FROM {$this->prefix}propal p LEFT JOIN {$this->prefix}societe s ON s.rowid=p.fk_soc WHERE p.fk_statut IN(1,2) AND p.datep<DATE_SUB(CURDATE(),INTERVAL ".(int)($r['days']??10)." DAY) ORDER BY p.datep ASC LIMIT 100",'proposal',$r['action']),
            'project_late'=>$this->rows("SELECT rowid object_id,ref,title thirdparty,0 amount,datee due_date FROM {$this->prefix}projet WHERE fk_statut IN(1,2) AND datee IS NOT NULL AND datee<CURDATE() ORDER BY datee ASC LIMIT 100",'project',$r['action']),
            'high_value_invoice'=>$this->rows("SELECT f.rowid object_id,f.ref,s.nom thirdparty,f.total_ttc amount,f.date_lim_reglement due_date FROM {$this->prefix}facture f LEFT JOIN {$this->prefix}societe s ON s.rowid=f.fk_soc WHERE f.fk_statut>0 AND f.paye=0 AND f.total_ttc>=".(float)($r['threshold']??10000)." ORDER BY f.total_ttc DESC LIMIT 100",'invoice',$r['action']),
            default=>[] };
        } catch(Throwable){ return []; }
    }

    private function rows(string $sql,string $type,string $action): array
    {
        $rows=$this->pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC)?:[];
        return array_map(fn($x)=>$x+['object_type'=>$type,'action'=>$action,'title'=>trim(($x['ref']??'').' — '.($x['thirdparty']??''))],$rows);
    }
    private function approvalStatus(array $r): string { return ($r['autonomy']??'approval')==='auto' && ($r['risk']??'high')==='low' ? 'auto_approved':'pending_validation'; }
    private function mode(): array { return ['level'=>'supervised','label'=>'Autonomie supervisée','write_protection'=>true,'description'=>'Twitten détecte et prépare automatiquement. Les actions moyennes ou sensibles demandent une validation.']; }
    private function queue(): array { $out=[]; foreach(glob($this->storage.'/queue/*.json')?:[] as $f){$v=json_decode((string)file_get_contents($f),true);if(is_array($v))$out[]=$v;} usort($out,fn($a,$b)=>strcmp((string)($b['created_at']??''),(string)($a['created_at']??'')));return $out; }
    private function alreadyQueued(string $fp): bool { foreach($this->queue() as $q) if(($q['fingerprint']??'')===$fp && !in_array(($q['status']??''),['rejected','done'],true)) return true; return false; }
    private function saveQueueItem(array $item): void { $item['id']='auto_'.date('YmdHis').'_'.bin2hex(random_bytes(3)); $this->writeQueueItem($item); }
    private function writeQueueItem(array $item): void { $d=$this->storage.'/queue';if(!is_dir($d))@mkdir($d,0775,true);file_put_contents($d.'/'.$item['id'].'.json',json_encode($item,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE),LOCK_EX); }
    private function changeStatus(string $id,string $status): array { $f=$this->storage.'/queue/'.basename($id).'.json';if(!is_file($f))return['ok'=>false,'error'=>'Action introuvable.'];$v=json_decode((string)file_get_contents($f),true);$v['status']=$status;$v['validated_at']=date('c');$this->writeQueueItem($v);$this->logRun('validation',$status,['queue_id'=>$id]);return['ok'=>true,'item'=>$v]; }
    private function logRun(string $action,string $status,array $data=[]): void { file_put_contents($this->storage.'/runs.jsonl',json_encode(['date'=>date('c'),'action'=>$action,'status'=>$status,'data'=>$data],JSON_UNESCAPED_UNICODE).PHP_EOL,FILE_APPEND|LOCK_EX); }
    private function readJsonl(string $file,int $limit): array { if(!is_file($file))return[];$l=array_slice(file($file,FILE_IGNORE_NEW_LINES|FILE_SKIP_EMPTY_LINES)?:[],-$limit);return array_reverse(array_values(array_filter(array_map(fn($x)=>json_decode($x,true),$l)))); }
}
