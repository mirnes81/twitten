<?php
namespace Twitten\AI;

use PDO;
use Throwable;

final class AiCenter
{
    public function __construct(private PDO $pdo, private string $prefix = 'llx_', private string $root = '') {}

    public function overview(): array
    {
        $recommendations = array_merge(
            $this->accountingAgent(),
            $this->salesAgent(),
            $this->projectAgent(),
            $this->managementAgent(),
            $this->savAgent()
        );
        usort($recommendations, fn($a,$b)=>($b['score'] ?? 0) <=> ($a['score'] ?? 0));
        return [
            'generated_at' => date('c'),
            'summary' => $this->summary($recommendations),
            'agents' => $this->agentsStatus($recommendations),
            'recommendations' => array_slice($recommendations, 0, 60),
            'today' => $this->today($recommendations),
            'journal' => $this->journal(10),
        ];
    }

    public function ask(string $question): array
    {
        $q = mb_strtolower(trim($question));
        $data = $this->overview();
        $answer = "Je peux analyser Dolibarr et préparer des actions, mais aucune action sensible ne part sans validation.";
        $results = [];
        if (str_contains($q, 'facture') || str_contains($q, 'impay')) {
            $results = $this->accountingAgent();
            $answer = 'Voici les factures et relances prioritaires détectées dans Dolibarr.';
        } elseif (str_contains($q, 'devis') || str_contains($q, 'proposition')) {
            $results = $this->salesAgent();
            $answer = 'Voici les devis sans réponse ou dossiers commerciaux à suivre.';
        } elseif (str_contains($q, 'projet') || str_contains($q, 'chantier')) {
            $results = $this->projectAgent();
            $answer = 'Voici les projets ou chantiers qui méritent une vérification.';
        } elseif (str_contains($q, 'aujourd') || str_contains($q, 'priorit')) {
            $results = $data['today']['items'];
            $answer = 'Voici les priorités du jour selon Twitten.';
        }
        $this->appendJournal('assistant', 'Question assistant', $question, ['count'=>count($results)]);
        return ['answer'=>$answer, 'items'=>array_slice($results,0,20), 'generated_at'=>date('c')];
    }

    public function triggerWebhook(string $agent, string $action, array $payload = []): array
    {
        $entry = [
            'id' => 'ai_' . date('YmdHis') . '_' . bin2hex(random_bytes(3)),
            'date' => date('c'),
            'agent' => $agent,
            'action' => $action,
            'status' => 'queued',
            'mode' => 'simulation',
            'payload' => $payload,
            'note' => 'Action préparée pour n8n. Envoi réel désactivé par défaut.'
        ];
        $dir = $this->root . '/storage/webhooks';
        if (!is_dir($dir)) @mkdir($dir, 0775, true);
        file_put_contents($dir . '/' . $entry['id'] . '.json', json_encode($entry, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));
        $this->appendJournal($agent, $action, 'Webhook n8n mis en file en simulation', $payload);
        return $entry;
    }

    private function accountingAgent(): array
    {
        $items=[];
        foreach ($this->rows("SELECT f.rowid id, f.ref, f.total_ttc, f.datef, f.date_lim_reglement, s.nom thirdparty
            FROM {$this->prefix}facture f LEFT JOIN {$this->prefix}societe s ON s.rowid=f.fk_soc
            WHERE f.fk_statut > 0 AND f.paye = 0
            ORDER BY COALESCE(f.date_lim_reglement,f.datef) ASC LIMIT 25") as $r) {
            $late = !empty($r['date_lim_reglement']) && strtotime($r['date_lim_reglement']) < strtotime('today');
            $items[] = $this->rec('Comptabilité', $late?'danger':'warning', 'invoice', (int)$r['id'], 'Relance facture '.$r['ref'],
                ($r['thirdparty'] ?: 'Client') . ' — ' . $this->money($r['total_ttc']),
                $late ? 'Préparer une relance ferme mais professionnelle.' : 'Préparer un suivi avant échéance.',
                $late ? 95 : 72, ['Montant'=>$this->money($r['total_ttc']), 'Échéance'=>$r['date_lim_reglement'] ?: '-', 'Client'=>$r['thirdparty'] ?: '-']);
        }
        return $items;
    }

    private function salesAgent(): array
    {
        $items=[];
        foreach ($this->rows("SELECT p.rowid id, p.ref, p.total_ttc, p.datep, s.nom thirdparty
            FROM {$this->prefix}propal p LEFT JOIN {$this->prefix}societe s ON s.rowid=p.fk_soc
            WHERE p.fk_statut IN (1,2)
            ORDER BY p.datep ASC LIMIT 25") as $r) {
            $age = $r['datep'] ? floor((time()-strtotime($r['datep']))/86400) : 0;
            if ($age < 7) continue;
            $items[] = $this->rec('Commercial', $age>15?'warning':'info', 'proposal', (int)$r['id'], 'Devis sans réponse '.$r['ref'],
                ($r['thirdparty'] ?: 'Client') . ' — ' . $this->money($r['total_ttc']),
                'Préparer un message de suivi et proposer un appel.', min(90, 55+$age), ['Âge'=>$age.' jours', 'Montant'=>$this->money($r['total_ttc']), 'Client'=>$r['thirdparty'] ?: '-']);
        }
        return $items;
    }

    private function projectAgent(): array
    {
        $items=[];
        if (!$this->tableExists('projet')) return $items;
        foreach ($this->rows("SELECT rowid id, ref, title, dateo, datee, fk_statut FROM {$this->prefix}projet WHERE fk_statut IN (1,2) ORDER BY COALESCE(datee,dateo) ASC LIMIT 20") as $r) {
            $late = !empty($r['datee']) && strtotime($r['datee']) < strtotime('today');
            $items[] = $this->rec('Chantier', $late?'danger':'info', 'project', (int)$r['id'], $late?'Projet à vérifier '.$r['ref']:'Projet actif '.$r['ref'],
                $r['title'] ?: $r['ref'], $late?'Contrôler retard, documents et prochaines actions.':'Vérifier documents et tâches ouvertes.', $late?86:48,
                ['Titre'=>$r['title'] ?: '-', 'Début'=>$r['dateo'] ?: '-', 'Fin'=>$r['datee'] ?: '-']);
        }
        return $items;
    }

    private function managementAgent(): array
    {
        $items=[];
        $unpaid = $this->scalar("SELECT COALESCE(SUM(total_ttc),0) FROM {$this->prefix}facture WHERE fk_statut>0 AND paye=0");
        if ($unpaid > 0) $items[] = $this->rec('Direction','primary','management',0,'Synthèse encaissements ouverts', $this->money($unpaid).' à suivre', 'Afficher les priorités de relance et l’impact trésorerie.', 70, ['Total ouvert'=>$this->money($unpaid)]);
        $drafts = $this->scalar("SELECT COUNT(*) FROM {$this->prefix}propal WHERE fk_statut IN (0,1,2)");
        if ($drafts > 0) $items[] = $this->rec('Direction','info','management',0,'Portefeuille devis actif', $drafts.' devis à surveiller', 'Classer les devis par probabilité et ancienneté.', 58, ['Devis actifs'=>(string)$drafts]);
        return $items;
    }

    private function savAgent(): array
    {
        $items=[];
        if ($this->tableExists('ticket')) {
            foreach ($this->rows("SELECT rowid id, ref, subject FROM {$this->prefix}ticket WHERE fk_statut NOT IN (8,9) ORDER BY rowid DESC LIMIT 10") as $r) {
                $items[] = $this->rec('SAV','warning','ticket',(int)$r['id'],'Ticket SAV ouvert '.$r['ref'], $r['subject'] ?: '', 'Préparer suivi client ou tâche interne.', 65, ['Sujet'=>$r['subject'] ?: '-']);
            }
        }
        return $items;
    }

    private function rec(string $agent,string $level,string $type,int $id,string $title,string $subtitle,string $suggestion,int $score,array $meta=[]): array
    { return compact('agent','level','type','id','title','subtitle','suggestion','score','meta') + ['created_at'=>date('c')]; }

    private function summary(array $recs): array
    {
        return ['total'=>count($recs), 'urgent'=>count(array_filter($recs, fn($r)=>$r['level']==='danger')), 'recommended'=>count(array_filter($recs, fn($r)=>($r['score']??0)>=70)), 'simulation'=>'Toutes les actions sont en simulation par défaut.'];
    }

    private function agentsStatus(array $recs): array
    {
        $names=['Direction','Comptabilité','Commercial','Chantier','SAV']; $out=[];
        foreach($names as $n){ $cnt=count(array_filter($recs, fn($r)=>$r['agent']===$n)); $out[]=['name'=>$n,'count'=>$cnt,'status'=>$cnt?'Actif':'OK']; }
        return $out;
    }

    private function today(array $recs): array
    { return ['urgent'=>array_values(array_filter($recs, fn($r)=>$r['level']==='danger')), 'items'=>array_slice($recs,0,12)]; }

    private function journal(int $limit=20): array
    {
        $file=$this->root.'/storage/ai/journal.jsonl'; if(!is_file($file)) return [];
        $lines=array_slice(file($file, FILE_IGNORE_NEW_LINES|FILE_SKIP_EMPTY_LINES) ?: [], -$limit);
        return array_reverse(array_values(array_filter(array_map(fn($l)=>json_decode($l,true), $lines))));
    }

    private function appendJournal(string $agent,string $action,string $message,array $payload=[]): void
    {
        $dir=$this->root.'/storage/ai'; if(!is_dir($dir)) @mkdir($dir,0775,true);
        file_put_contents($dir.'/journal.jsonl', json_encode(['date'=>date('c'),'agent'=>$agent,'action'=>$action,'message'=>$message,'payload'=>$payload], JSON_UNESCAPED_UNICODE).PHP_EOL, FILE_APPEND);
    }

    private function rows(string $sql): array { try { return $this->pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC) ?: []; } catch(Throwable){ return []; } }
    private function scalar(string $sql): float { try { return (float)$this->pdo->query($sql)->fetchColumn(); } catch(Throwable){ return 0; } }
    private function money($v): string { return number_format((float)$v, 2, '.', "'") . ' CHF'; }
    private function tableExists(string $name): bool { try { $st=$this->pdo->prepare('SHOW TABLES LIKE ?'); $st->execute([$this->prefix.$name]); return (bool)$st->fetchColumn(); } catch(Throwable){ return false; } }
}
