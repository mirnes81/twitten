<?php
function twitten_private_ready(){ return true; }
