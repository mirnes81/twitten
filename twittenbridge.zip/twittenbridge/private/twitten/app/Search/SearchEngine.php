<?php
declare(strict_types=1);

namespace Twitten\Search;

use PDO;
use Throwable;

final class SearchEngine
{
    public function __construct(
        private readonly PDO $pdo,
        private readonly string $prefix = 'llx_',
        private readonly string $storageDir = __DIR__ . '/../../storage/search_index'
    ) {}

    public function search(string $query, int $limit = 50): array
    {
        $query = trim($query);
        if (mb_strlen($query) < 2) return [];

        $tokens = $this->tokens($query);
        $items = $this->loadIndex();
        if (!$items) {
            $items = $this->buildSmallLiveIndex($query);
        }

        $scored = [];
        foreach ($items as $item) {
            $score = $this->score($item, $tokens, $query);
            if ($score <= 0) continue;
            $item['_score'] = $score;
            $scored[] = $item;
        }

        usort($scored, static fn(array $a, array $b): int => ($b['_score'] <=> $a['_score']) ?: strcmp((string)($a['title'] ?? ''), (string)($b['title'] ?? '')));
        return array_slice(array_map([$this, 'publicItem'], $scored), 0, max(1, min(100, $limit)));
    }

    public function rebuild(int $limitPerType = 1500): array
    {
        $started = microtime(true);
        $items = [];
        foreach ($this->sources($limitPerType) as $source) {
            try {
                $stmt = $this->pdo->query($source['sql']);
                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    $items[] = $this->normalize($source['type'], $source['label'], $row);
                }
            } catch (Throwable $e) {
                $items[] = $this->errorItem($source['type'], $source['label'], $e->getMessage());
            }
        }
        if (!is_dir($this->storageDir)) @mkdir($this->storageDir, 0775, true);
        $payload = [
            'version' => 1,
            'built_at' => date('c'),
            'count' => count($items),
            'items' => $items,
        ];
        file_put_contents($this->indexFile(), json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT));
        return ['ok' => true, 'count' => count($items), 'seconds' => round(microtime(true) - $started, 3), 'file' => $this->indexFile()];
    }

    public function status(): array
    {
        $file = $this->indexFile();
        if (!is_file($file)) return ['exists' => false, 'count' => 0, 'built_at' => null, 'file' => $file];
        $json = json_decode((string)file_get_contents($file), true) ?: [];
        return ['exists' => true, 'count' => (int)($json['count'] ?? 0), 'built_at' => $json['built_at'] ?? null, 'file' => $file, 'size_kb' => round(filesize($file) / 1024, 1)];
    }

    private function sources(int $limit): array
    {
        $p = $this->prefix;
        $limit = max(50, min(10000, $limit));
        return [
            ['type'=>'thirdparty','label'=>'Client / tiers','sql'=>"SELECT s.rowid id, s.nom title, s.code_client ref, s.email, s.phone, s.town, s.zip, s.address, s.note_public, s.note_private, s.status, se.* FROM {$p}societe s LEFT JOIN {$p}societe_extrafields se ON se.fk_object=s.rowid WHERE s.entity IN (1) ORDER BY s.rowid DESC LIMIT {$limit}"],
            ['type'=>'product','label'=>'Produit / service','sql'=>"SELECT p.rowid id, p.ref, p.label title, p.description, p.price, p.tva_tx, p.stock, p.status, pe.* FROM {$p}product p LEFT JOIN {$p}product_extrafields pe ON pe.fk_object=p.rowid WHERE p.entity IN (1) ORDER BY p.rowid DESC LIMIT {$limit}"],
            ['type'=>'proposal','label'=>'Devis','sql'=>"SELECT d.rowid id, d.ref, d.ref_client, d.total_ht, d.total_ttc, d.fk_statut status, d.note_public, d.note_private, s.nom thirdparty, pr.ref project_ref, pr.title project_title, e.* FROM {$p}propal d LEFT JOIN {$p}societe s ON s.rowid=d.fk_soc LEFT JOIN {$p}projet pr ON pr.rowid=d.fk_project LEFT JOIN {$p}propal_extrafields e ON e.fk_object=d.rowid WHERE d.entity IN (1) ORDER BY d.rowid DESC LIMIT {$limit}"],
            ['type'=>'invoice','label'=>'Facture','sql'=>"SELECT d.rowid id, d.ref, d.ref_client, d.total_ht, d.total_ttc, d.fk_statut status, d.note_public, d.note_private, s.nom thirdparty, pr.ref project_ref, pr.title project_title, e.* FROM {$p}facture d LEFT JOIN {$p}societe s ON s.rowid=d.fk_soc LEFT JOIN {$p}projet pr ON pr.rowid=d.fk_project LEFT JOIN {$p}facture_extrafields e ON e.fk_object=d.rowid WHERE d.entity IN (1) ORDER BY d.rowid DESC LIMIT {$limit}"],
            ['type'=>'order','label'=>'Commande','sql'=>"SELECT d.rowid id, d.ref, d.ref_client, d.total_ht, d.total_ttc, d.fk_statut status, d.note_public, d.note_private, s.nom thirdparty, pr.ref project_ref, pr.title project_title, e.* FROM {$p}commande d LEFT JOIN {$p}societe s ON s.rowid=d.fk_soc LEFT JOIN {$p}projet pr ON pr.rowid=d.fk_project LEFT JOIN {$p}commande_extrafields e ON e.fk_object=d.rowid WHERE d.entity IN (1) ORDER BY d.rowid DESC LIMIT {$limit}"],
            ['type'=>'project','label'=>'Projet','sql'=>"SELECT p.rowid id, p.ref, p.title, p.description, p.budget_amount, p.dateo, p.datee, p.fk_statut status, e.* FROM {$p}projet p LEFT JOIN {$p}projet_extrafields e ON e.fk_object=p.rowid WHERE p.entity IN (1) ORDER BY p.rowid DESC LIMIT {$limit}"],
        ];
    }

    private function normalize(string $type, string $label, array $row): array
    {
        $title = (string)($row['title'] ?? $row['nom'] ?? $row['label'] ?? $row['ref'] ?? '');
        $ref = (string)($row['ref'] ?? $row['code_client'] ?? '');
        $haystack = mb_strtolower(implode(' ', array_map(static fn($v): string => is_scalar($v) ? (string)$v : '', $row)));
        $extra = [];
        foreach ($row as $k => $v) {
            if (in_array($k, ['id','rowid','fk_object','title','ref','ref_client','total_ht','total_ttc','status','note_public','note_private','thirdparty','project_ref','project_title','email','phone','town','zip','address','description','price','stock','tva_tx'], true)) continue;
            if ($v !== null && (string)$v !== '') $extra[$k] = (string)$v;
        }
        return [
            'id' => (int)($row['id'] ?? $row['rowid'] ?? 0),
            'type' => $type,
            'type_label' => $label,
            'ref' => $ref,
            'title' => $title,
            'subtitle' => (string)($row['thirdparty'] ?? $row['ref_client'] ?? $row['email'] ?? $row['description'] ?? ''),
            'amount' => $row['total_ttc'] ?? $row['price'] ?? $row['budget_amount'] ?? null,
            'status' => $row['status'] ?? null,
            'project_ref' => $row['project_ref'] ?? null,
            'project_title' => $row['project_title'] ?? null,
            'note_public' => $this->short($row['note_public'] ?? ''),
            'note_private' => $this->short($row['note_private'] ?? ''),
            'meta' => array_filter([
                'Réf.' => $ref,
                'Client' => $row['thirdparty'] ?? null,
                'Réf. client' => $row['ref_client'] ?? null,
                'Projet' => trim((string)($row['project_ref'] ?? '') . ' ' . (string)($row['project_title'] ?? '')),
                'Montant TTC' => $row['total_ttc'] ?? null,
                'Prix' => $row['price'] ?? null,
                'Ville' => $row['town'] ?? null,
                'Téléphone' => $row['phone'] ?? null,
                'Email' => $row['email'] ?? null,
                'Stock' => $row['stock'] ?? null,
                'Statut' => $row['status'] ?? null,
            ], static fn($v): bool => $v !== null && (string)$v !== ''),
            'extrafields' => $extra,
            '_haystack' => $haystack,
        ];
    }

    private function buildSmallLiveIndex(string $q): array
    {
        $like = '%' . str_replace(['%','_'], ['\\%','\\_'], $q) . '%';
        $p = $this->prefix;
        $items = [];
        $queries = [
            ['thirdparty','Client / tiers',"SELECT rowid id, nom title, code_client ref, email, phone, town, status FROM {$p}societe WHERE nom LIKE ? OR code_client LIKE ? OR email LIKE ? LIMIT 20"],
            ['product','Produit / service',"SELECT rowid id, ref, label title, description, price, stock, status FROM {$p}product WHERE ref LIKE ? OR label LIKE ? OR description LIKE ? LIMIT 20"],
            ['invoice','Facture',"SELECT f.rowid id, f.ref, f.ref_client, f.total_ttc, f.fk_statut status, s.nom thirdparty FROM {$p}facture f LEFT JOIN {$p}societe s ON s.rowid=f.fk_soc WHERE f.ref LIKE ? OR f.ref_client LIKE ? OR s.nom LIKE ? LIMIT 20"],
            ['proposal','Devis',"SELECT d.rowid id, d.ref, d.ref_client, d.total_ttc, d.fk_statut status, s.nom thirdparty FROM {$p}propal d LEFT JOIN {$p}societe s ON s.rowid=d.fk_soc WHERE d.ref LIKE ? OR d.ref_client LIKE ? OR s.nom LIKE ? LIMIT 20"],
            ['order','Commande',"SELECT c.rowid id, c.ref, c.ref_client, c.total_ttc, c.fk_statut status, s.nom thirdparty FROM {$p}commande c LEFT JOIN {$p}societe s ON s.rowid=c.fk_soc WHERE c.ref LIKE ? OR c.ref_client LIKE ? OR s.nom LIKE ? LIMIT 20"],
        ];
        foreach ($queries as [$type,$label,$sql]) {
            try {
                $stmt = $this->pdo->prepare($sql); $stmt->execute([$like,$like,$like]);
                foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) $items[] = $this->normalize($type, $label, $row);
            } catch (Throwable) {}
        }
        return $items;
    }

    private function tokens(string $q): array
    {
        $q = mb_strtolower(trim($q));
        return array_values(array_filter(preg_split('/\s+/u', $q) ?: [], static fn($t): bool => mb_strlen($t) >= 2));
    }

    private function score(array $item, array $tokens, string $query): int
    {
        $score = 0;
        $ref = mb_strtolower((string)($item['ref'] ?? ''));
        $title = mb_strtolower((string)($item['title'] ?? ''));
        $subtitle = mb_strtolower((string)($item['subtitle'] ?? ''));
        $hay = (string)($item['_haystack'] ?? '');
        $q = mb_strtolower($query);
        if ($ref !== '' && str_starts_with($ref, $q)) $score += 120;
        if ($title !== '' && str_starts_with($title, $q)) $score += 90;
        if ($ref === $q || $title === $q) $score += 160;
        foreach ($tokens as $t) {
            if ($ref !== '' && str_contains($ref, $t)) $score += 70;
            if ($title !== '' && str_contains($title, $t)) $score += 55;
            if ($subtitle !== '' && str_contains($subtitle, $t)) $score += 35;
            if ($hay !== '' && str_contains($hay, $t)) $score += 15;
        }
        return $score;
    }

    private function publicItem(array $item): array
    {
        unset($item['_haystack']);
        $item['label'] = $item['title'] ?? ($item['ref'] ?? '');
        return $item;
    }

    private function loadIndex(): array
    {
        $file = $this->indexFile();
        if (!is_file($file)) return [];
        $json = json_decode((string)file_get_contents($file), true);
        return is_array($json['items'] ?? null) ? $json['items'] : [];
    }

    private function indexFile(): string { return rtrim($this->storageDir, '/').'/dolibarr_search_index.json'; }
    private function short(mixed $v): string { return mb_substr(trim(strip_tags((string)$v)), 0, 500); }
    private function errorItem(string $type, string $label, string $error): array { return ['id'=>0,'type'=>$type,'type_label'=>$label,'ref'=>'','title'=>'Erreur index '.$label,'subtitle'=>$error,'_haystack'=>mb_strtolower($error),'meta'=>['Erreur'=>$error]]; }
}
