<?php
namespace Twitten\Dashboard;

use PDO;
use Throwable;

final class SmartDashboard
{
    public function __construct(private PDO $pdo, private string $prefix = 'llx_') {}

    public function overview(): array
    {
        return [
            'generated_at' => date('c'),
            'kpis' => $this->kpis(),
            'alerts' => $this->alerts(),
            'followups' => $this->followups(),
            'cashflow' => $this->cashflow(),
            'activity' => $this->recentActivity(),
        ];
    }

    private function kpis(): array
    {
        return [
            'unpaid_invoices' => $this->scalar("SELECT COUNT(*) FROM {$this->prefix}facture WHERE fk_statut > 0 AND paye = 0"),
            'unpaid_amount' => $this->money("SELECT COALESCE(SUM(total_ttc),0) FROM {$this->prefix}facture WHERE fk_statut > 0 AND paye = 0"),
            'open_proposals' => $this->scalar("SELECT COUNT(*) FROM {$this->prefix}propal WHERE fk_statut IN (1,2)"),
            'late_invoices' => $this->scalar("SELECT COUNT(*) FROM {$this->prefix}facture WHERE fk_statut > 0 AND paye = 0 AND date_lim_reglement IS NOT NULL AND date_lim_reglement < CURDATE()"),
            'active_projects' => $this->safeCount("{$this->prefix}projet", "WHERE fk_statut IN (1,2)")
        ];
    }

    private function alerts(): array
    {
        $alerts = [];
        foreach ($this->rows("SELECT f.rowid id, f.ref, f.total_ttc, f.date_lim_reglement, s.nom thirdparty
            FROM {$this->prefix}facture f LEFT JOIN {$this->prefix}societe s ON s.rowid=f.fk_soc
            WHERE f.fk_statut > 0 AND f.paye = 0 AND f.date_lim_reglement IS NOT NULL AND f.date_lim_reglement < CURDATE()
            ORDER BY f.date_lim_reglement ASC LIMIT 8") as $r) {
            $alerts[] = ['level'=>'danger','type'=>'invoice','id'=>$r['id'],'title'=>'Facture en retard '.$r['ref'],'subtitle'=>$r['thirdparty'] ?? '', 'amount'=>$this->formatMoney($r['total_ttc'] ?? 0), 'date'=>$r['date_lim_reglement'], 'action'=>'Relancer'];
        }
        foreach ($this->rows("SELECT p.rowid id, p.ref, p.total_ttc, p.datep, s.nom thirdparty
            FROM {$this->prefix}propal p LEFT JOIN {$this->prefix}societe s ON s.rowid=p.fk_soc
            WHERE p.fk_statut IN (1,2) AND p.datep < DATE_SUB(CURDATE(), INTERVAL 10 DAY)
            ORDER BY p.datep ASC LIMIT 8") as $r) {
            $alerts[] = ['level'=>'warning','type'=>'proposal','id'=>$r['id'],'title'=>'Devis sans réponse '.$r['ref'],'subtitle'=>$r['thirdparty'] ?? '', 'amount'=>$this->formatMoney($r['total_ttc'] ?? 0), 'date'=>$r['datep'], 'action'=>'Suivre'];
        }
        return array_slice($alerts, 0, 12);
    }

    private function followups(): array
    {
        $items = [];
        foreach ($this->rows("SELECT f.rowid id, f.ref, f.total_ttc, f.date_lim_reglement, s.nom thirdparty
            FROM {$this->prefix}facture f LEFT JOIN {$this->prefix}societe s ON s.rowid=f.fk_soc
            WHERE f.fk_statut > 0 AND f.paye = 0
            ORDER BY COALESCE(f.date_lim_reglement, f.datef) ASC LIMIT 10") as $r) {
            $items[] = ['type'=>'invoice','id'=>$r['id'],'ref'=>$r['ref'],'label'=>$r['thirdparty'] ?? '', 'amount'=>$this->formatMoney($r['total_ttc'] ?? 0), 'date'=>$r['date_lim_reglement'], 'priority'=>$this->priorityFromDate($r['date_lim_reglement'] ?? null)];
        }
        foreach ($this->rows("SELECT p.rowid id, p.ref, p.total_ttc, p.datep, s.nom thirdparty
            FROM {$this->prefix}propal p LEFT JOIN {$this->prefix}societe s ON s.rowid=p.fk_soc
            WHERE p.fk_statut IN (1,2)
            ORDER BY p.datep ASC LIMIT 10") as $r) {
            $items[] = ['type'=>'proposal','id'=>$r['id'],'ref'=>$r['ref'],'label'=>$r['thirdparty'] ?? '', 'amount'=>$this->formatMoney($r['total_ttc'] ?? 0), 'date'=>$r['datep'], 'priority'=>$this->priorityFromDate($r['datep'] ?? null, 10)];
        }
        usort($items, fn($a,$b)=>($b['priority_score'] ?? $this->scorePriority($b['priority'])) <=> ($a['priority_score'] ?? $this->scorePriority($a['priority'])));
        return array_slice($items, 0, 12);
    }

    private function cashflow(): array
    {
        $rows = $this->rows("SELECT DATE_FORMAT(COALESCE(date_lim_reglement,datef),'%Y-%m') month, SUM(total_ttc) amount
            FROM {$this->prefix}facture
            WHERE fk_statut > 0 AND paye = 0
            GROUP BY DATE_FORMAT(COALESCE(date_lim_reglement,datef),'%Y-%m')
            ORDER BY month ASC LIMIT 6");
        return array_map(fn($r)=>['month'=>$r['month'], 'amount'=>(float)$r['amount'], 'amount_label'=>$this->formatMoney($r['amount'])], $rows);
    }

    private function recentActivity(): array
    {
        $out = [];
        foreach ($this->rows("SELECT rowid id, ref, datef dt, total_ttc amount FROM {$this->prefix}facture ORDER BY rowid DESC LIMIT 5") as $r) {
            $out[] = ['type'=>'invoice','id'=>$r['id'],'title'=>'Facture '.$r['ref'],'date'=>$r['dt'],'amount'=>$this->formatMoney($r['amount'])];
        }
        foreach ($this->rows("SELECT rowid id, ref, datep dt, total_ttc amount FROM {$this->prefix}propal ORDER BY rowid DESC LIMIT 5") as $r) {
            $out[] = ['type'=>'proposal','id'=>$r['id'],'title'=>'Devis '.$r['ref'],'date'=>$r['dt'],'amount'=>$this->formatMoney($r['amount'])];
        }
        usort($out, fn($a,$b)=>strcmp((string)($b['date']??''), (string)($a['date']??'')));
        return array_slice($out,0,8);
    }

    private function rows(string $sql): array
    {
        try { return $this->pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC) ?: []; }
        catch (Throwable $e) { return []; }
    }
    private function scalar(string $sql): int
    {
        try { return (int)$this->pdo->query($sql)->fetchColumn(); }
        catch (Throwable $e) { return 0; }
    }
    private function money(string $sql): string
    {
        try { return $this->formatMoney((float)$this->pdo->query($sql)->fetchColumn()); }
        catch (Throwable $e) { return '0.00 CHF'; }
    }
    private function safeCount(string $table, string $where=''): int
    {
        try { return (int)$this->pdo->query("SELECT COUNT(*) FROM {$table} {$where}")->fetchColumn(); }
        catch (Throwable $e) { return 0; }
    }
    private function formatMoney(mixed $v): string { return number_format((float)$v, 2, '.', "'") . ' CHF'; }
    private function priorityFromDate(?string $date, int $ageDays = 0): string
    {
        if (!$date) return 'normal';
        $days = (strtotime(date('Y-m-d')) - strtotime(substr($date,0,10))) / 86400;
        if ($days > max(0,$ageDays)+15) return 'urgent';
        if ($days > max(0,$ageDays)) return 'high';
        return 'normal';
    }
    private function scorePriority(string $p): int { return ['urgent'=>3,'high'=>2,'normal'=>1][$p] ?? 0; }
}
