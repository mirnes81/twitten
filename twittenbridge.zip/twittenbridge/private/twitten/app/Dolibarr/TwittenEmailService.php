<?php
declare(strict_types=1);
namespace Twitten\Dolibarr;

use Twitten\Core\JsonStore;

final class TwittenEmailService
{
    private JsonStore $store;
    public function __construct(private readonly DolibarrApi $api, string $storageRoot)
    {
        $this->store = new JsonStore(rtrim($storageRoot, '/').'/config');
        $this->seedTemplates();
    }

    public function templates(): array { return $this->store->read('email_templates.json', []); }

    public function preview(string $type, int $id, string $templateKey): array
    {
        $detail = $this->api->detail($type, $id);
        $tpl = $this->templates()[$templateKey] ?? null;
        if (!$tpl) return ['ok'=>false, 'error'=>'Modèle e-mail introuvable.'];
        $subject = $this->renderText($tpl['subject'], $detail);
        $body = $this->renderText($tpl['body'], $detail);
        return ['ok'=>true, 'subject'=>$subject, 'body'=>$body, 'object'=>$detail, 'template'=>$tpl, 'status'=>'preview_only'];
    }

    public function queueEmail(string $type, int $id, string $templateKey, array $payload=[]): array
    {
        $preview = $this->preview($type, $id, $templateKey);
        if (!$preview['ok']) return $preview;
        $queueDir = dirname(__DIR__, 2).'/storage/queue';
        if (!is_dir($queueDir)) mkdir($queueDir, 0775, true);
        $item = ['id'=>'email_'.date('Ymd_His').'_'.bin2hex(random_bytes(3)), 'created_at'=>date('c'), 'type'=>$type, 'id_object'=>$id, 'template'=>$templateKey, 'to'=>$payload['to'] ?? '', 'subject'=>$preview['subject'], 'body'=>$preview['body'], 'status'=>'pending_manual_send'];
        file_put_contents($queueDir.'/'.$item['id'].'.json', json_encode($item, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE), LOCK_EX);
        return ['ok'=>true, 'message'=>'E-mail préparé dans la file Twitten. Aucun envoi automatique.', 'queue'=>$item];
    }

    private function renderText(string $text, array $detail): string
    {
        $o = $detail['object'] ?? [];
        return strtr($text, [
            '{{REF}}'=>(string)($o['ref'] ?? $o['name'] ?? ''),
            '{{CLIENT}}'=>(string)($o['thirdparty'] ?? $o['client'] ?? ''),
            '{{TOTAL_TTC}}'=>(string)($o['total_ttc'] ?? $o['total'] ?? ''),
            '{{DATE}}'=>date('d.m.Y'),
            '{{PROJECT}}'=>(string)($detail['project']['ref'] ?? $detail['project']['title'] ?? ''),
        ]);
    }

    private function seedTemplates(): void
    {
        if ($this->templates()) return;
        $this->store->write('email_templates.json', [
            'envoi_document'=>['name'=>'Envoi document', 'subject'=>'Votre document {{REF}}', 'body'=>"Bonjour,\n\nVeuillez trouver les informations concernant {{REF}}.\n\nClient : {{CLIENT}}\nProjet : {{PROJECT}}\nMontant TTC : {{TOTAL_TTC}}\n\nCordialement,\nMV-3 PRO"],
            'relance_paiement'=>['name'=>'Relance paiement', 'subject'=>'Rappel concernant {{REF}}', 'body'=>"Bonjour,\n\nNous nous permettons de revenir vers vous concernant {{REF}}.\n\nMontant TTC : {{TOTAL_TTC}}\n\nMerci d’avance pour votre retour.\n\nCordialement,\nMV-3 PRO"],
            'suivi_chantier'=>['name'=>'Suivi chantier', 'subject'=>'Suivi chantier {{PROJECT}}', 'body'=>"Bonjour,\n\nVoici un point de suivi pour le projet {{PROJECT}} lié à {{REF}}.\n\nCordialement,\nMV-3 PRO"],
        ]);
    }
}
