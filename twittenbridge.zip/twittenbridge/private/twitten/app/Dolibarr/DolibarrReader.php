<?php
namespace Twitten\Dolibarr;
use Twitten\Core\Config;
use PDO; use Throwable;
final class DolibarrReader {
    private Config $config;
    public function __construct(Config $config){ $this->config=$config; }
    private function pdo(): PDO {
        $host=$this->config->get('db_host'); $port=$this->config->get('db_port','3306');
        $db=$this->config->get('db_name'); $user=$this->config->get('db_user'); $pass=$this->config->get('db_pass');
        return new PDO("mysql:host=$host;port=$port;dbname=$db;charset=utf8mb4",$user,$pass,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);
    }
    public function stats(): array {
        $p=$this->config->get('db_prefix','llx_');
        try { $pdo=$this->pdo(); return [
            'Tiers'=>$this->count($pdo,$p.'societe'),
            'Produits'=>$this->count($pdo,$p.'product'),
            'Devis'=>$this->count($pdo,$p.'propal'),
            'Factures'=>$this->count($pdo,$p.'facture'),
        ]; } catch (Throwable $e) { return ['Connexion Dolibarr'=>'Erreur','Diagnostic'=>'À contrôler']; }
    }
    private function count(PDO $pdo,string $table): int { return (int)$pdo->query("SELECT COUNT(*) FROM `$table`")->fetchColumn(); }
    public function search(string $q): array {
        if (mb_strlen($q)<2) return [];
        $pdo=$this->pdo(); $p=$this->config->get('db_prefix','llx_'); $like='%'.$q.'%'; $out=[];
        $queries=[
            ['type'=>'Tiers','sql'=>"SELECT rowid id, code_client ref, nom label, '' amount FROM {$p}societe WHERE nom LIKE ? OR code_client LIKE ? ORDER BY rowid DESC LIMIT 8",'url'=>'/object.php?type=thirdparty&id='],
            ['type'=>'Produit','sql'=>"SELECT rowid id, ref, label, price amount FROM {$p}product WHERE ref LIKE ? OR label LIKE ? ORDER BY rowid DESC LIMIT 8",'url'=>'/object.php?type=product&id='],
            ['type'=>'Devis','sql'=>"SELECT rowid id, ref, ref_client label, total_ttc amount FROM {$p}propal WHERE ref LIKE ? OR ref_client LIKE ? ORDER BY rowid DESC LIMIT 8",'url'=>'/object.php?type=propal&id='],
            ['type'=>'Facture','sql'=>"SELECT rowid id, ref, ref_client label, total_ttc amount FROM {$p}facture WHERE ref LIKE ? OR ref_client LIKE ? ORDER BY rowid DESC LIMIT 8",'url'=>'/object.php?type=invoice&id='],
        ];
        foreach($queries as $def){ $st=$pdo->prepare($def['sql']); $st->execute([$like,$like]); foreach($st as $r){ $r['type']=$def['type']; $r['url']=$def['url'].$r['id']; $out[]=$r; } }
        return array_slice($out,0,20);
    }
}
