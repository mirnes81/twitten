<?php
declare(strict_types=1);

namespace Twitten\Dolibarr;

use PDO;
use Throwable;

final class DolibarrWriter
{
    public function __construct(
        private readonly PDO $pdo,
        private readonly string $prefix = 'llx_',
        private readonly string $storageRoot = __DIR__ . '/../../storage'
    ) {}

    public function execute(string $action, string $type, int $id, array $payload, bool $simulate = true): array
    {
        $allowed = ['add_note', 'create_task', 'prepare_reminder', 'change_status_request'];
        if (!in_array($action, $allowed, true)) {
            return $this->result(false, 'Action non autorisée.', $action, $type, $id, $simulate);
        }

        $object = $this->objectSnapshot($type, $id);
        if (!$object) return $this->result(false, 'Objet Dolibarr introuvable.', $action, $type, $id, $simulate);

        if ($simulate) {
            $entry = $this->audit($action, $type, $id, $payload, true, 'Simulation uniquement — aucune écriture Dolibarr.');
            return ['ok'=>true, 'simulated'=>true, 'message'=>'Simulation OK. Aucune donnée Dolibarr modifiée.', 'object'=>$object, 'audit'=>$entry];
        }

        try {
            return match ($action) {
                'add_note' => $this->addNote($type, $id, $payload, $object),
                'create_task' => $this->createTask($type, $id, $payload, $object),
                'prepare_reminder' => $this->prepareReminder($type, $id, $payload, $object),
                'change_status_request' => $this->changeStatusRequest($type, $id, $payload, $object),
                default => $this->result(false, 'Action inconnue.', $action, $type, $id, false),
            };
        } catch (Throwable $e) {
            $this->audit($action, $type, $id, $payload, false, 'Erreur: '.$e->getMessage());
            return ['ok'=>false, 'error'=>$e->getMessage()];
        }
    }

    private function addNote(string $type, int $id, array $payload, array $object): array
    {
        $note = trim((string)($payload['note'] ?? ''));
        $visibility = ($payload['visibility'] ?? 'private') === 'public' ? 'note_public' : 'note_private';
        if ($note === '') return ['ok'=>false, 'error'=>'Note vide.'];
        [$table] = $this->mapObject($type);
        $current = (string)($object[$visibility] ?? '');
        $stamp = date('Y-m-d H:i');
        $new = trim($current . "\n\n[Twitten {$stamp}] " . $note);
        $stmt = $this->pdo->prepare("UPDATE {$this->prefix}{$table} SET {$visibility}=:note WHERE rowid=:id");
        $stmt->execute([':note'=>$new, ':id'=>$id]);
        $entry = $this->audit('add_note', $type, $id, ['visibility'=>$visibility, 'note'=>$note], true, 'Note ajoutée dans Dolibarr.');
        return ['ok'=>true, 'message'=>'Note ajoutée dans Dolibarr.', 'audit'=>$entry];
    }

    private function createTask(string $type, int $id, array $payload, array $object): array
    {
        $label = trim((string)($payload['label'] ?? 'Tâche Twitten'));
        $note = trim((string)($payload['note'] ?? 'Créé depuis Twitten'));
        $dueDate = trim((string)($payload['due_date'] ?? ''));
        $fkProject = (int)($object['fk_project'] ?? 0);
        if ($type === 'project') $fkProject = $id;
        $datep = $dueDate !== '' ? strtotime($dueDate.' 09:00:00') : time();

        $sql = "INSERT INTO {$this->prefix}projet_task (fk_projet, label, description, datec, dateo, fk_statut, entity) VALUES (:project, :label, :description, :datec, :dateo, 0, 1)";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([':project'=>$fkProject ?: null, ':label'=>$label, ':description'=>$note, ':datec'=>time(), ':dateo'=>$datep]);
        $taskId = (int)$this->pdo->lastInsertId();
        $entry = $this->audit('create_task', $type, $id, ['task_id'=>$taskId, 'label'=>$label, 'due_date'=>$dueDate], true, 'Tâche créée dans Dolibarr.');
        return ['ok'=>true, 'message'=>'Tâche créée dans Dolibarr.', 'task_id'=>$taskId, 'audit'=>$entry];
    }

    private function prepareReminder(string $type, int $id, array $payload, array $object): array
    {
        $queueDir = rtrim($this->storageRoot, '/').'/queue';
        if (!is_dir($queueDir)) mkdir($queueDir, 0775, true);
        $item = [
            'id' => 'reminder_'.date('Ymd_His').'_'.bin2hex(random_bytes(3)),
            'created_at' => date('c'),
            'object_type' => $type,
            'object_id' => $id,
            'object_ref' => $object['ref'] ?? $object['name'] ?? '',
            'payload' => $payload,
            'status' => 'pending_validation',
        ];
        file_put_contents($queueDir.'/'.$item['id'].'.json', json_encode($item, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));
        $entry = $this->audit('prepare_reminder', $type, $id, $payload, true, 'Relance préparée dans la file Twitten.');
        return ['ok'=>true, 'message'=>'Relance préparée. Elle reste à valider avant envoi.', 'queue'=>$item, 'audit'=>$entry];
    }

    private function changeStatusRequest(string $type, int $id, array $payload, array $object): array
    {
        $queueDir = rtrim($this->storageRoot, '/').'/queue';
        if (!is_dir($queueDir)) mkdir($queueDir, 0775, true);
        $item = [
            'id' => 'status_'.date('Ymd_His').'_'.bin2hex(random_bytes(3)),
            'created_at' => date('c'),
            'object_type' => $type,
            'object_id' => $id,
            'object_ref' => $object['ref'] ?? $object['name'] ?? '',
            'requested_status' => $payload['status'] ?? '',
            'reason' => $payload['reason'] ?? '',
            'status' => 'pending_manual_validation',
        ];
        file_put_contents($queueDir.'/'.$item['id'].'.json', json_encode($item, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));
        $entry = $this->audit('change_status_request', $type, $id, $payload, true, 'Demande de changement de statut préparée, non appliquée.');
        return ['ok'=>true, 'message'=>'Demande préparée. Le statut Dolibarr n’est pas changé automatiquement.', 'queue'=>$item, 'audit'=>$entry];
    }

    private function objectSnapshot(string $type, int $id): array
    {
        [$table] = $this->mapObject($type);
        if ($table === '') return [];
        $stmt = $this->pdo->prepare("SELECT * FROM {$this->prefix}{$table} WHERE rowid=:id");
        $stmt->execute([':id'=>$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC) ?: [];
    }

    private function mapObject(string $type): array
    {
        return match ($type) {
            'thirdparty' => ['societe'],
            'product' => ['product'],
            'proposal' => ['propal'],
            'invoice' => ['facture'],
            'order' => ['commande'],
            'project' => ['projet'],
            default => [''],
        };
    }

    private function audit(string $action, string $type, int $id, array $payload, bool $ok, string $message): array
    {
        $logDir = rtrim($this->storageRoot, '/').'/logs';
        if (!is_dir($logDir)) mkdir($logDir, 0775, true);
        $entry = ['at'=>date('c'), 'action'=>$action, 'type'=>$type, 'id'=>$id, 'ok'=>$ok, 'message'=>$message, 'payload'=>$payload, 'ip'=>$_SERVER['REMOTE_ADDR'] ?? 'cli'];
        file_put_contents($logDir.'/actions.log', json_encode($entry, JSON_UNESCAPED_UNICODE).PHP_EOL, FILE_APPEND|LOCK_EX);
        return $entry;
    }

    private function result(bool $ok, string $message, string $action, string $type, int $id, bool $simulate): array
    {
        $entry = $this->audit($action, $type, $id, [], $ok, $message);
        return ['ok'=>$ok, 'simulated'=>$simulate, $ok ? 'message' : 'error'=>$message, 'audit'=>$entry];
    }
}
