<?php
declare(strict_types=1);

namespace Twitten\Dolibarr;

use PDO;
use RuntimeException;

final class DolibarrConfigDetector
{
    public function __construct(private readonly ?string $root = null) {}

    public function detect(?string $manualPath = null): array
    {
        $candidates = [];
        if ($manualPath) $candidates[] = rtrim($manualPath, '/');
        if ($this->root) {
            $candidates[] = rtrim($this->root, '/') . '/crm';
            $candidates[] = rtrim($this->root, '/') . '/dolibarr';
            $candidates[] = dirname(rtrim($this->root, '/')) . '/crm';
            $candidates[] = dirname(rtrim($this->root, '/')) . '/dolibarr';
        }
        $candidates[] = realpath(__DIR__ . '/../../../../crm') ?: '';
        $candidates[] = realpath(__DIR__ . '/../../../../dolibarr') ?: '';
        $candidates[] = '/htdocs/crm';
        $candidates[] = '/htdocs/dolibarr';

        foreach (array_unique(array_filter($candidates)) as $base) {
            $conf = rtrim((string)$base, '/') . '/conf/conf.php';
            if (is_file($conf) && is_readable($conf)) {
                return array_merge(['ok' => true, 'path' => rtrim((string)$base, '/'), 'conf' => $conf], $this->readConf($conf));
            }
        }
        throw new RuntimeException('conf/conf.php Dolibarr introuvable. Indiquer le chemin manuellement dans install.php.');
    }

    public function readConf(string $confFile): array
    {
        $dolibarr_main_db_host = 'localhost';
        $dolibarr_main_db_name = '';
        $dolibarr_main_db_user = '';
        $dolibarr_main_db_pass = '';
        $dolibarr_main_db_port = '3306';
        $dolibarr_main_db_prefix = 'llx_';
        include $confFile;

        return [
            'db_host' => (string)($dolibarr_main_db_host ?? 'localhost'),
            'db_port' => (string)($dolibarr_main_db_port ?? '3306'),
            'db_name' => (string)($dolibarr_main_db_name ?? ''),
            'db_user' => (string)($dolibarr_main_db_user ?? ''),
            'db_pass' => (string)($dolibarr_main_db_pass ?? ''),
            'db_prefix' => (string)($dolibarr_main_db_prefix ?? 'llx_'),
        ];
    }

    public function pdo(array $config): PDO
    {
        $dsn = sprintf('mysql:host=%s;port=%s;dbname=%s;charset=utf8mb4', $config['db_host'], $config['db_port'], $config['db_name']);
        return new PDO($dsn, $config['db_user'], $config['db_pass'], [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);
    }
}
