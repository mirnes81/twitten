<?php
declare(strict_types=1);
namespace Twitten\Dolibarr;

use Twitten\Core\JsonStore;

final class TwittenDocumentService
{
    private JsonStore $store;
    private string $docRoot;

    public function __construct(private readonly DolibarrApi $api, string $storageRoot)
    {
        $this->store = new JsonStore(rtrim($storageRoot, '/').'/config');
        $this->docRoot = rtrim($storageRoot, '/').'/documents';
        if (!is_dir($this->docRoot)) mkdir($this->docRoot, 0775, true);
        $this->seedTemplates();
    }

    public function templates(): array
    {
        return $this->store->read('document_templates.json', []);
    }

    public function preview(string $type, int $id, string $templateKey): array
    {
        $detail = $this->api->detail($type, $id);
        $template = $this->templates()[$templateKey] ?? null;
        if (!$template) return ['ok'=>false, 'error'=>'Modèle introuvable.'];
        $html = $this->render($template['html'], $detail);
        return ['ok'=>true, 'html'=>$html, 'object'=>$detail, 'template'=>$template];
    }

    public function createHtmlDocument(string $type, int $id, string $templateKey): array
    {
        $preview = $this->preview($type, $id, $templateKey);
        if (!$preview['ok']) return $preview;
        $ref = preg_replace('/[^a-zA-Z0-9_\-]/', '_', (string)($preview['object']['ref'] ?? $preview['object']['name'] ?? $id));
        $filename = date('Ymd_His')."_{$type}_{$ref}.html";
        file_put_contents($this->docRoot.'/'.$filename, $preview['html']);
        $this->logDocument($type, $id, $templateKey, $filename);
        return ['ok'=>true, 'message'=>'Document HTML généré.', 'file'=>'storage/documents/'.$filename, 'filename'=>$filename, 'html'=>$preview['html']];
    }

    private function render(string $html, array $detail): string
    {
        $object = $detail['object'] ?? [];
        $lines = $detail['lines'] ?? [];
        $vars = [
            '{{REF}}' => htmlspecialchars((string)($object['ref'] ?? $object['name'] ?? ''), ENT_QUOTES, 'UTF-8'),
            '{{LABEL}}' => htmlspecialchars((string)($object['label'] ?? $object['name'] ?? ''), ENT_QUOTES, 'UTF-8'),
            '{{THIRDPARTY}}' => htmlspecialchars((string)($object['thirdparty'] ?? $object['client'] ?? ''), ENT_QUOTES, 'UTF-8'),
            '{{TOTAL_TTC}}' => htmlspecialchars((string)($object['total_ttc'] ?? $object['total'] ?? ''), ENT_QUOTES, 'UTF-8'),
            '{{DATE}}' => date('d.m.Y'),
            '{{NOTE_PUBLIC}}' => nl2br(htmlspecialchars((string)($object['note_public'] ?? ''), ENT_QUOTES, 'UTF-8')),
            '{{NOTE_PRIVATE}}' => nl2br(htmlspecialchars((string)($object['note_private'] ?? ''), ENT_QUOTES, 'UTF-8')),
            '{{PROJECT}}' => htmlspecialchars((string)($detail['project']['ref'] ?? $detail['project']['title'] ?? ''), ENT_QUOTES, 'UTF-8'),
        ];
        $rows = '';
        foreach ($lines as $line) {
            $rows .= '<tr><td>'.htmlspecialchars((string)($line['description'] ?? $line['label'] ?? ''), ENT_QUOTES, 'UTF-8').'</td><td>'.htmlspecialchars((string)($line['qty'] ?? ''), ENT_QUOTES, 'UTF-8').'</td><td>'.htmlspecialchars((string)($line['subprice'] ?? ''), ENT_QUOTES, 'UTF-8').'</td><td>'.htmlspecialchars((string)($line['total_ttc'] ?? ''), ENT_QUOTES, 'UTF-8').'</td></tr>';
        }
        $vars['{{LINES}}'] = $rows ?: '<tr><td colspan="4" class="text-muted">Aucune ligne disponible.</td></tr>';
        return strtr($html, $vars);
    }

    private function logDocument(string $type, int $id, string $templateKey, string $filename): void
    {
        $log = $this->store->read('documents_log.json', []);
        $log[] = ['at'=>date('c'), 'type'=>$type, 'id'=>$id, 'template'=>$templateKey, 'filename'=>$filename];
        $this->store->write('documents_log.json', $log);
    }

    private function seedTemplates(): void
    {
        if ($this->templates()) return;
        $base = '<!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"><title>{{REF}}</title><style>body{background:#f6f7fb}.doc{max-width:980px;margin:30px auto;background:white;border-radius:24px;padding:42px;box-shadow:0 20px 60px #0001}.brand{font-size:28px;font-weight:800}.muted{color:#64748b}.table td,.table th{vertical-align:top}.note{background:#f8fafc;border:1px solid #e2e8f0;border-radius:16px;padding:16px}</style></head><body><main class="doc"><div class="d-flex justify-content-between align-items-start mb-4"><div><div class="brand">Twitten / MV-3 PRO</div><div class="muted">Document généré depuis Dolibarr</div></div><div class="text-end"><strong>{{REF}}</strong><br><span class="muted">{{DATE}}</span></div></div><hr><h1 class="h3 mb-1">{{LABEL}}</h1><p class="muted mb-4">Client : {{THIRDPARTY}} · Projet : {{PROJECT}}</p><table class="table"><thead><tr><th>Description</th><th>Qté</th><th>Prix</th><th>Total</th></tr></thead><tbody>{{LINES}}</tbody></table><div class="row g-3 mt-4"><div class="col-md-6"><div class="note"><strong>Note publique</strong><div>{{NOTE_PUBLIC}}</div></div></div><div class="col-md-6"><div class="note"><strong>Suivi interne</strong><div>{{NOTE_PRIVATE}}</div></div></div></div><div class="text-end mt-4"><span class="muted">Total TTC</span><h2>{{TOTAL_TTC}}</h2></div></main></body></html>';
        $this->store->write('document_templates.json', [
            'standard' => ['name'=>'Document standard', 'description'=>'Aperçu Bootstrap propre pour devis/facture/commande.', 'html'=>$base],
            'relance' => ['name'=>'Relance client', 'description'=>'Document de relance basé sur les données Dolibarr.', 'html'=>str_replace('Document généré depuis Dolibarr', 'Relance préparée depuis Twitten', $base)],
            'chantier' => ['name'=>'Fiche chantier', 'description'=>'Fiche projet/chantier lisible avec notes et lignes.', 'html'=>str_replace('Client : {{THIRDPARTY}} · Projet : {{PROJECT}}', 'Fiche chantier · Projet : {{PROJECT}} · Client : {{THIRDPARTY}}', $base)],
        ]);
    }
}
