<?php
declare(strict_types=1);

namespace Twitten\Dolibarr;

use PDO;
use Throwable;

final class DolibarrApi
{
    public function __construct(private readonly PDO $pdo, private readonly string $prefix = 'llx_') {}

    public function stats(): array
    {
        return [
            'thirdparties' => $this->safeCount('societe'),
            'products' => $this->safeCount('product'),
            'proposals' => $this->safeCount('propal'),
            'invoices' => $this->safeCount('facture'),
            'orders' => $this->safeCount('commande'),
            'projects' => $this->safeCount('projet'),
        ];
    }

    public function globalSearch(string $q, int $limit = 40): array
    {
        if (mb_strlen($q) < 2) return [];
        $items = [];
        foreach ([
            ['thirdparties','thirdparty','Client / tiers','name'],
            ['products','product','Produit / service','ref'],
            ['proposals','proposal','Devis','ref'],
            ['invoices','invoice','Facture','ref'],
            ['orders','order','Commande','ref'],
            ['projects','project','Projet','ref'],
        ] as [$listType,$single,$label,$main]) {
            foreach ($this->list($listType, $q, 8) as $row) {
                $row['type'] = $single;
                $row['type_label'] = $label;
                $row['meta'] = $this->metaFor($single, $row);
                $items[] = $row;
            }
        }
        return array_slice($items, 0, max(1, min(80, $limit)));
    }

    public function renderDetailHtml(array $data, string $type): string
    {
        if (!($data['ok'] ?? false)) return '<div class="alert alert-warning">Fiche introuvable.</div>';
        $o = $data['object'] ?? [];
        $title = $this->e($o['ref'] ?? $o['name'] ?? $o['nom'] ?? $o['label'] ?? ('#'.($o['rowid'] ?? '')));
        $subtitle = $this->e($o['thirdparty'] ?? $o['label'] ?? $o['title'] ?? $o['email'] ?? '');
        $html = '<div class="d-grid gap-3"><div><span class="badge text-bg-primary">'.htmlspecialchars($type).'</span><h3 class="mt-2 mb-1">'.$title.'</h3><div class="text-muted">'.$subtitle.'</div></div>';
        $html .= '<div class="tw-meta">';
        foreach (['ref'=>'Réf.','ref_client'=>'Réf. client','total_ht'=>'HT','total_ttc'=>'TTC','status'=>'Statut','datec'=>'Créé','email'=>'Email','phone'=>'Téléphone','town'=>'Ville','project_ref'=>'Projet'] as $k=>$label) {
            if (isset($o[$k]) && (string)$o[$k] !== '') $html .= '<div><dt>'.$this->e($label).'</dt><dd>'.$this->e((string)$o[$k]).'</dd></div>';
        }
        $html .= '</div>';
        foreach (['note_public'=>'Note publique','note_private'=>'Note privée','description'=>'Description'] as $k=>$label) {
            if (!empty($o[$k])) $html .= '<div class="alert alert-light border"><strong>'.$this->e($label).'</strong><br>'.$this->e(strip_tags((string)$o[$k])).'</div>';
        }
        if (!empty($data['extrafields'])) {
            $html .= '<h6>Extrafields</h6><div>';
            foreach ($data['extrafields'] as $k=>$v) if ($k !== 'rowid' && $k !== 'fk_object' && (string)$v !== '') $html .= '<span class="tw-pill"><strong>'.$this->e((string)$k).'</strong> '.$this->e((string)$v).'</span>';
            $html .= '</div>';
        }
        if (!empty($data['lines'])) {
            $html .= '<h6>Lignes</h6><div class="tw-lines">';
            foreach (array_slice($data['lines'],0,12) as $line) $html .= '<div class="tw-line"><div>'.$this->e(strip_tags((string)($line['description'] ?? ''))).'</div><small class="text-muted">Qté '.$this->e((string)($line['qty'] ?? '')).' · PU '.$this->e((string)($line['subprice'] ?? '')).' · HT '.$this->e((string)($line['total_ht'] ?? '')).'</small></div>';
            $html .= '</div>';
        }
        $html .= '</div>';
        return $html;
    }


    public function list(string $type, string $q = '', int $limit = 30): array
    {
        return match ($type) {
            'thirdparties' => $this->thirdparties($q, $limit),
            'products' => $this->products($q, $limit),
            'proposals' => $this->documents('propal', 'propal', $q, $limit),
            'invoices' => $this->documents('facture', 'facture', $q, $limit),
            'orders' => $this->documents('commande', 'commande', $q, $limit),
            'projects' => $this->projects($q, $limit),
            default => [],
        };
    }

    public function detail(string $type, int $id): array
    {
        return match ($type) {
            'thirdparty' => $this->thirdpartyDetail($id),
            'product' => $this->productDetail($id),
            'proposal' => $this->documentDetail('propal', 'propaldet', $id),
            'invoice' => $this->documentDetail('facture', 'facturedet', $id),
            'order' => $this->documentDetail('commande', 'commandedet', $id),
            'project' => $this->projectDetail($id),
            default => ['ok' => false, 'error' => 'Type inconnu'],
        };
    }

    private function thirdparties(string $q, int $limit): array
    {
        $sql = "SELECT rowid id, nom name, code_client code, email, phone, town, zip, address, status FROM {$this->prefix}societe WHERE entity IN (1)";
        $params = [];
        if ($q !== '') { $sql .= " AND (nom LIKE :q OR code_client LIKE :q OR email LIKE :q OR town LIKE :q)"; $params[':q'] = "%$q%"; }
        $sql .= " ORDER BY nom ASC LIMIT " . max(1, min(100, $limit));
        return $this->fetchAll($sql, $params);
    }

    private function products(string $q, int $limit): array
    {
        $sql = "SELECT rowid id, ref, label, description, price, tva_tx, stock, status FROM {$this->prefix}product WHERE entity IN (1)";
        $params = [];
        if ($q !== '') { $sql .= " AND (ref LIKE :q OR label LIKE :q OR description LIKE :q)"; $params[':q'] = "%$q%"; }
        $sql .= " ORDER BY ref ASC LIMIT " . max(1, min(100, $limit));
        return $this->fetchAll($sql, $params);
    }

    private function documents(string $table, string $type, string $q, int $limit): array
    {
        $sql = "SELECT d.rowid id, d.ref, d.ref_client, d.total_ht, d.total_ttc, d.fk_statut status, d.note_public, d.note_private, s.nom thirdparty
                FROM {$this->prefix}{$table} d
                LEFT JOIN {$this->prefix}societe s ON s.rowid=d.fk_soc
                WHERE d.entity IN (1)";
        $params = [];
        if ($q !== '') { $sql .= " AND (d.ref LIKE :q OR d.ref_client LIKE :q OR s.nom LIKE :q OR d.note_public LIKE :q OR d.note_private LIKE :q)"; $params[':q'] = "%$q%"; }
        $sql .= " ORDER BY d.rowid DESC LIMIT " . max(1, min(100, $limit));
        return $this->fetchAll($sql, $params);
    }

    private function projects(string $q, int $limit): array
    {
        $sql = "SELECT rowid id, ref, title, description, budget_amount, dateo, datee, fk_statut status FROM {$this->prefix}projet WHERE entity IN (1)";
        $params = [];
        if ($q !== '') { $sql .= " AND (ref LIKE :q OR title LIKE :q OR description LIKE :q)"; $params[':q'] = "%$q%"; }
        $sql .= " ORDER BY rowid DESC LIMIT " . max(1, min(100, $limit));
        return $this->fetchAll($sql, $params);
    }

    private function documentDetail(string $table, string $lineTable, int $id): array
    {
        $doc = $this->fetchOne("SELECT d.*, s.nom thirdparty, p.ref project_ref, p.title project_title FROM {$this->prefix}{$table} d LEFT JOIN {$this->prefix}societe s ON s.rowid=d.fk_soc LEFT JOIN {$this->prefix}projet p ON p.rowid=d.fk_project WHERE d.rowid=:id", [':id'=>$id]);
        $lines = $this->fetchAll("SELECT rowid, description, qty, subprice, total_ht, tva_tx, product_type, fk_product FROM {$this->prefix}{$lineTable} WHERE fk_{$table}=:id ORDER BY rang,rowid", [':id'=>$id]);
        return ['ok'=>true, 'object'=>$doc, 'lines'=>$lines, 'extrafields'=>$this->extrafields($table, $id)];
    }

    private function thirdpartyDetail(int $id): array
    {
        return ['ok'=>true, 'object'=>$this->fetchOne("SELECT * FROM {$this->prefix}societe WHERE rowid=:id", [':id'=>$id]), 'extrafields'=>$this->extrafields('societe', $id)];
    }

    private function productDetail(int $id): array
    {
        return ['ok'=>true, 'object'=>$this->fetchOne("SELECT * FROM {$this->prefix}product WHERE rowid=:id", [':id'=>$id]), 'extrafields'=>$this->extrafields('product', $id)];
    }

    private function projectDetail(int $id): array
    {
        return ['ok'=>true, 'object'=>$this->fetchOne("SELECT * FROM {$this->prefix}projet WHERE rowid=:id", [':id'=>$id]), 'extrafields'=>$this->extrafields('projet', $id)];
    }

    private function extrafields(string $element, int $id): array
    {
        $table = match ($element) {
            'societe' => 'societe_extrafields',
            'product' => 'product_extrafields',
            'projet' => 'projet_extrafields',
            'propal' => 'propal_extrafields',
            'facture' => 'facture_extrafields',
            'commande' => 'commande_extrafields',
            default => '',
        };
        if ($table === '') return [];
        try { return $this->fetchOne("SELECT * FROM {$this->prefix}{$table} WHERE fk_object=:id", [':id'=>$id]) ?: []; }
        catch (Throwable) { return []; }
    }


    private function safeCount(string $table): int
    {
        try { return (int)$this->pdo->query("SELECT COUNT(*) FROM {$this->prefix}{$table} WHERE entity IN (1)")->fetchColumn(); }
        catch (Throwable) { try { return (int)$this->pdo->query("SELECT COUNT(*) FROM {$this->prefix}{$table}")->fetchColumn(); } catch (Throwable) { return 0; } }
    }

    private function metaFor(string $type, array $row): array
    {
        return array_filter([
            'Client' => $row['thirdparty'] ?? $row['name'] ?? null,
            'Réf.' => $row['ref'] ?? $row['code'] ?? null,
            'Réf. client' => $row['ref_client'] ?? null,
            'Montant TTC' => $row['total_ttc'] ?? null,
            'Prix' => $row['price'] ?? null,
            'Ville' => $row['town'] ?? null,
            'Statut' => $row['status'] ?? null,
        ], fn($v) => $v !== null && $v !== '');
    }

    private function e(string $value): string
    {
        return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }

    private function fetchAll(string $sql, array $params = []): array
    {
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
    }

    private function fetchOne(string $sql, array $params = []): array
    {
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetch(PDO::FETCH_ASSOC) ?: [];
    }
}
