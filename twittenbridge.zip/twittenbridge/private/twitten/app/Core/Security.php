<?php
declare(strict_types=1);

namespace Twitten\Core;

final class Security
{
    public static function csrfToken(): string
    {
        if (session_status() !== PHP_SESSION_ACTIVE) session_start();
        if (empty($_SESSION['twitten_csrf'])) $_SESSION['twitten_csrf'] = bin2hex(random_bytes(32));
        return (string) $_SESSION['twitten_csrf'];
    }

    public static function requireCsrf(): void
    {
        if (session_status() !== PHP_SESSION_ACTIVE) session_start();
        $expected = $_SESSION['twitten_csrf'] ?? '';
        $received = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? ($_POST['csrf'] ?? '');
        if (!is_string($expected) || $expected === '' || !hash_equals($expected, (string) $received)) {
            self::json(['ok'=>false, 'error'=>'Protection CSRF invalide. Recharge la page.'], 419);
        }
    }

    public static function writeEnabled(): bool
    {
        return self::env('TWITTEN_WRITE_MODE', 'readonly') === 'enabled';
    }
    public static function env(string $key, ?string $default = null): ?string
    {
        $value = getenv($key);
        return $value === false ? $default : $value;
    }

    public static function requireReadOnly(): void
    {
        $mode = self::env('TWITTEN_WRITE_MODE', 'readonly');
        if ($mode !== 'enabled') {
            http_response_code(403);
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(['ok' => false, 'error' => 'Mode lecture seule actif. Ecriture Dolibarr bloquee.'], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
            exit;
        }
    }

    public static function requireBridgeToken(): void
    {
        $expected = self::env('TWITTEN_BRIDGE_TOKEN', 'change-me');
        $received = $_SERVER['HTTP_X_TWITTEN_TOKEN'] ?? ($_GET['token'] ?? '');
        if (!hash_equals($expected, (string) $received)) {
            http_response_code(401);
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(['ok' => false, 'error' => 'Token bridge invalide.'], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
            exit;
        }
    }

    public static function json(array $payload, int $status = 200): never
    {
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        exit;
    }
}
