<?php
namespace Twitten\Core;
final class App {
    private Config $config;
    private function __construct(){ $this->config = new Config(); }
    public static function boot(): self { return new self(); }
    public function config(): Config { return $this->config; }
}
