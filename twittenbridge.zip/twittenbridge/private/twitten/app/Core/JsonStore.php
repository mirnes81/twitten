<?php
declare(strict_types=1);
namespace Twitten\Core;

final class JsonStore
{
    public function __construct(private readonly string $root) {}

    public function path(string $name): string
    {
        $safe = preg_replace('/[^a-zA-Z0-9_\-\.]/', '_', $name);
        if (!is_dir($this->root)) mkdir($this->root, 0775, true);
        return rtrim($this->root, '/').'/'.$safe;
    }

    public function read(string $name, array $default = []): array
    {
        $path = $this->path($name);
        if (!is_file($path)) return $default;
        $data = json_decode((string)file_get_contents($path), true);
        return is_array($data) ? $data : $default;
    }

    public function write(string $name, array $data): void
    {
        file_put_contents($this->path($name), json_encode($data, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE), LOCK_EX);
    }
}
