<?php
if (session_status() !== PHP_SESSION_ACTIVE) { @session_start(); }
spl_autoload_register(function($class){
    $prefix='Twitten\\';
    if (strncmp($class,$prefix,strlen($prefix))!==0) return;
    $rel=str_replace('\\','/',substr($class,strlen($prefix)));
    $file=__DIR__.'/../'.$rel.'.php';
    if (is_file($file)) require $file;
});
