<?php
namespace Twitten\Core;
final class Config {
    private string $file;
    private array $data=[];
    public function __construct(){
        $this->file=__DIR__.'/../../storage/config/twitten.php';
        if (is_file($this->file)) $this->data=require $this->file;
    }
    public function isInstalled(): bool { return !empty($this->data['installed']); }
    public function get(string $key, mixed $default=null): mixed { return $this->data[$key] ?? $default; }
    public function write(array $data): void {
        $data['installed']=true;
        $content="<?php\nreturn ".var_export($data,true).";\n";
        if (!is_dir(dirname($this->file))) mkdir(dirname($this->file),0775,true);
        file_put_contents($this->file,$content,LOCK_EX);
    }
}
