Twitten private application folder. Must stay outside public_html.
