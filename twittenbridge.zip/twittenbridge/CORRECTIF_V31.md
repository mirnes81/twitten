# Twitten Bridge Propal Cockpit V3.1

## Correctif principal
- Compatibilité Dolibarr avec la colonne native `fk_projet`.
- Détection automatique de `fk_projet` ou `fk_project` pour éviter les erreurs SQL selon la version.
- Correction des recherches, fiches, projets liés et mise à jour des métadonnées.
- Le champ envoyé par l’interface reste `fk_project` pour préserver la compatibilité frontend.

## Installation
Remplacer les fichiers de la version précédente en conservant la configuration et la clé API.
