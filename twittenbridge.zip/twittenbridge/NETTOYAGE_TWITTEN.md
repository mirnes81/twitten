# Twitten Bridge — version nettoyée et renforcée

## Ce qui a été corrigé

- Correction de la séparation entre Twitten et Dolibarr : Twitten reste une interface moderne, Dolibarr reste le moteur ERP.
- Correction du Bridge : l’interface appelait `list`, `detail` et `search`, mais le bridge ne répondait pas correctement à toutes ces actions.
- Ajout d’une compatibilité propre pour : clients, devis, factures, commandes, projets et produits.
- Correction des fiches : `object.php?type=propal&id=...` et `object.php?type=invoice&id=...` retournent maintenant document + lignes.
- Correction des actions réelles : note, tâche, relance, génération PDF, ajout/modification/suppression de lignes.
- Passage des actions sensibles en POST depuis Twitten pour éviter les URLs trop longues et les descriptions coupées.
- Nettoyage de l’ancien `/custom/twittenbridge/api.php` : il redirige maintenant proprement vers `/api/api.php`.
- Correction affichage clients : nom/code client au lieu de champs inexistants.
- Correction affichage factures : état payé/à suivre basé sur `paye`.
- Correction affichage dates devis/factures.

## Installation

1. Dans Dolibarr : remplacer le dossier `htdocs/custom/twittenbridge` par le dossier `twittenbridge` du ZIP.
2. Dans le site Twitten : remplacer les fichiers du dossier `public_html`.
3. Garder ou recréer la config dans `software_data/twitten/config/config.php` ou `private/twitten/config/config.php`.
4. Tester : `https://crm.mv-3pro.ch/custom/twittenbridge/api/api.php?action=ping&key=VOTRE_CLE`
5. Tester Twitten : `bridge-test.php`, puis clients/devis/factures.

## Important sécurité

- Le module ne modifie pas le core Dolibarr.
- Les écritures passent par le bridge avec clé API.
- Les factures validées bloquent la modification de lignes, sauf suppression déjà protégée côté Dolibarr.
- Aucun e-mail automatique n’est envoyé sans validation.
