# Twitten Bridge – Correctif V3.2 Schema Safe

## Erreurs corrigées

- `Unknown column 'required' in field list` : la définition des extrafields ne suppose plus que la colonne `required` existe.
- Compatibilité automatique avec `required` ou `mandatory`.
- Compatibilité automatique avec `pos`, `position` ou `rang`.
- Compatibilité automatique avec `enabled` ou `active`.
- Correction définitive du lien projet avec `fk_projet` ou `fk_project`.
- Correction de l'enregistrement du projet depuis le formulaire Twitten (`fk_project`).
- Les blocs secondaires (contacts, événements et listes de configuration) ne bloquent plus toute la fiche si une colonne optionnelle diffère.
- Les listes conditions de paiement, modes de paiement, disponibilités et origines sont maintenant construites selon le schéma réellement installé.

## Diagnostic

Le bridge expose maintenant l'action :

`api.php?action=propal_schema_diagnostic&key=VOTRE_CLE`

Elle retourne uniquement les tables/colonnes détectées et permet de diagnostiquer une future différence de version Dolibarr sans casser la fiche.

## Installation

1. Sauvegarder l'ancien dossier `custom/twittenbridge`.
2. Remplacer le dossier `twittenbridge` côté Dolibarr.
3. Remplacer les fichiers du site Twitten par le contenu de `public_html`.
4. Conserver la configuration et la clé API existantes.
5. Vider le cache PHP/OPcache si l'hébergeur le permet.
6. Tester `bridge-test.php`, puis ouvrir une fiche devis.
