<?php
require_once __DIR__.'/app.php';
$type=strtolower((string)($_GET['type']??'propal')); $id=(int)($_GET['id']??0);
if(!in_array($type,['propal','proposal','devis'],true)){
    $j=tw_bridge('detail',['type'=>$type,'id'=>$id]); $o=$j['object']??[]; $lines=$j['lines']??[]; layout_start('Fiche '.ucfirst($type));
    if(empty($j['ok'])) echo '<div class="alert alert-danger">'.h($j['error']??'Erreur').'</div>';
    else { echo '<div class="cardx p-4"><h2>'.h($o['ref']??$o['nom']??'Fiche').'</h2><pre>'.h(json_encode($o,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)).'</pre></div>'; }
    layout_end(); exit;
}
$j=tw_bridge('propal_cockpit',['id'=>$id]); $d=$j['doc']??[]; $lines=$j['lines']??[];
layout_start('Cockpit devis');
if(empty($j['ok'])){ echo '<div class="alert alert-danger">'.h($j['error']??'Impossible de charger le devis').'</div>'; layout_end(); exit; }
$status=$d['status_info']??['label'=>'Statut','class'=>'secondary'];
function tw_date_input($v){return $v?substr((string)$v,0,10):'';}
?>
<div id="toastZone" class="position-fixed top-0 end-0 p-3" style="z-index:1080"></div>
<div class="propal-commandbar cardx mb-3">
  <div class="d-flex flex-wrap gap-2 align-items-center justify-content-between p-3">
    <div class="d-flex align-items-center gap-3">
      <div class="doc-icon"><i class="bi bi-file-earmark-text"></i></div>
      <div><div class="small text-muted">DEVIS DOLIBARR</div><h2 class="mb-0"><?=h($d['ref']??'')?></h2></div>
      <span class="badge text-bg-<?=h($status['class'])?> rounded-pill px-3 py-2"><?=h($status['label'])?></span>
    </div>
    <div class="d-flex flex-wrap gap-2">
      <a target="_blank" class="btn btn-outline-dark" href="<?=h($d['dolibarr_url']??'#')?>"><i class="bi bi-box-arrow-up-right"></i> Ouvrir Dolibarr</a>
      <button class="btn btn-outline-primary" onclick="generatePdf()"><i class="bi bi-filetype-pdf"></i> Générer PDF</button>
      <?php if((int)($d['status']??0)===0): ?><button class="btn btn-primary" onclick="statusAction('validate')"><i class="bi bi-check2-circle"></i> Valider</button><?php endif; ?>
      <?php if((int)($d['status']??0)===1): ?><button class="btn btn-success" onclick="statusAction('accept')"><i class="bi bi-hand-thumbs-up"></i> Accepter</button><button class="btn btn-outline-danger" onclick="statusAction('refuse')"><i class="bi bi-hand-thumbs-down"></i> Refuser</button><?php endif; ?>
      <?php if(in_array((int)($d['status']??0),[2,3],true)): ?><button class="btn btn-outline-warning" onclick="statusAction('reopen')"><i class="bi bi-arrow-counterclockwise"></i> Réouvrir</button><?php endif; ?>
    </div>
  </div>
</div>

<div class="row g-3 mb-3">
  <div class="col-xl-3 col-md-6"><div class="cardx metric-card"><div class="metric-label">Total HT</div><div class="metric-value"><?=money($d['total_ht']??0)?></div><div class="metric-sub">TVA <?=money($d['total_tva']??0)?></div></div></div>
  <div class="col-xl-3 col-md-6"><div class="cardx metric-card"><div class="metric-label">Total TTC</div><div class="metric-value"><?=money($d['total_ttc']??0)?></div><div class="metric-sub"><?=h($d['currency']??'CHF')?></div></div></div>
  <div class="col-xl-3 col-md-6"><div class="cardx metric-card"><div class="metric-label">Client</div><div class="metric-value metric-text"><?=h($d['thirdparty']??'—')?></div><a target="_blank" href="<?=h($d['thirdparty_url']??'#')?>" class="metric-link">Voir la fiche client <i class="bi bi-arrow-right"></i></a></div></div>
  <div class="col-xl-3 col-md-6"><div class="cardx metric-card"><div class="metric-label">Échéance de validité</div><div class="metric-value metric-text"><?=h($d['date_validity']??'Non définie')?></div><div class="metric-sub">Date devis : <?=h($d['date_propal']??'—')?></div></div></div>
</div>

<ul class="nav nav-pills propal-tabs mb-3" id="propalTabs" role="tablist">
  <li class="nav-item"><button class="nav-link active" data-bs-toggle="pill" data-bs-target="#tab-lines"><i class="bi bi-list-ul"></i> Lignes <span class="badge bg-light text-dark"><?=count($lines)?></span></button></li>
  <li class="nav-item"><button class="nav-link" data-bs-toggle="pill" data-bs-target="#tab-info"><i class="bi bi-sliders"></i> Informations</button></li>
  <li class="nav-item"><button class="nav-link" data-bs-toggle="pill" data-bs-target="#tab-extra"><i class="bi bi-ui-checks-grid"></i> Extrafields <span class="badge bg-light text-dark"><?=count($j['extrafields']??[])?></span></button></li>
  <li class="nav-item"><button class="nav-link" data-bs-toggle="pill" data-bs-target="#tab-linked"><i class="bi bi-diagram-3"></i> Documents liés</button></li>
  <li class="nav-item"><button class="nav-link" data-bs-toggle="pill" data-bs-target="#tab-files"><i class="bi bi-folder2-open"></i> Fichiers <span class="badge bg-light text-dark"><?=count($j['documents']??[])?></span></button></li>
  <li class="nav-item"><button class="nav-link" data-bs-toggle="pill" data-bs-target="#tab-activity"><i class="bi bi-clock-history"></i> Activité</button></li>
</ul>

<div class="tab-content">
<div class="tab-pane fade show active" id="tab-lines">
  <div class="cardx overflow-hidden">
    <div class="section-toolbar p-3"><div><h4 class="mb-1">Contenu du devis</h4><div class="text-muted small">Modifier, dupliquer, supprimer et réorganiser les lignes.</div></div><button class="btn btn-primary" onclick="openLineModal()"><i class="bi bi-plus-lg"></i> Ajouter une ligne</button></div>
    <div class="table-responsive"><table class="table propal-lines mb-0"><thead><tr><th class="dragcol">Ordre</th><th>Description / produit</th><th class="text-end">Qté</th><th class="text-end">PU HT</th><th class="text-end">Remise</th><th class="text-end">TVA</th><th class="text-end">Total HT</th><th class="actionscol"></th></tr></thead><tbody>
      <?php foreach($lines as $index=>$l): ?><tr>
        <td><div class="line-order"><button title="Monter" onclick="moveLine(<?= (int)$l['rowid']?>,'up')"><i class="bi bi-chevron-up"></i></button><span><?= $index+1 ?></span><button title="Descendre" onclick="moveLine(<?= (int)$l['rowid']?>,'down')"><i class="bi bi-chevron-down"></i></button></div></td>
        <td><div class="fw-semibold"><?=h($l['product_ref']??'')?></div><div><?=nl2br(h(strip_tags($l['description']??$l['product_label']??'')))?></div><?php if(!empty($l['product_label'])):?><div class="small text-muted"><?=h($l['product_label'])?></div><?php endif;?></td>
        <td class="text-end fw-semibold"><?=h($l['qty']??0)?></td><td class="text-end"><?=money($l['subprice']??0)?></td><td class="text-end"><?=h($l['remise_percent']??0)?>%</td><td class="text-end"><?=h($l['tva_tx']??0)?>%</td><td class="text-end fw-bold"><?=money($l['total_ht']??0)?></td>
        <td><div class="dropdown"><button class="btn btn-sm btn-light" data-bs-toggle="dropdown"><i class="bi bi-three-dots-vertical"></i></button><ul class="dropdown-menu dropdown-menu-end"><li><button class="dropdown-item" onclick='editLine(<?=json_encode($l,JSON_HEX_APOS|JSON_HEX_QUOT|JSON_UNESCAPED_UNICODE)?>)'><i class="bi bi-pencil"></i> Modifier</button></li><li><button class="dropdown-item" onclick="duplicateLine(<?=(int)$l['rowid']?>)"><i class="bi bi-copy"></i> Dupliquer</button></li><li><hr class="dropdown-divider"></li><li><button class="dropdown-item text-danger" onclick="deleteLine(<?=(int)$l['rowid']?>)"><i class="bi bi-trash3"></i> Supprimer</button></li></ul></div></td>
      </tr><?php endforeach; ?>
      <?php if(!$lines):?><tr><td colspan="8" class="text-center text-muted py-5">Aucune ligne dans ce devis.</td></tr><?php endif;?>
    </tbody><tfoot><tr><td colspan="6" class="text-end">Total HT</td><td class="text-end fw-bold"><?=money($d['total_ht']??0)?></td><td></td></tr><tr><td colspan="6" class="text-end">TVA</td><td class="text-end"><?=money($d['total_tva']??0)?></td><td></td></tr><tr class="grand-total"><td colspan="6" class="text-end">Total TTC</td><td class="text-end"><?=money($d['total_ttc']??0)?></td><td></td></tr></tfoot></table></div>
  </div>
</div>

<div class="tab-pane fade" id="tab-info"><form id="headerForm" class="cardx p-4" onsubmit="saveHeader(event)"><div class="section-title"><h4>Informations générales et conditions</h4><button class="btn btn-primary" type="submit"><i class="bi bi-check2"></i> Enregistrer</button></div><div class="row g-3">
  <div class="col-md-4"><label class="form-label">Référence client</label><input class="form-control" name="ref_client" value="<?=h($d['ref_client']??'')?>"></div>
  <div class="col-md-4"><label class="form-label">Date du devis</label><input type="date" class="form-control" name="date_propal" value="<?=h(tw_date_input($d['date_propal']??''))?>"></div>
  <div class="col-md-4"><label class="form-label">Fin de validité</label><input type="date" class="form-control" name="date_validity" value="<?=h(tw_date_input($d['date_validity']??''))?>"></div>
  <div class="col-md-4"><label class="form-label">Date de livraison prévue</label><input type="date" class="form-control" name="date_delivery" value="<?=h(tw_date_input($d['date_delivery']??''))?>"></div>
  <div class="col-md-4"><label class="form-label">Conditions de règlement</label><select class="form-select" name="fk_payment_term"><option value="">—</option><?php foreach($j['settings']['payment_terms']??[] as $x):?><option value="<?=(int)$x['id']?>" <?=((int)($d['fk_payment_term']??0)===(int)$x['id'])?'selected':''?>><?=h($x['label'])?></option><?php endforeach;?></select></div>
  <div class="col-md-4"><label class="form-label">Mode de règlement</label><select class="form-select" name="fk_payment_mode"><option value="">—</option><?php foreach($j['settings']['payment_modes']??[] as $x):?><option value="<?=(int)$x['id']?>" <?=((int)($d['fk_payment_mode']??0)===(int)$x['id'])?'selected':''?>><?=h($x['label'])?></option><?php endforeach;?></select></div>
  <div class="col-md-6"><label class="form-label">Disponibilité</label><select class="form-select" name="fk_availability"><option value="">—</option><?php foreach($j['settings']['availability']??[] as $x):?><option value="<?=(int)$x['id']?>" <?=((int)($d['fk_availability']??0)===(int)$x['id'])?'selected':''?>><?=h($x['label'])?></option><?php endforeach;?></select></div>
  <div class="col-md-6"><label class="form-label">Origine / canal</label><select class="form-select" name="fk_input_reason"><option value="">—</option><?php foreach($j['settings']['input_reasons']??[] as $x):?><option value="<?=(int)$x['id']?>" <?=((int)($d['fk_input_reason']??0)===(int)$x['id'])?'selected':''?>><?=h($x['label'])?></option><?php endforeach;?></select></div>
  <div class="col-md-6"><label class="form-label">Note publique</label><textarea class="form-control" rows="6" name="note_public"><?=h($d['note_public']??'')?></textarea></div>
  <div class="col-md-6"><label class="form-label">Note privée</label><textarea class="form-control" rows="6" name="note_private"><?=h($d['note_private']??'')?></textarea></div>
</div></form></div>

<div class="tab-pane fade" id="tab-extra"><form id="extraForm" class="cardx p-4" onsubmit="saveExtrafields(event)"><div class="section-title"><div><h4>Champs complémentaires Dolibarr</h4><div class="text-muted small">Les extrafields configurés dans Dolibarr sont affichés ici automatiquement.</div></div><button class="btn btn-primary" type="submit"><i class="bi bi-check2"></i> Enregistrer</button></div><div class="row g-3">
<?php foreach($j['extrafields']??[] as $ef): $name='ef_'.$ef['name']; $val=$ef['value']??''; ?><div class="col-md-6"><label class="form-label"><?=h($ef['label'])?><?=!empty($ef['required'])?' *':''?></label><?php if(in_array($ef['type'],['date','datetime'],true)):?><input type="date" class="form-control" name="<?=h($name)?>" value="<?=h(tw_date_input($val))?>"><?php elseif(in_array($ef['type'],['text','html'],true)):?><textarea class="form-control" rows="3" name="<?=h($name)?>"><?=h($val)?></textarea><?php elseif(in_array($ef['type'],['boolean','bool'],true)):?><select class="form-select" name="<?=h($name)?>"><option value="0" <?=!$val?'selected':''?>>Non</option><option value="1" <?=$val?'selected':''?>>Oui</option></select><?php else:?><input class="form-control" name="<?=h($name)?>" value="<?=h($val)?>"><?php endif;?></div><?php endforeach;?>
<?php if(empty($j['extrafields'])):?><div class="col-12 text-center text-muted py-5">Aucun extrafield configuré pour les devis.</div><?php endif;?></div></form></div>

<div class="tab-pane fade" id="tab-linked"><div class="row g-3"><div class="col-lg-6"><div class="cardx p-4 h-100"><h4><i class="bi bi-bag-check"></i> Commandes liées</h4><?php foreach($j['linked']['orders']??[] as $x):?><a target="_blank" href="<?=h($x['url'])?>" class="linked-doc"><div><strong><?=h($x['ref'])?></strong><div class="small text-muted">Commande client</div></div><div class="text-end"><strong><?=money($x['total_ttc']??0)?></strong><i class="bi bi-box-arrow-up-right ms-2"></i></div></a><?php endforeach;?><?php if(empty($j['linked']['orders'])):?><div class="empty-state">Aucune commande liée détectée.</div><?php endif;?></div></div><div class="col-lg-6"><div class="cardx p-4 h-100"><h4><i class="bi bi-receipt"></i> Factures liées</h4><?php foreach($j['linked']['invoices']??[] as $x):?><a target="_blank" href="<?=h($x['url'])?>" class="linked-doc"><div><strong><?=h($x['ref'])?></strong><div class="small text-muted"><?=!empty($x['paye'])?'Payée':'À contrôler'?></div></div><div class="text-end"><strong><?=money($x['total_ttc']??0)?></strong><i class="bi bi-box-arrow-up-right ms-2"></i></div></a><?php endforeach;?><?php if(empty($j['linked']['invoices'])):?><div class="empty-state">Aucune facture liée détectée.</div><?php endif;?></div></div></div></div>

<div class="tab-pane fade" id="tab-files"><div class="cardx p-4"><div class="section-title"><h4>Documents générés</h4><button class="btn btn-primary" onclick="generatePdf()"><i class="bi bi-filetype-pdf"></i> Générer un nouveau PDF</button></div><div class="document-grid"><?php foreach($j['documents']??[] as $f):?><a target="_blank" class="document-card" href="<?=h($f['url'])?>"><i class="bi bi-file-earmark-pdf"></i><div><strong><?=h($f['name'])?></strong><div class="small text-muted"><?=number_format(((int)$f['size'])/1024,1)?> Ko · <?=h(substr($f['modified'],0,16))?></div></div><i class="bi bi-download ms-auto"></i></a><?php endforeach;?><?php if(empty($j['documents'])):?><div class="empty-state w-100">Aucun document généré pour ce devis.</div><?php endif;?></div></div></div>

<div class="tab-pane fade" id="tab-activity"><div class="row g-3"><div class="col-lg-8"><div class="cardx p-4"><h4>Historique et actions</h4><div class="timeline"><?php foreach($j['events']??[] as $e):?><div class="timeline-item"><div class="timeline-dot"></div><div><strong><?=h($e['label']??'Action')?></strong><div class="small text-muted"><?=h($e['datec']??$e['datep']??'')?></div><?php if(!empty($e['note_private'])||!empty($e['note_public'])):?><div class="mt-1"><?=h($e['note_private']??$e['note_public'])?></div><?php endif;?></div></div><?php endforeach;?><?php if(empty($j['events'])):?><div class="empty-state">Aucune activité liée trouvée.</div><?php endif;?></div></div></div><div class="col-lg-4"><div class="cardx p-4"><h4>Ajouter une note / tâche</h4><label class="form-label">Note</label><textarea id="noteText" class="form-control mb-2" rows="4"></textarea><div class="mb-3"><label class="me-3"><input type="radio" name="noteVisibility" value="private" checked> Privée</label><label><input type="radio" name="noteVisibility" value="public"> Publique</label></div><button class="btn btn-primary w-100 mb-4" onclick="saveNote('propal',<?=$id?>)">Ajouter la note</button><label class="form-label">Titre de tâche</label><input id="taskLabel" class="form-control mb-2" value="Relancer <?=h($d['ref']??'')?>"><input id="taskDate" type="date" class="form-control mb-2" value="<?=date('Y-m-d',strtotime('+3 days'))?>"><textarea id="taskNote" class="form-control mb-2" rows="3" placeholder="Détail de la tâche"></textarea><button class="btn btn-success w-100" onclick="createTask('propal',<?=$id?>)">Créer la tâche</button></div></div></div></div>
</div>

<div class="modal fade" id="lineModal" tabindex="-1"><div class="modal-dialog modal-lg"><form class="modal-content" onsubmit="saveLine(event)"><div class="modal-header"><h5 class="modal-title" id="lineModalTitle">Ajouter une ligne</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body"><input type="hidden" id="lineId"><div class="mb-3"><label class="form-label">Description</label><textarea id="lineDescription" class="form-control" rows="5" required></textarea></div><div class="row g-3"><div class="col-md-3"><label class="form-label">Quantité</label><input id="lineQty" type="number" step="0.001" class="form-control" value="1" required></div><div class="col-md-3"><label class="form-label">Prix unitaire HT</label><input id="linePrice" type="number" step="0.01" class="form-control" value="0" required></div><div class="col-md-3"><label class="form-label">TVA %</label><input id="lineVat" type="number" step="0.01" class="form-control" value="8.1"></div><div class="col-md-3"><label class="form-label">Remise %</label><input id="lineDiscount" type="number" step="0.01" class="form-control" value="0"></div></div></div><div class="modal-footer"><button type="button" class="btn btn-light" data-bs-dismiss="modal">Annuler</button><button class="btn btn-primary" type="submit">Enregistrer la ligne</button></div></form></div></div>
<script>
const PROPAL_ID=<?=$id?>; let lineModal;
document.addEventListener('DOMContentLoaded',()=>lineModal=new bootstrap.Modal(document.getElementById('lineModal')));
function toast(message,ok=true){const el=document.createElement('div');el.className='toast show align-items-center text-bg-'+(ok?'success':'danger')+' border-0 mb-2';el.innerHTML='<div class="d-flex"><div class="toast-body">'+escapeHtml(message)+'</div><button class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button></div>';document.getElementById('toastZone').appendChild(el);setTimeout(()=>el.remove(),4500)}
function escapeHtml(s){return String(s||'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]))}
async function postAction(action,data={}){try{const j=await api(action,{id:PROPAL_ID,...data},true);toast(j.message||j.error||'Action terminée',!!j.ok);if(!j.ok)throw new Error(j.error||'Erreur');return j}catch(e){toast(e.message,false);throw e}}
async function saveHeader(e){e.preventDefault();const data=Object.fromEntries(new FormData(e.target));await postAction('propal_update_header',data);setTimeout(()=>location.reload(),500)}
async function saveExtrafields(e){e.preventDefault();const data=Object.fromEntries(new FormData(e.target));await postAction('propal_update_extrafields',data)}
function openLineModal(){document.getElementById('lineModalTitle').textContent='Ajouter une ligne';document.getElementById('lineId').value='';document.getElementById('lineDescription').value='';document.getElementById('lineQty').value='1';document.getElementById('linePrice').value='0';document.getElementById('lineVat').value='8.1';document.getElementById('lineDiscount').value='0';lineModal.show()}
function editLine(l){document.getElementById('lineModalTitle').textContent='Modifier la ligne';document.getElementById('lineId').value=l.rowid;document.getElementById('lineDescription').value=l.description||'';document.getElementById('lineQty').value=l.qty||1;document.getElementById('linePrice').value=l.subprice||0;document.getElementById('lineVat').value=l.tva_tx||0;document.getElementById('lineDiscount').value=l.remise_percent||0;lineModal.show()}
async function saveLine(e){e.preventDefault();const lineid=document.getElementById('lineId').value;const data={lineid,description:document.getElementById('lineDescription').value,qty:document.getElementById('lineQty').value,subprice:document.getElementById('linePrice').value,tva_tx:document.getElementById('lineVat').value,remise_percent:document.getElementById('lineDiscount').value};await postAction(lineid?'propal_line_update':'propal_line_add',data);lineModal.hide();setTimeout(()=>location.reload(),500)}
async function deleteLine(lineid){if(!confirm('Supprimer définitivement cette ligne du devis ?'))return;await postAction('propal_line_delete',{lineid});location.reload()}
async function duplicateLine(lineid){await postAction('propal_line_duplicate',{lineid});location.reload()}
async function moveLine(lineid,direction){await postAction('propal_line_move',{lineid,direction});location.reload()}
async function generatePdf(){const j=await postAction('generate_pdf',{type:'propal'});if(j.url)window.open(j.url,'_blank')}
async function statusAction(operation){let note='';if(operation==='refuse')note=prompt('Motif du refus :')||'';if(!confirm('Confirmer cette action sur le statut du devis ?'))return;await postAction('propal_status_action',{operation,note});location.reload()}
</script>
<?php layout_end(); ?>
