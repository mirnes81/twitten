<?php
function tw_config(){
  $candidates=[dirname(__DIR__).'/software_data/twitten/config/config.php', dirname(__DIR__).'/private/twitten/config/config.php'];
  foreach($candidates as $f){ if(is_file($f)) return include $f; }
  return ['dolibarr_url'=>'https://crm.mv-3pro.ch','bridge_url'=>'https://crm.mv-3pro.ch/custom/twittenbridge/api/api.php','bridge_key'=>''];
}
function tw_bridge($action,$params=[],$post=false){
  $cfg=tw_config(); $url=$cfg['bridge_url']; if(strpos($url,'api.php')===false) $url=rtrim($url,'/').'/api/api.php';
  $params=array_merge(['action'=>$action,'key'=>$cfg['bridge_key']??''],$params);
  $ch=curl_init();
  if($post){ curl_setopt($ch,CURLOPT_URL,$url); curl_setopt($ch,CURLOPT_POST,1); curl_setopt($ch,CURLOPT_POSTFIELDS,http_build_query($params)); }
  else { curl_setopt($ch,CURLOPT_URL,$url.'?'.http_build_query($params)); }
  curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>1,CURLOPT_TIMEOUT=>20,CURLOPT_SSL_VERIFYPEER=>false]);
  $raw=curl_exec($ch); $err=curl_error($ch); curl_close($ch);
  $json=json_decode((string)$raw,true); if(!is_array($json)) return ['ok'=>false,'error'=>'Réponse Bridge invalide','raw'=>substr((string)$raw,0,500),'curl'=>$err]; return $json;
}
function h($v){ return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8'); }
function money($v){ return number_format((float)$v,2,"'",' ').' CHF'; }
function layout_start($title='Twitten'){
?><!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title><?=h($title)?></title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"><link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet"><link href="assets/twitten.css" rel="stylesheet"></head><body><div class="tw-layout"><aside class="tw-side"><div class="brand"><i class="bi bi-gem"></i> Twitten</div><nav><a href="index.php"><i class="bi bi-speedometer2"></i> Dashboard</a><a href="clients.php"><i class="bi bi-people"></i> Clients</a><a href="invoices.php"><i class="bi bi-receipt"></i> Factures</a><a href="propals.php"><i class="bi bi-file-earmark-text"></i> Devis</a><a href="smart-actions.php"><i class="bi bi-lightning-charge"></i> Actions intelligentes</a><a href="bridge-test.php"><i class="bi bi-plug"></i> Test Bridge</a></nav></aside><main class="tw-main"><div class="tw-top"><div><h1><?=h($title)?></h1><p class="text-muted mb-0">Interface moderne connectée à Dolibarr</p></div><div class="position-relative"><input id="globalSearch" class="form-control form-control-lg search" placeholder="Rechercher dès 2 lettres..."><div id="searchBox" class="searchbox d-none"></div></div></div>
<?php }
function layout_end(){ ?><script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script><script src="assets/twitten.js"></script></main></div></body></html><?php }
