<?php require __DIR__.'/lib.php'; header('Content-Type: application/json; charset=utf-8');
$action=$_POST['action'] ?? $_GET['action'] ?? '';
$params=$_POST ?: $_GET; unset($params['action']);
echo json_encode(tw_call($action,$params,true), JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
