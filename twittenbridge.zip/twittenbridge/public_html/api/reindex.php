<?php
declare(strict_types=1);
require_once __DIR__ . '/../../private/twitten/app/Core/bootstrap.php';

use Twitten\Core\Security;
use Twitten\Dolibarr\DolibarrConfigDetector;
use Twitten\Search\SearchEngine;

try {
    Security::requireCsrf();
    $detector = new DolibarrConfigDetector(dirname(__DIR__, 3));
    $config = $detector->detect();
    $pdo = $detector->pdo($config);
    $engine = new SearchEngine($pdo, $config['db_prefix'] ?? 'llx_', dirname(__DIR__, 2).'/storage/search_index');
    $limit = (int)($_POST['limit'] ?? 1500);
    Security::json($engine->rebuild($limit));
} catch (Throwable $e) {
    Security::json(['ok'=>false, 'error'=>$e->getMessage()], 500);
}
