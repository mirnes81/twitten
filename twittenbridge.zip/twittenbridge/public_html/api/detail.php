<?php
require_once __DIR__ . '/../../private/twitten/app/Core/bootstrap.php';
use Twitten\Core\Security;
use Twitten\Dolibarr\DolibarrConfigDetector;
use Twitten\Dolibarr\DolibarrApi;
try {
    $type = preg_replace('/[^a-z_]/', '', $_GET['type'] ?? 'thirdparty');
    $id = max(1, (int)($_GET['id'] ?? 0));
    $detector = new DolibarrConfigDetector(dirname(__DIR__, 3));
    $config = $detector->detect();
    $pdo = $detector->pdo($config);
    $api = new DolibarrApi($pdo, $config['db_prefix'] ?? 'llx_');
    $data = $api->detail($type, $id);
    if (isset($_GET['html'])) {
        header('Content-Type: text/html; charset=utf-8');
        echo $api->renderDetailHtml($data, $type);
        exit;
    }
    Security::json($data);
} catch (Throwable $e) {
    if (isset($_GET['html'])) { http_response_code(500); echo '<div class="alert alert-danger">'.htmlspecialchars($e->getMessage()).'</div>'; exit; }
    Security::json(['ok'=>false, 'error'=>$e->getMessage()], 500);
}
