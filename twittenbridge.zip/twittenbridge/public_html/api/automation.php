<?php
require_once __DIR__.'/../../private/twitten/app/Core/bootstrap.php';
use Twitten\Core\Security;
use Twitten\Dolibarr\DolibarrConfigDetector;
use Twitten\AI\AutomationEngine;
try{
 $detector=new DolibarrConfigDetector(dirname(__DIR__,2));$cfg=$detector->detect();$pdo=$detector->pdo($cfg);
 $engine=new AutomationEngine($pdo,$cfg['db_prefix']??'llx_',dirname(__DIR__,2));
 $action=(string)($_GET['action']??$_POST['action']??'dashboard');
 if($_SERVER['REQUEST_METHOD']==='POST') Security::requireCsrf();
 $result=match($action){
  'dashboard'=>$engine->dashboard(),'scan'=>$engine->scan(true),'approve'=>$engine->approve((string)($_POST['id']??'')),
  'reject'=>$engine->reject((string)($_POST['id']??'')),'execute'=>$engine->executeApproved(),
  'rule'=>$engine->updateRule((string)($_POST['id']??''),$_POST),default=>['ok'=>false,'error'=>'Action inconnue.']};
 Security::json(['ok'=>$result['ok']??true,'data'=>$result],($result['ok']??true)?200:400);
}catch(Throwable $e){Security::json(['ok'=>false,'error'=>$e->getMessage()],500);}
