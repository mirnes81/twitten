<?php
require_once __DIR__ . '/../../private/twitten/app/Core/bootstrap.php';
use Twitten\Customization\CustomizationService;
$service = new CustomizationService(__DIR__ . '/../../storage');
header('Content-Type: application/json; charset=utf-8');
header('Content-Disposition: attachment; filename="twitten-customization-export.json"');
echo json_encode($service->exportAll(), JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE);
