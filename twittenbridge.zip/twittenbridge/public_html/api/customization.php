<?php
require_once __DIR__ . '/../../private/twitten/app/Core/bootstrap.php';

use Twitten\Core\Security;
use Twitten\Customization\CustomizationService;

header('Content-Type: application/json; charset=utf-8');
$service = new CustomizationService(__DIR__ . '/../../storage');
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$section = (string)($_GET['section'] ?? 'all');

try {
    if ($method === 'POST') {
        Security::requireCsrf((string)($_POST['_csrf'] ?? ''));
        $action = (string)($_POST['action'] ?? '');
        $data = $_POST;
        $result = match ($action) {
            'save_branding' => $service->saveBranding($data),
            'add_field' => $service->addField($data),
            'save_views' => $service->saveViews($data),
            'save_template' => $service->saveTemplate($data),
            'add_workflow' => $service->addWorkflow($data),
            default => ['error' => 'Action inconnue'],
        };
        echo json_encode(['ok'=>true,'result'=>$result], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $payload = match ($section) {
        'branding' => $service->branding(),
        'fields' => $service->fields(),
        'views' => $service->views(),
        'templates' => $service->templates(),
        'workflows' => $service->workflows(),
        default => $service->exportAll(),
    };
    echo json_encode(['ok'=>true,'data'=>$payload], JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok'=>false,'error'=>$e->getMessage()], JSON_UNESCAPED_UNICODE);
}
