<?php
require_once __DIR__ . '/../../private/twitten/app/Core/bootstrap.php';
header('Content-Type: application/json; charset=utf-8');
try {
    $detector = new \Twitten\Dolibarr\DolibarrConfigDetector(dirname(__DIR__, 2));
    $config = $detector->detect();
    $pdo = $detector->pdo($config);
    $dashboard = new \Twitten\Dashboard\SmartDashboard($pdo, $config['db_prefix'] ?? 'llx_');
    echo json_encode(['ok'=>true,'data'=>$dashboard->overview()], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok'=>false,'error'=>$e->getMessage()], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}
