<?php
require_once __DIR__ . '/../../private/twitten/app/Core/bootstrap.php';
header('Content-Type: application/json; charset=utf-8');
try {
    $detector = new \Twitten\Dolibarr\DolibarrConfigDetector(dirname(__DIR__,2));
    $config = $detector->detect();
    $pdo = $detector->pdo($config);
    $center = new \Twitten\AI\AiCenter($pdo, $config['db_prefix'] ?? 'llx_', dirname(__DIR__,2));
    $action = $_GET['action'] ?? $_POST['action'] ?? 'overview';
    if ($action === 'ask') {
        $raw = file_get_contents('php://input');
        $data = json_decode($raw ?: '{}', true) ?: $_POST;
        echo json_encode(['ok'=>true,'data'=>$center->ask((string)($data['question'] ?? ''))], JSON_UNESCAPED_UNICODE); exit;
    }
    if ($action === 'webhook') {
        if (class_exists('Twitten\\Core\\Security')) { \Twitten\Core\Security::requireCsrf(); }
        $raw = file_get_contents('php://input');
        $data = json_decode($raw ?: '{}', true) ?: $_POST;
        echo json_encode(['ok'=>true,'data'=>$center->triggerWebhook((string)($data['agent'] ?? 'IA'), (string)($data['request'] ?? 'Action IA'), $data)], JSON_UNESCAPED_UNICODE); exit;
    }
    echo json_encode(['ok'=>true,'data'=>$center->overview()], JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok'=>false,'error'=>$e->getMessage()], JSON_UNESCAPED_UNICODE);
}
