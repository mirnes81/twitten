<?php
header('Content-Type: application/json; charset=utf-8');
function find_private(){
  $root=dirname(__DIR__,2);
  $c=[
    $root.'/software_data/twitten',
    $root.'/private/twitten',
    dirname($root).'/software_data/twitten',
    dirname($root).'/private/twitten'
  ];
  foreach($c as $p){ if(is_dir($p) && is_dir($p.'/config')) return $p; }
  return $root.'/software_data/twitten';
}
$private=find_private();
$config=$private.'/config/config.php';
if(!is_file($config)){ echo json_encode(['ok'=>false,'error'=>'Configuration Twitten manquante']); exit; }
$cfg=require $config;
$bridge=rtrim($cfg['bridge_url'] ?? '', '?');
$key=$cfg['bridge_key'] ?? '';
$action=preg_replace('/[^a-z0-9_\-]/i','', $_GET['action'] ?? 'summary');
$q=$_GET['q'] ?? '';
$limit=(int)($_GET['limit'] ?? 20);
if(!$bridge || !$key){ echo json_encode(['ok'=>false,'error'=>'Bridge URL ou clé manquante']); exit; }
$url=$bridge.'?action='.urlencode($action).'&key='.urlencode($key).'&limit='.$limit;
if($q!=='') $url.='&q='.urlencode($q);
$ctx=stream_context_create(['http'=>['timeout'=>8,'ignore_errors'=>true]]);
$res=@file_get_contents($url,false,$ctx);
if($res===false){ echo json_encode(['ok'=>false,'error'=>'Impossible de contacter le Bridge','url'=>$bridge]); exit; }
echo $res;
