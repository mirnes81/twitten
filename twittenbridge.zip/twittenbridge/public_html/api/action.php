<?php
require_once __DIR__ . '/../../private/twitten/app/Core/bootstrap.php';

use Twitten\Core\Security;
use Twitten\Dolibarr\DolibarrConfigDetector;
use Twitten\Dolibarr\DolibarrWriter;

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    Security::json(['ok'=>false, 'error'=>'Méthode POST obligatoire.'], 405);
}

Security::requireCsrf();

$action = (string)($_POST['action'] ?? '');
$type = (string)($_POST['type'] ?? '');
$id = (int)($_POST['id'] ?? 0);
$confirm = (string)($_POST['confirm'] ?? '');
$simulate = $confirm !== 'WRITE_DOLIBARR' || !Security::writeEnabled();

$payload = $_POST;
unset($payload['csrf'], $payload['action'], $payload['type'], $payload['id'], $payload['confirm']);

if ($id <= 0 || $type === '' || $action === '') {
    Security::json(['ok'=>false, 'error'=>'Action, type ou ID manquant.'], 400);
}

try {
    $detector = new DolibarrConfigDetector(dirname(__DIR__, 2));
    $config = $detector->detect();
    $pdo = $detector->pdo($config);
    $writer = new DolibarrWriter($pdo, $config['db_prefix'] ?? 'llx_', dirname(__DIR__, 2).'/storage');
    $result = $writer->execute($action, $type, $id, $payload, $simulate);
    $result['write_mode'] = Security::writeEnabled() ? 'enabled' : 'readonly';
    $result['confirm_required'] = 'WRITE_DOLIBARR';
    Security::json($result, ($result['ok'] ?? false) ? 200 : 400);
} catch (Throwable $e) {
    Security::json(['ok'=>false, 'error'=>$e->getMessage()], 500);
}
