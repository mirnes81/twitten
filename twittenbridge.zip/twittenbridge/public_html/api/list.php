<?php
require_once __DIR__ . '/../../private/twitten/app/Core/bootstrap.php';
use Twitten\Core\Security;
use Twitten\Dolibarr\DolibarrConfigDetector;
use Twitten\Dolibarr\DolibarrApi;

try {
    $type = preg_replace('/[^a-z_]/', '', $_GET['type'] ?? 'thirdparties');
    $q = trim((string)($_GET['q'] ?? ''));
    $limit = (int)($_GET['limit'] ?? 30);
    $detector = new DolibarrConfigDetector(dirname(__DIR__, 3));
    $config = $detector->detect();
    $pdo = $detector->pdo($config);
    $api = new DolibarrApi($pdo, $config['db_prefix'] ?? 'llx_');
    Security::json(['ok'=>true, 'type'=>$type, 'items'=>$api->list($type, $q, $limit)]);
} catch (Throwable $e) {
    Security::json(['ok'=>false, 'error'=>$e->getMessage()], 500);
}
