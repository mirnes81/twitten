<?php
require_once __DIR__ . '/../../private/twitten/app/Core/bootstrap.php';

use Twitten\Core\Security;
use Twitten\Dolibarr\DolibarrConfigDetector;
use Twitten\Dolibarr\DolibarrApi;
use Twitten\Dolibarr\TwittenDocumentService;

$type = preg_replace('/[^a-z_]/', '', $_REQUEST['type'] ?? 'proposal');
$id = max(1, (int)($_REQUEST['id'] ?? 0));
$template = preg_replace('/[^a-zA-Z0-9_\-]/', '', $_REQUEST['template'] ?? 'standard');
$mode = preg_replace('/[^a-z]/', '', $_REQUEST['mode'] ?? 'preview');

try {
    $detector = new DolibarrConfigDetector(dirname(__DIR__, 2));
    $config = $detector->detect();
    $pdo = $detector->pdo($config);
    $api = new DolibarrApi($pdo, $config['db_prefix'] ?? 'llx_');
    $svc = new TwittenDocumentService($api, dirname(__DIR__, 2).'/storage');

    if ($mode === 'templates') {
        Security::json(['ok'=>true, 'templates'=>$svc->templates()]);
    }

    if ($mode === 'create') {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') Security::json(['ok'=>false, 'error'=>'POST obligatoire.'], 405);
        Security::requireCsrf();
        Security::json($svc->createHtmlDocument($type, $id, $template));
    }

    $result = $svc->preview($type, $id, $template);
    if (isset($_GET['html'])) {
        header('Content-Type: text/html; charset=utf-8');
        echo $result['html'] ?? '<div class="alert alert-danger">Erreur aperçu document.</div>';
        exit;
    }
    Security::json($result, ($result['ok'] ?? false) ? 200 : 400);
} catch (Throwable $e) {
    Security::json(['ok'=>false, 'error'=>$e->getMessage()], 500);
}
