<?php
require_once __DIR__ . '/../../private/twitten/app/Core/bootstrap.php';

use Twitten\Core\Security;
use Twitten\Dolibarr\DolibarrConfigDetector;
use Twitten\Dolibarr\DolibarrApi;
use Twitten\Dolibarr\TwittenEmailService;

$type = preg_replace('/[^a-z_]/', '', $_REQUEST['type'] ?? 'invoice');
$id = max(1, (int)($_REQUEST['id'] ?? 0));
$template = preg_replace('/[^a-zA-Z0-9_\-]/', '', $_REQUEST['template'] ?? 'envoi_document');
$mode = preg_replace('/[^a-z]/', '', $_REQUEST['mode'] ?? 'preview');

try {
    $detector = new DolibarrConfigDetector(dirname(__DIR__, 2));
    $config = $detector->detect();
    $pdo = $detector->pdo($config);
    $api = new DolibarrApi($pdo, $config['db_prefix'] ?? 'llx_');
    $svc = new TwittenEmailService($api, dirname(__DIR__, 2).'/storage');

    if ($mode === 'templates') Security::json(['ok'=>true, 'templates'=>$svc->templates()]);

    if ($mode === 'queue') {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') Security::json(['ok'=>false, 'error'=>'POST obligatoire.'], 405);
        Security::requireCsrf();
        Security::json($svc->queueEmail($type, $id, $template, $_POST));
    }

    Security::json($svc->preview($type, $id, $template));
} catch (Throwable $e) {
    Security::json(['ok'=>false, 'error'=>$e->getMessage()], 500);
}
