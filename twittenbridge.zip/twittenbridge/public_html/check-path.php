<?php
require __DIR__ . '/bootstrap.php';
$prep = tw_prepare_private();
header('Content-Type: text/plain; charset=utf-8');
echo "Twitten V1 path check + real auto repair\n";
echo "Public path: " . tw_public_path() . "\n";
echo "Document root: " . ($_SERVER['DOCUMENT_ROOT'] ?? '') . "\n";
echo "Selected private path: " . ($prep['private'] ?: 'AUCUN') . "\n";
echo "Private dir exists: " . (($prep['private'] && is_dir($prep['private'])) ? 'YES' : 'NO') . "\n";
echo "Private app exists: " . (($prep['private'] && is_dir($prep['private'].'/app')) ? 'YES' : 'NO') . "\n";
echo "Storage exists: " . (($prep['private'] && is_dir($prep['private'].'/storage')) ? 'YES' : 'NO') . "\n";
echo "Storage writable: " . (($prep['private'] && tw_is_writable_dir($prep['private'].'/storage')) ? 'YES' : 'NO') . "\n";
echo "Config exists: " . (($prep['private'] && file_exists($prep['private'].'/config/config.php')) ? 'YES' : 'NO') . "\n";
echo "PHP: " . PHP_VERSION . "\n";
if ($prep['created']) { echo "\nCreated this run:\n- " . implode("\n- ", $prep['created']) . "\n"; }
if ($prep['errors']) { echo "\nErrors:\n- " . implode("\n- ", $prep['errors']) . "\n"; }
echo "\nCandidates tested:\n";
foreach (tw_base_candidates() as $p) {
    echo (is_dir($p) ? '[DIR] ' : '[NO ] ') . $p . "\n";
}
