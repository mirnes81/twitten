<?php
/** Twitten V1 Hoststar bootstrap - no fixed path. */
declare(strict_types=1);

function tw_html($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

function tw_public_path(): string {
    return realpath(__DIR__) ?: __DIR__;
}

function tw_base_candidates(): array {
    $public = tw_public_path();
    $docroot = isset($_SERVER['DOCUMENT_ROOT']) ? (realpath($_SERVER['DOCUMENT_ROOT']) ?: $_SERVER['DOCUMENT_ROOT']) : $public;
    $domainRoot = dirname($public);
    $home = getenv('HOME') ?: '';
    $c = [];

    // Preferred: Hoststar private folder beside public_html
    $c[] = $domainRoot . '/private/twitten';

    // Hoststar often allows software_data for private writable app data
    $c[] = $domainRoot . '/software_data/twitten';

    // Variants from DOCUMENT_ROOT
    $c[] = dirname($docroot) . '/private/twitten';
    $c[] = dirname($docroot) . '/software_data/twitten';

    // Some Hoststar PHP paths differ from FTP paths: try without /web/
    if (strpos($domainRoot, '/web/') !== false) {
        $c[] = str_replace('/web/', '/', $domainRoot) . '/private/twitten';
        $c[] = str_replace('/web/', '/', $domainRoot) . '/software_data/twitten';
    }

    // User home fallbacks
    if ($home) {
        $host = $_SERVER['HTTP_HOST'] ?? basename($domainRoot);
        $c[] = rtrim($home, '/') . '/web/' . $host . '/private/twitten';
        $c[] = rtrim($home, '/') . '/web/' . $host . '/software_data/twitten';
        $c[] = rtrim($home, '/') . '/' . $host . '/private/twitten';
        $c[] = rtrim($home, '/') . '/' . $host . '/software_data/twitten';
    }

    // Last resort: public_html/.twitten_private (works even if Hoststar blocks ../private)
    // Not preferred, protected by .htaccess, but used only if all private folders are inaccessible.
    $c[] = $public . '/.twitten_private';

    return array_values(array_unique($c));
}

function tw_is_writable_dir(string $path): bool {
    if (!is_dir($path)) return false;
    $test = rtrim($path, '/') . '/.tw_write_test_' . uniqid('', true);
    $ok = @file_put_contents($test, 'ok') !== false;
    if ($ok) @unlink($test);
    return $ok;
}

function tw_make_dir(string $dir): bool {
    if (is_dir($dir)) return true;
    return @mkdir($dir, 0775, true) || is_dir($dir);
}

function tw_prepare_private(?string $forced = null): array {
    $created = [];
    $errors = [];
    $candidates = $forced ? [$forced] : tw_base_candidates();
    $selected = null;

    foreach ($candidates as $candidate) {
        $candidate = rtrim($candidate, '/');
        $parent = dirname($candidate);
        // Try to create only where parent exists or can be created.
        if (!is_dir($candidate)) {
            if (@mkdir($candidate, 0775, true)) $created[] = $candidate;
        }
        if (is_dir($candidate)) {
            $selected = $candidate;
            break;
        }
    }

    if (!$selected) {
        return ['ok'=>false, 'private'=>null, 'created'=>$created, 'errors'=>['Impossible de créer/trouver le dossier privé.']];
    }

    foreach (['app','config','storage','storage/logs','storage/cache','bridge','docs'] as $sub) {
        $d = $selected . '/' . $sub;
        if (!is_dir($d)) {
            if (tw_make_dir($d)) $created[] = $d;
            else $errors[] = "Création impossible: $d";
        }
    }

    // protect fallback public private folder
    if (strpos($selected, tw_public_path()) === 0) {
        @file_put_contents($selected.'/.htaccess', "Require all denied\nDeny from all\n");
    }

    $helpers = $selected . '/app/helpers.php';
    if (!file_exists($helpers)) {
        @file_put_contents($helpers, "<?php\nfunction twitten_private_ready(){ return true; }\n");
        if (file_exists($helpers)) $created[] = $helpers;
    }

    return [
        'ok'=>is_dir($selected.'/app') && is_dir($selected.'/storage'),
        'private'=>$selected,
        'created'=>$created,
        'errors'=>$errors,
        'writable'=>tw_is_writable_dir($selected.'/storage'),
        'config_exists'=>file_exists($selected.'/config/config.php'),
    ];
}

function tw_private_path(): string {
    static $path = null;
    if ($path !== null) return $path;
    $prepared = tw_prepare_private();
    $path = $prepared['private'] ?: (tw_base_candidates()[0] ?? dirname(__DIR__) . '/private/twitten');
    return $path;
}

function tw_config_file(): string { return tw_private_path() . '/config/config.php'; }

function tw_load_config(): array {
    $file = tw_config_file();
    if (file_exists($file)) {
        $cfg = include $file;
        return is_array($cfg) ? $cfg : [];
    }
    return [];
}

function tw_save_config(array $cfg): bool {
    $prep = tw_prepare_private();
    if (!$prep['private']) return false;
    $file = $prep['private'] . '/config/config.php';
    $export = var_export($cfg, true);
    return @file_put_contents($file, "<?php\nreturn $export;\n") !== false;
}

function tw_bridge_get(string $endpoint, array $query = []): array {
    $cfg = tw_load_config();
    $base = rtrim($cfg['bridge_url'] ?? '', '/');
    $key = $cfg['bridge_key'] ?? '';
    if (!$base || !$key) return ['ok'=>false, 'error'=>'Bridge non configuré', 'data'=>null];
    $url = $base . (str_contains($base, '?') ? '&' : '?') . http_build_query(array_merge($query, ['endpoint'=>$endpoint, 'key'=>$key]));
    $ctx = stream_context_create(['http'=>['timeout'=>8, 'ignore_errors'=>true]]);
    $raw = @file_get_contents($url, false, $ctx);
    if ($raw === false) return ['ok'=>false, 'error'=>'Connexion bridge impossible', 'data'=>null];
    $json = json_decode($raw, true);
    return is_array($json) ? $json : ['ok'=>true, 'raw'=>$raw, 'data'=>null];
}
