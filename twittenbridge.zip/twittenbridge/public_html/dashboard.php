<?php
require_once __DIR__ . '/../private/twitten/app/Core/bootstrap.php';
$csrf = \Twitten\Core\Security::csrfToken();
?>
<!doctype html>
<html lang="fr" data-bs-theme="light">
<head>
  <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Twitten — Dashboard intelligent</title>
  <meta name="twitten-csrf" content="<?= htmlspecialchars($csrf, ENT_QUOTES) ?>">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/twitten.css" rel="stylesheet">
</head>
<body>
<div class="tw-app" x-data="smartDashboard()" x-init="load()">
  <aside class="tw-sidebar">
    <div class="tw-brand"><span class="tw-logo">T</span><div><strong>Twitten</strong><small>Smart Cockpit</small></div></div>
    <nav class="tw-nav">
      <a class="active" href="dashboard.php"><i class="bi bi-speedometer2"></i>Dashboard intelligent</a>
      <a href="index.php"><i class="bi bi-search-heart"></i>Recherche globale</a>
      <a href="documents.php"><i class="bi bi-file-earmark-pdf"></i>Documents</a>
      <a href="ai-center.php"><i class="bi bi-stars"></i>Centre IA</a>
      <a href="customization.php"><i class="bi bi-sliders2-vertical"></i>Personnalisation</a>
      <a href="search-index.php"><i class="bi bi-database-check"></i>Index</a>
      <a href="diagnostic.php"><i class="bi bi-shield-check"></i>Diagnostic</a>
    </nav>
    <div class="tw-sidebar-foot"><span class="badge text-bg-success">Dolibarr connecté</span><small>Lecture + actions contrôlées</small></div>
  </aside>
  <main class="tw-main">
    <header class="tw-topbar">
      <div><h1 class="h4 mb-0">Dashboard intelligent</h1><small class="text-muted">Ce qui demande ton attention maintenant</small></div>
      <div class="tw-actions"><button class="btn btn-outline-secondary" @click="load()"><i class="bi bi-arrow-clockwise"></i> Actualiser</button><a class="btn btn-primary" href="index.php"><i class="bi bi-search"></i> Recherche</a></div>
    </header>

    <section class="tw-hero">
      <div><span class="badge rounded-pill text-bg-primary mb-2">Phase 17</span><h1>Twitten ne montre pas seulement les chiffres, il signale les priorités.</h1><p>Factures impayées, devis sans réponse, montants attendus, activité récente et relances à préparer.</p></div>
      <div class="tw-hero-card"><strong x-text="data?.kpis?.unpaid_amount || '0 CHF'"></strong><span>Encaissement ouvert</span><small>Lecture directe Dolibarr.</small></div>
    </section>

    <template x-if="loading"><div class="alert alert-info"><span class="spinner-border spinner-border-sm"></span> Chargement du cockpit intelligent...</div></template>
    <template x-if="error"><div class="alert alert-danger" x-text="error"></div></template>

    <section class="row g-3 mb-4" x-show="data">
      <div class="col-6 col-xl-2"><div class="tw-kpi"><i class="bi bi-receipt-cutoff"></i><small>Factures ouvertes</small><strong x-text="data.kpis.unpaid_invoices"></strong></div></div>
      <div class="col-6 col-xl-3"><div class="tw-kpi"><i class="bi bi-cash-coin"></i><small>Montant ouvert</small><strong x-text="data.kpis.unpaid_amount"></strong></div></div>
      <div class="col-6 col-xl-2"><div class="tw-kpi"><i class="bi bi-exclamation-triangle"></i><small>En retard</small><strong x-text="data.kpis.late_invoices"></strong></div></div>
      <div class="col-6 col-xl-2"><div class="tw-kpi"><i class="bi bi-file-earmark-text"></i><small>Devis ouverts</small><strong x-text="data.kpis.open_proposals"></strong></div></div>
      <div class="col-12 col-xl-3"><div class="tw-kpi"><i class="bi bi-kanban"></i><small>Projets actifs</small><strong x-text="data.kpis.active_projects"></strong></div></div>
    </section>

    <section class="row g-4" x-show="data">
      <div class="col-xl-7">
        <div class="tw-card mb-4">
          <div class="tw-card-head"><div><h2>Alertes prioritaires</h2><p>Ce qui mérite une action rapide</p></div><span class="badge text-bg-danger" x-text="data.alerts.length + ' alertes'"></span></div>
          <div class="list-group list-group-flush">
            <template x-for="a in data.alerts" :key="a.type+'-'+a.id">
              <div class="list-group-item px-0 d-flex align-items-center justify-content-between gap-3">
                <div><span class="badge" :class="a.level==='danger'?'text-bg-danger':'text-bg-warning'" x-text="a.action"></span><strong class="ms-2" x-text="a.title"></strong><div class="small text-muted" x-text="a.subtitle + ' · ' + (a.date || '')"></div></div>
                <div class="text-end"><strong x-text="a.amount"></strong><br><a class="small" :href="'index.php#'+a.type+'-'+a.id">ouvrir</a></div>
              </div>
            </template>
            <template x-if="data.alerts.length===0"><div class="text-muted p-3">Aucune alerte importante détectée.</div></template>
          </div>
        </div>
        <div class="tw-card">
          <div class="tw-card-head"><div><h2>Encaissements attendus</h2><p>Factures ouvertes par mois</p></div></div>
          <div class="tw-bars">
            <template x-for="c in data.cashflow" :key="c.month">
              <div class="tw-bar-row"><span x-text="c.month"></span><div class="progress flex-grow-1"><div class="progress-bar" :style="'width:'+barWidth(c.amount)+'%'"></div></div><strong x-text="c.amount_label"></strong></div>
            </template>
          </div>
        </div>
      </div>
      <div class="col-xl-5">
        <div class="tw-card mb-4">
          <div class="tw-card-head"><div><h2>À relancer / suivre</h2><p>Liste d’action commerciale et paiement</p></div></div>
          <template x-for="f in data.followups" :key="f.type+'-'+f.id">
            <div class="tw-followup"><span class="tw-priority" :class="'p-'+f.priority" x-text="f.priority"></span><div><strong x-text="f.ref"></strong><div class="small text-muted" x-text="f.label + ' · ' + (f.date || '')"></div></div><strong x-text="f.amount"></strong></div>
          </template>
        </div>
        <div class="tw-card">
          <div class="tw-card-head"><div><h2>Activité récente</h2><p>Dernières pièces Dolibarr</p></div></div>
          <template x-for="r in data.activity" :key="r.type+'-'+r.id">
            <div class="tw-activity"><i class="bi" :class="r.type==='invoice'?'bi-receipt':'bi-file-earmark-text'"></i><div><strong x-text="r.title"></strong><div class="small text-muted" x-text="r.date"></div></div><span x-text="r.amount"></span></div>
          </template>
        </div>
      </div>
    </section>
  </main>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
<script>
function smartDashboard(){return{loading:false,error:'',data:null,async load(){this.loading=true;this.error='';try{const r=await fetch('api/dashboard.php');const j=await r.json();if(!j.ok)throw new Error(j.error||'Erreur dashboard');this.data=j.data;}catch(e){this.error=e.message;}finally{this.loading=false;}},barWidth(v){const max=Math.max(...(this.data?.cashflow||[]).map(x=>x.amount),1);return Math.max(4,Math.round((v/max)*100));}}}
</script>
<style>
.tw-bars{display:grid;gap:12px}.tw-bar-row{display:flex;align-items:center;gap:12px}.tw-bar-row>span{width:76px}.tw-bar-row>strong{width:115px;text-align:right}.tw-followup,.tw-activity{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:12px 0;border-bottom:1px solid var(--bs-border-color)}.tw-followup:last-child,.tw-activity:last-child{border-bottom:0}.tw-priority{font-size:.72rem;text-transform:uppercase;border-radius:999px;padding:4px 8px;background:#eef}.tw-priority.p-urgent{background:#ffe5e5;color:#b00020}.tw-priority.p-high{background:#fff3cd;color:#8a5a00}.tw-priority.p-normal{background:#e7f5ff;color:#084298}.progress{height:10px}
</style>
</body></html>
