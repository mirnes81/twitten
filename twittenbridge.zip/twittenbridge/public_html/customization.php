<?php
require_once __DIR__ . '/../private/twitten/app/Core/bootstrap.php';
use Twitten\Core\Security;
use Twitten\Customization\CustomizationService;
$csrf = Security::csrfToken();
$service = new CustomizationService(__DIR__ . '/../storage');
$branding = $service->branding();
$fields = $service->fields();
$views = $service->views();
$templates = $service->templates();
$workflows = $service->workflows();
function e(string $v): string { return htmlspecialchars($v, ENT_QUOTES, 'UTF-8'); }
?>
<!doctype html>
<html lang="fr" data-bs-theme="<?= e($branding['theme'] === 'dark' ? 'dark' : 'light') ?>">
<head>
  <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Twitten — Personnalisation</title>
  <meta name="twitten-csrf" content="<?= e($csrf) ?>">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/twitten.css" rel="stylesheet">
  <style>:root{--tw-accent:<?= e($branding['accent']) ?>}.tw-logo,.btn-primary{background:var(--tw-accent)!important;border-color:var(--tw-accent)!important}.tw-custom-card{border:1px solid rgba(0,0,0,.08);border-radius:24px;background:var(--bs-body-bg);box-shadow:0 18px 50px rgba(20,20,60,.08)}.tw-section-icon{width:44px;height:44px;border-radius:15px;display:grid;place-items:center;background:rgba(109,93,252,.12);color:var(--tw-accent)}.tw-mini-pill{display:inline-flex;gap:.35rem;align-items:center;border:1px solid rgba(0,0,0,.08);border-radius:999px;padding:.25rem .6rem;margin:.15rem;background:rgba(0,0,0,.02);font-size:.82rem}</style>
</head>
<body>
<div class="tw-app">
  <aside class="tw-sidebar">
    <div class="tw-brand"><span class="tw-logo"><?= e($branding['logo_text']) ?></span><div><strong><?= e($branding['app_name']) ?></strong><small><?= e($branding['company_name']) ?></small></div></div>
    <nav class="tw-nav">
      <a href="dashboard.php"><i class="bi bi-speedometer2"></i>Dashboard</a>
      <a href="index.php"><i class="bi bi-search"></i>Recherche</a>
      <a href="documents.php"><i class="bi bi-file-earmark-pdf"></i>Documents</a>
      <a href="ai-center.php"><i class="bi bi-stars"></i>Centre IA</a>
      <a class="active" href="customization.php"><i class="bi bi-sliders2-vertical"></i>Personnalisation</a>
      <a href="diagnostic.php"><i class="bi bi-shield-check"></i>Diagnostic</a>
    </nav>
    <div class="tw-sidebar-foot"><span class="badge text-bg-primary">Phase 19</span><small>Personnalisation sans core Dolibarr</small></div>
  </aside>
  <main class="tw-main">
    <header class="tw-topbar">
      <div><h1 class="h4 mb-0">Centre de personnalisation</h1><small class="text-muted">Champs, vues, PDF, workflows, menus et identité visuelle.</small></div>
      <div class="tw-actions"><a class="btn btn-outline-secondary" href="api/customization-export.php"><i class="bi bi-download"></i> Export JSON</a><a class="btn btn-primary" href="index.php"><i class="bi bi-search"></i> Retour cockpit</a></div>
    </header>

    <section class="container-fluid py-4">
      <div class="row g-4">
        <div class="col-xl-4">
          <div class="tw-custom-card p-4 h-100">
            <div class="d-flex gap-3 align-items-center mb-3"><span class="tw-section-icon"><i class="bi bi-palette2"></i></span><div><h2 class="h5 mb-0">Identité</h2><small class="text-muted">Logo texte, couleur, thème.</small></div></div>
            <form method="post" action="api/customization.php" class="vstack gap-3">
              <input type="hidden" name="_csrf" value="<?= e($csrf) ?>"><input type="hidden" name="action" value="save_branding">
              <label class="form-label">Nom application<input class="form-control" name="app_name" value="<?= e($branding['app_name']) ?>"></label>
              <label class="form-label">Entreprise<input class="form-control" name="company_name" value="<?= e($branding['company_name']) ?>"></label>
              <div class="row g-2"><div class="col-4"><label class="form-label">Logo<input class="form-control" name="logo_text" maxlength="2" value="<?= e($branding['logo_text']) ?>"></label></div><div class="col-4"><label class="form-label">Couleur<input class="form-control form-control-color w-100" name="accent" value="<?= e($branding['accent']) ?>"></label></div><div class="col-4"><label class="form-label">Thème<select class="form-select" name="theme"><option value="light">Clair</option><option value="dark" <?= $branding['theme']==='dark'?'selected':'' ?>>Sombre</option><option value="auto" <?= $branding['theme']==='auto'?'selected':'' ?>>Auto</option></select></label></div></div>
              <label class="form-check"><input class="form-check-input" type="checkbox" name="compact_mode" value="1" <?= !empty($branding['compact_mode'])?'checked':'' ?>> <span class="form-check-label">Mode compact</span></label>
              <button class="btn btn-primary"><i class="bi bi-save"></i> Enregistrer</button>
            </form>
          </div>
        </div>

        <div class="col-xl-8">
          <div class="tw-custom-card p-4 h-100">
            <div class="d-flex gap-3 align-items-center mb-3"><span class="tw-section-icon"><i class="bi bi-input-cursor-text"></i></span><div><h2 class="h5 mb-0">Champs personnalisés Twitten</h2><small class="text-muted">Surcouche indépendante : n'altère pas les extrafields Dolibarr existants.</small></div></div>
            <form method="post" action="api/customization.php" class="row g-2 align-items-end mb-3">
              <input type="hidden" name="_csrf" value="<?= e($csrf) ?>"><input type="hidden" name="action" value="add_field">
              <div class="col-md-3"><label class="form-label">Module<select class="form-select" name="module"><option value="thirdparties">Clients</option><option value="products">Produits</option><option value="proposals">Devis</option><option value="invoices">Factures</option><option value="orders">Commandes</option><option value="projects">Projets</option></select></label></div>
              <div class="col-md-3"><label class="form-label">Libellé<input class="form-control" name="label" placeholder="Ex: Villa, Étage, Poseur"></label></div>
              <div class="col-md-2"><label class="form-label">Type<select class="form-select" name="type"><option>text</option><option>number</option><option>date</option><option>select</option><option>textarea</option><option>checkbox</option></select></label></div>
              <div class="col-md-2"><label class="form-label">Options<input class="form-control" name="options" placeholder="A,B,C"></label></div>
              <div class="col-md-2"><button class="btn btn-primary w-100"><i class="bi bi-plus-lg"></i> Ajouter</button></div>
              <div class="col-12 d-flex gap-3 small"><label><input type="checkbox" name="required" value="1"> Obligatoire</label><label><input type="checkbox" name="show_in_search" value="1" checked> Recherche</label><label><input type="checkbox" name="show_in_pdf" value="1" checked> PDF</label></div>
            </form>
            <?php foreach ($fields as $module => $items): ?>
              <div class="mb-2"><strong><?= e($module) ?></strong>
                <?php if (!$items): ?><span class="text-muted small"> Aucun champ</span><?php endif; ?>
                <?php foreach ($items as $field): ?><span class="tw-mini-pill"><i class="bi bi-tag"></i><?= e($field['label']) ?> <small><?= e($field['type']) ?></small></span><?php endforeach; ?>
              </div>
            <?php endforeach; ?>
          </div>
        </div>

        <div class="col-xl-6">
          <div class="tw-custom-card p-4 h-100">
            <div class="d-flex gap-3 align-items-center mb-3"><span class="tw-section-icon"><i class="bi bi-layout-wtf"></i></span><div><h2 class="h5 mb-0">Vues & menus</h2><small class="text-muted">Prépare les écrans par entreprise.</small></div></div>
            <form method="post" action="api/customization.php">
              <input type="hidden" name="_csrf" value="<?= e($csrf) ?>"><input type="hidden" name="action" value="save_views">
              <h6>Widgets dashboard</h6>
              <?php foreach (['smart_alerts'=>'Alertes intelligentes','expected_payments'=>'Encaissements attendus','quotes_to_follow'=>'Devis à suivre','recent_activity'=>'Activité récente','today_column'=>'Colonne Aujourd’hui'] as $key=>$label): ?>
                <label class="form-check form-check-inline"><input class="form-check-input" type="checkbox" name="dashboard_widgets[]" value="<?= e($key) ?>" <?= in_array($key,$views['dashboard_widgets']??[],true)?'checked':'' ?>> <?= e($label) ?></label>
              <?php endforeach; ?>
              <hr><h6>Menus visibles</h6>
              <?php foreach (['dashboard','search','clients','proposals','invoices','orders','projects','products','documents','ai','customization'] as $key): ?>
                <label class="form-check form-check-inline"><input class="form-check-input" type="checkbox" name="menus[]" value="<?= e($key) ?>" <?= in_array($key,$views['menus']??[],true)?'checked':'' ?>> <?= e($key) ?></label>
              <?php endforeach; ?>
              <div class="mt-3"><button class="btn btn-primary"><i class="bi bi-save"></i> Enregistrer les vues</button></div>
            </form>
          </div>
        </div>

        <div class="col-xl-6">
          <div class="tw-custom-card p-4 h-100">
            <div class="d-flex gap-3 align-items-center mb-3"><span class="tw-section-icon"><i class="bi bi-file-earmark-richtext"></i></span><div><h2 class="h5 mb-0">Modèles PDF / e-mails</h2><small class="text-muted">Variables préparées : {{company_name}}, {{ref}}, {{thirdparty}}, {{project}}.</small></div></div>
            <form method="post" action="api/customization.php" class="vstack gap-2">
              <input type="hidden" name="_csrf" value="<?= e($csrf) ?>"><input type="hidden" name="action" value="save_template">
              <select class="form-select" name="type"><option value="invoice">Facture</option><option value="proposal">Devis</option><option value="order">Commande</option></select>
              <input class="form-control" name="name" placeholder="Nom du modèle">
              <textarea class="form-control" name="header" rows="2" placeholder="En-tête"></textarea>
              <textarea class="form-control" name="footer" rows="2" placeholder="Pied de page"></textarea>
              <label class="form-check"><input class="form-check-input" type="checkbox" name="show_extrafields" value="1" checked> Afficher les extrafields dans le document</label>
              <button class="btn btn-primary"><i class="bi bi-save"></i> Sauver modèle</button>
            </form>
            <div class="mt-3 small text-muted">Modèles existants : <?= e(implode(', ', array_map(fn($t)=>$t['name'] ?? '', $templates))) ?></div>
          </div>
        </div>

        <div class="col-12">
          <div class="tw-custom-card p-4">
            <div class="d-flex gap-3 align-items-center mb-3"><span class="tw-section-icon"><i class="bi bi-diagram-3"></i></span><div><h2 class="h5 mb-0">Workflows personnalisables</h2><small class="text-muted">Règles métier prêtes pour n8n/IA. En phase 19, elles restent sécurisées et contrôlées.</small></div></div>
            <form method="post" action="api/customization.php" class="row g-2 align-items-end mb-3">
              <input type="hidden" name="_csrf" value="<?= e($csrf) ?>"><input type="hidden" name="action" value="add_workflow">
              <div class="col-md-4"><label class="form-label">Nom<input class="form-control" name="name" placeholder="Ex: Relance client VIP"></label></div>
              <div class="col-md-3"><label class="form-label">Déclencheur<input class="form-control" name="trigger" placeholder="invoice.overdue"></label></div>
              <div class="col-md-3"><label class="form-label">Action<input class="form-control" name="action" placeholder="prepare_email"></label></div>
              <div class="col-md-2"><button class="btn btn-primary w-100"><i class="bi bi-plus-lg"></i> Ajouter</button></div>
              <div class="col-12"><label class="form-check"><input class="form-check-input" type="checkbox" name="enabled" value="1" checked> Actif</label></div>
            </form>
            <div class="table-responsive"><table class="table align-middle"><thead><tr><th>Nom</th><th>Déclencheur</th><th>Action</th><th>Statut</th></tr></thead><tbody><?php foreach ($workflows as $wf): ?><tr><td><?= e($wf['name']) ?></td><td><code><?= e($wf['trigger']) ?></code></td><td><code><?= e($wf['action']) ?></code></td><td><?= !empty($wf['enabled'])?'<span class="badge text-bg-success">Actif</span>':'<span class="badge text-bg-secondary">Inactif</span>' ?></td></tr><?php endforeach; ?></tbody></table></div>
          </div>
        </div>
      </div>
    </section>
  </main>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
