<?php $_GET['type']='invoice'; require __DIR__.'/document-editor.php';
