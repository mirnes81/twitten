<?php
declare(strict_types=1);
require_once __DIR__ . '/../private/twitten/app/Core/bootstrap.php';
use Twitten\Dolibarr\DolibarrConfigDetector;
use Twitten\Search\SearchEngine;

$csrf = \Twitten\Core\Security::csrfToken();
try {
    $detector = new DolibarrConfigDetector(dirname(__DIR__));
    $config = $detector->detect();
    $pdo = $detector->pdo($config);
    $engine = new SearchEngine($pdo, $config['db_prefix'] ?? 'llx_', dirname(__DIR__).'/storage/search_index');
    $status = $engine->status();
} catch (Throwable $e) { $status = ['exists'=>false, 'count'=>0, 'built_at'=>null, 'error'=>$e->getMessage()]; }
?>
<!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="twitten-csrf" content="<?= htmlspecialchars($csrf, ENT_QUOTES) ?>"><title>Twitten — Index recherche</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"><link href="assets/twitten.css" rel="stylesheet"></head>
<body class="p-4"><main class="container"><div class="tw-card p-4"><h1>Moteur de recherche Twitten</h1><p class="text-muted">Cette page reconstruit l’index local utilisé par la barre de recherche ultra rapide.</p><div class="alert alert-info">Index actuel : <strong><?= $status['exists'] ? 'présent' : 'absent' ?></strong> · <?= (int)($status['count'] ?? 0) ?> éléments · <?= htmlspecialchars((string)($status['built_at'] ?? 'jamais')) ?></div><form id="reindexForm" class="d-flex gap-2"><input class="form-control" name="limit" type="number" value="1500" min="50" max="10000"><button class="btn btn-primary">Reconstruire l’index</button><a class="btn btn-outline-secondary" href="index.php">Retour</a></form><pre id="result" class="mt-3 bg-body-tertiary p-3 rounded"></pre></div></main><script>document.getElementById('reindexForm').addEventListener('submit',async e=>{e.preventDefault();const csrf=document.querySelector('meta[name="twitten-csrf"]').content;const fd=new FormData(e.target);const r=await fetch('api/reindex.php',{method:'POST',headers:{'X-CSRF-Token':csrf},body:fd});document.getElementById('result').textContent=JSON.stringify(await r.json(),null,2);});</script></body></html>
