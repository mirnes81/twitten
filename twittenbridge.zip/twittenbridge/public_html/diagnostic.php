<?php require __DIR__ . '/check-path.php';
