<?php
require __DIR__ . '/bootstrap.php';
$prep = tw_prepare_private();
$message = '';
$existing = tw_load_config() ?: [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $bridgeUrl = trim($_POST['bridge_url'] ?? '');
    // Correction automatique si l'utilisateur met /custom/twittenbridge/api.php
    $bridgeUrl = str_replace('/custom/twittenbridge/api.php', '/custom/twittenbridge/api/api.php', $bridgeUrl);
    $cfg = [
        'installed_at' => $existing['installed_at'] ?? date('c'),
        'updated_at' => date('c'),
        'dolibarr_url' => rtrim($_POST['dolibarr_url'] ?? '', '/'),
        'bridge_url' => $bridgeUrl,
        'bridge_key' => trim($_POST['bridge_key'] ?? ''),
        'mode' => 'readonly',
    ];
    if (tw_save_config($cfg)) { header('Location: index.php?installed=1'); exit; }
    $message = 'Impossible de créer le fichier config. Vérifie les droits du dossier config/storage.';
}
$configExists = $prep['private'] && file_exists($prep['private'].'/config/config.php');
$cfg = $existing ?: ['dolibarr_url'=>'https://crm.mv-3pro.ch','bridge_url'=>'https://crm.mv-3pro.ch/custom/twittenbridge/api/api.php','bridge_key'=>''];
function h($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
?><!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Installation Twitten</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"><link href="assets/twitten.css" rel="stylesheet"></head><body class="tw-bg"><div class="container py-5"><div class="row justify-content-center"><div class="col-lg-7"><div class="card shadow-sm border-0"><div class="card-body p-4"><h1 class="h2 mb-2">Configuration Twitten</h1><p class="text-muted">Connexion Twitten ↔ Dolibarr Bridge.</p><?php if($message): ?><div class="alert alert-danger"><?=h($message)?></div><?php endif; ?><div class="mb-3 small"><b>Private:</b> <?=h($prep['private'] ?: 'introuvable')?><br><b>Storage writable:</b> <?=($prep['private'] && tw_is_writable_dir($prep['private'].'/storage'))?'OK':'PAS OK'?><br><b>Config:</b> <?=$configExists?'OK':'à créer'?><br><b>PHP:</b> <?=h(PHP_VERSION)?></div><form method="post"><label class="form-label">URL Dolibarr</label><input class="form-control mb-3" name="dolibarr_url" value="<?=h($cfg['dolibarr_url'] ?? 'https://crm.mv-3pro.ch')?>"><label class="form-label">URL Bridge Dolibarr</label><input class="form-control mb-3" name="bridge_url" value="<?=h($cfg['bridge_url'] ?? 'https://crm.mv-3pro.ch/custom/twittenbridge/api/api.php')?>"><label class="form-label">Clé API Bridge</label><input class="form-control mb-3" name="bridge_key" value="<?=h($cfg['bridge_key'] ?? '')?>" placeholder="TWB_..."><button class="btn btn-primary btn-lg">Enregistrer la configuration</button> <a class="btn btn-outline-secondary btn-lg" href="bridge-test.php">Tester Bridge</a> <a class="btn btn-outline-secondary btn-lg" href="check-path.php">Diagnostic chemin</a></form></div></div></div></div></div></body></html>
