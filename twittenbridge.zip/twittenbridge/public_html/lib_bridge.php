<?php
require_once __DIR__ . '/bootstrap.php';
function tw_h($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function tw_bridge_call(string $action, array $params = []): array {
    $cfg = tw_load_config() ?: [];
    $bridge = trim((string)($cfg['bridge_url'] ?? ''));
    $key = trim((string)($cfg['bridge_key'] ?? ''));
    if ($bridge === '' || $key === '') return ['ok'=>false,'error'=>'Bridge ou clé API non configuré', 'config'=>$cfg];
    $bridge = str_replace('/custom/twittenbridge/api.php', '/custom/twittenbridge/api/api.php', $bridge);
    $query = http_build_query(array_merge(['action'=>$action,'key'=>$key], $params));
    $url = $bridge . (strpos($bridge, '?') === false ? '?' : '&') . $query;
    $ctx = stream_context_create(['http'=>['timeout'=>15,'ignore_errors'=>true,'header'=>"Accept: application/json\r\n"]]);
    $raw = @file_get_contents($url, false, $ctx);
    if ($raw === false) return ['ok'=>false,'error'=>'Impossible de contacter le Bridge','url'=>$url];
    $json = json_decode($raw, true);
    if (!is_array($json)) return ['ok'=>false,'error'=>'Réponse Bridge invalide','url'=>$url,'raw'=>$raw];
    $json['_url'] = $url;
    return $json;
}
