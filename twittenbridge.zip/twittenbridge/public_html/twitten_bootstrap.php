<?php
function tw_private_base() {
    $root = dirname(__DIR__);
    $candidates = [
        $root.'/software_data/twitten',
        $root.'/private/twitten',
        dirname($root).'/software_data/twitten',
        dirname($root).'/private/twitten',
        __DIR__.'/.twitten_private'
    ];
    foreach ($candidates as $c) if (is_dir($c) && is_writable($c)) return $c;
    return $root.'/software_data/twitten';
}
function tw_config_path() { return tw_private_base().'/config/config.php'; }
function tw_config() {
    $file = tw_config_path();
    if (is_file($file)) { $cfg = include $file; if (is_array($cfg)) return $cfg; }
    return ['dolibarr_url'=>'https://crm.mv-3pro.ch','bridge_url'=>'','bridge_key'=>''];
}
