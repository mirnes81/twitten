<?php
function tw_config(){
    $candidates=[
        dirname(__DIR__).'/software_data/twitten/config/config.php',
        dirname(__DIR__).'/private/twitten/config/config.php',
        __DIR__.'/.twitten_private/config/config.php'
    ];
    foreach($candidates as $base){ if(file_exists($base)){ $cfg=include $base; if(is_array($cfg)) return $cfg; }}
    return ['bridge_url'=>'https://crm.mv-3pro.ch/custom/twittenbridge/api/api.php','api_key'=>'','bridge_key'=>''];
}
function tw_bridge_url(array $c): string {
    $url=$c['bridge_url'] ?? $c['bridge'] ?? 'https://crm.mv-3pro.ch/custom/twittenbridge/api/api.php';
    if(strpos($url,'/custom/twittenbridge/api.php')!==false) $url=str_replace('/custom/twittenbridge/api.php','/custom/twittenbridge/api/api.php',$url);
    if(substr($url,-7)!=='api.php') $url=rtrim($url,'/').'/api/api.php';
    return $url;
}
function tw_call($action,$params=[],$post=null){
    $c=tw_config(); $key=$c['api_key'] ?? $c['bridge_key'] ?? $c['key'] ?? '';
    $params=array_merge(['action'=>$action,'key'=>$key],$params);
    $url=tw_bridge_url($c);
    $writeActions=['add_note','create_task','prepare_reminder','generate_pdf','propal_line_add','propal_line_update','propal_line_delete','invoice_line_add','invoice_line_update','invoice_line_delete'];
    if($post===null) $post=in_array($action,$writeActions,true);
    $ctxOpt=['http'=>['timeout'=>25,'ignore_errors'=>true,'header'=>"Accept: application/json\r\n"]];
    if($post){ $ctxOpt['http']['method']='POST'; $ctxOpt['http']['header'].="Content-Type: application/x-www-form-urlencoded\r\n"; $ctxOpt['http']['content']=http_build_query($params); }
    else { $url.='?'.http_build_query($params); }
    $raw=@file_get_contents($url,false,stream_context_create($ctxOpt));
    $json=json_decode((string)$raw,true);
    if(!is_array($json)) return ['ok'=>false,'error'=>'Réponse Bridge invalide','raw'=>substr((string)$raw,0,700),'url'=>$url];
    return $json;
}
function h($s){return htmlspecialchars((string)$s,ENT_QUOTES,'UTF-8');}
function money($v){return number_format((float)$v,2,'.',"'").' CHF';}
