<?php
$id=(int)($_GET['id']??0);
header('Location: object.php?type=propal&id='.$id);
exit;
