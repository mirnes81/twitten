<?php

function mv3mail_h($value)
{
    return dol_escape_htmltag((string) $value);
}

/** Retourne la reference et le libelle du projet lie au document. */
function mv3mail_get_project_data($document)
{
    $project = null;
    if (!empty($document->project) && is_object($document->project)) $project = $document->project;
    if ((!is_object($project) || empty($project->id)) && !empty($document->fk_project) && !empty($document->db)) {
        require_once DOL_DOCUMENT_ROOT.'/projet/class/project.class.php';
        $candidate = new Project($document->db);
        if ($candidate->fetch((int) $document->fk_project) > 0) $project = $candidate;
    }
    if (!is_object($project) || empty($project->id)) return array('ref' => '', 'title' => '', 'display' => '');
    $ref = isset($project->ref) ? trim((string) $project->ref) : '';
    $title = isset($project->title) ? trim((string) $project->title) : '';
    if ($title === '' && isset($project->label)) $title = trim((string) $project->label);
    $display = trim($ref.($ref !== '' && $title !== '' ? ' - ' : '').$title);
    return array('ref' => $ref, 'title' => $title, 'display' => $display);
}

/** Construit la note libre définie dans la configuration du module. */
function mv3mail_build_custom_note_html()
{
    $note = trim((string) getDolGlobalString('MV3MAIL_CUSTOM_NOTE'));
    if ($note === '') return '';
    $safeNote = nl2br(mv3mail_h($note));
    return '<tr><td style="padding:0 28px 24px;"><table role="presentation" width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#fff8e8" style="width:100%;border-collapse:separate;background:#fff8e8;border-left:4px solid #f3c45a;border-radius:10px;"><tr><td style="padding:16px 18px;"><div style="font-size:11px;line-height:15px;font-weight:bold;letter-spacing:1px;color:#9a6818;">NOTE</div><div style="padding-top:6px;font-size:13px;line-height:21px;color:#4b5563;">'.$safeNote.'</div></td></tr></table></td></tr>';
}

function mv3mail_portal_token($type, $document)
{
    // Secret stable : il ne disparaît pas lorsque le module est désactivé puis réactivé.
    $secret = getDolGlobalString('MAIN_SECURITY_SALT');
    if ($secret === '') $secret = hash('sha256', DOL_DATA_ROOT.'|mv3mail-portal-stable');
    return hash_hmac('sha256', $type.'|'.((int) $document->id).'|'.((string) $document->ref), $secret);
}

function mv3mail_portal_legacy_token($type, $document)
{
    $secret = getDolGlobalString('MV3MAIL_PORTAL_SECRET');
    if ($secret === '') return '';
    return hash_hmac('sha256', $type.'|'.((int) $document->id).'|'.((string) $document->ref), $secret);
}

/**
 * Liens emis avant la stabilisation de la cle de portail.
 * La correspondance document + jeton evite toute acceptation generale de
 * signatures inconnues. Apres validation, portal.php redirige vers le lien
 * stable actuel.
 */
function mv3mail_is_migrated_legacy_link($type, $document, $token)
{
    $known = array(
        'inv:2573' => '9811e4d9250861ac506abbca8308bb2b84f70ba279b89b3072754bde727e6e19f',
    );
    $key = (string) $type.':'.((int) $document->id);
    return isset($known[$key]) && hash_equals($known[$key], (string) $token);
}

function mv3mail_portal_url($type, $document)
{
    return dol_buildpath('/custom/mv3mail/portal.php', 2).'?type='.rawurlencode($type).'&id='.((int) $document->id).'&token='.rawurlencode(mv3mail_portal_token($type, $document));
}

function mv3mail_portal_action_token($type, $document, $action)
{
    return hash_hmac('sha256', (string) $action, mv3mail_portal_token($type, $document));
}

function mv3mail_sumup_create_hosted_checkout($document, $redirectUrl, &$error)
{
    global $conf;
    $apiKey = getDolGlobalString('MV3MAIL_SUMUP_API_KEY');
    $merchantCode = getDolGlobalString('MV3MAIL_SUMUP_MERCHANT_CODE');
    if ($apiKey === '' || $merchantCode === '') { $error = 'La configuration SumUp est incomplète.'; return ''; }
    try { $nonce = bin2hex(random_bytes(4)); } catch (Exception $e) { $nonce = substr(hash('sha256', uniqid('', true)), 0, 8); }
    $payload = json_encode(array(
        'merchant_code' => $merchantCode,
        'amount' => round((float) $document->total_ttc, 2),
        'currency' => (string) $conf->currency,
        'checkout_reference' => substr('MV3-'.$document->ref.'-'.$document->id.'-'.time().'-'.$nonce, 0, 90),
        'description' => 'Facture MV-3 PRO '.$document->ref,
        'redirect_url' => $redirectUrl,
        'hosted_checkout' => array('enabled' => true)
    ));
    $response = false; $status = 0;
    if (function_exists('curl_init')) {
        $curl = curl_init('https://api.sumup.com/v0.1/checkouts');
        curl_setopt_array($curl, array(CURLOPT_POST => true, CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 20, CURLOPT_HTTPHEADER => array('Authorization: Bearer '.$apiKey, 'Content-Type: application/json'), CURLOPT_POSTFIELDS => $payload));
        $response = curl_exec($curl); $status = (int) curl_getinfo($curl, CURLINFO_HTTP_CODE);
        if ($response === false) $error = curl_error($curl);
        curl_close($curl);
    } elseif (ini_get('allow_url_fopen')) {
        $context = stream_context_create(array('http' => array('method' => 'POST', 'timeout' => 20, 'ignore_errors' => true, 'header' => "Authorization: Bearer ".$apiKey."\r\nContent-Type: application/json\r\n", 'content' => $payload)));
        $response = @file_get_contents('https://api.sumup.com/v0.1/checkouts', false, $context);
        if (!empty($http_response_header[0]) && preg_match('/\s([0-9]{3})\s/', $http_response_header[0], $match)) $status = (int) $match[1];
    }
    $decoded = is_string($response) ? json_decode($response, true) : null;
    if ($status >= 200 && $status < 300 && !empty($decoded['hosted_checkout_url'])) return $decoded['hosted_checkout_url'];
    if ($error === '') $error = !empty($decoded['message']) ? (string) $decoded['message'] : 'SumUp n’a pas pu créer la session de paiement.';
    return '';
}

function mv3mail_find_document_pdf($invoice, $outputDir)
{
    global $conf;
    if (!empty($invoice->last_main_doc)) {
        $candidate = DOL_DATA_ROOT.'/'.$invoice->last_main_doc;
        if (is_readable($candidate) && is_file($candidate)) return $candidate;
    }
    require_once DOL_DOCUMENT_ROOT.'/core/lib/files.lib.php';
    $ref = dol_sanitizeFileName($invoice->ref);
    $dir = $outputDir.'/'.$ref;
    $fileparams = dol_most_recent_file($dir, preg_quote($ref, '/').'[^\-]+');
    return !empty($fileparams['fullname']) ? $fileparams['fullname'] : '';
}

function mv3mail_preview_assets()
{
    $height = max(520, min(1200, (int) getDolGlobalString('MV3MAIL_PREVIEW_HEIGHT', '760')));
    return '<style id="mv3mail-preview-style">'
        .'#mailform .cke{width:100%!important;max-width:none!important}'
        .'#mailform .cke_contents,#mailform .cke_wysiwyg_frame,#mailform iframe.cke_wysiwyg_frame{height:'.$height.'px!important;min-height:'.$height.'px!important}'
        .'#mailform textarea#message{height:'.$height.'px!important;min-height:'.$height.'px!important;width:100%!important}'
        .'#mv3mail-preview-banner{display:flex;align-items:center;justify-content:space-between;padding:12px 16px;background:#14274e;color:#fff;border-radius:8px 8px 0 0;font:600 13px Arial,sans-serif;letter-spacing:.3px}'
        .'#mv3mail-preview-banner span{color:#f3c45a;font-weight:400;font-size:12px}'
        .'#mv3mail-note-composer{margin:0 0 14px;padding:15px 16px;background:#fff8e8;border:1px solid #f1d58d;border-radius:8px;font:13px Arial,sans-serif;color:#14274e}'
        .'#mv3mail-note-composer label{display:block;margin-bottom:7px;font-weight:bold}'
        .'#mv3mail-note-composer textarea{box-sizing:border-box;width:100%;min-height:78px;padding:10px 12px;border:1px solid #d8dde6;border-radius:6px;background:#fff;font:13px/1.5 Arial,sans-serif;resize:vertical}'
        .'#mv3mail-note-composer small{display:block;padding-top:6px;color:#6b7280}'
        .'</style>'
        .'<script>(function(){function esc(s){return s.replace(/[&<>\"]/g,function(c){return{"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;"}[c]})}function editorIn(f){if(!window.CKEDITOR||!CKEDITOR.instances)return null;var found=null;Object.keys(CKEDITOR.instances).some(function(k){var e=CKEDITOR.instances[k];if(e&&e.container&&f.contains(e.container.$)){found=e;return true}return false});return found}function applyNote(f,value){var e=editorIn(f);if(!e)return;var data=e.getData().replace(/<!--MV3NOTE-->[\s\S]*?<!--\/MV3NOTE-->/g,"");value=value.trim();if(value){var box="<table role=\"presentation\" align=\"center\" width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" bgcolor=\"#fff8e8\" style=\"width:100%;max-width:680px;margin:16px auto 0;border-collapse:separate;background:#fff8e8;border:1px solid #f1d58d;border-radius:14px;\"><tr><td style=\"padding:18px 22px;\"><div style=\"font-size:11px;line-height:15px;font-weight:bold;letter-spacing:1.4px;color:#9a6818;\">NOTE POUR CET ENVOI</div><div style=\"padding-top:8px;font-size:13px;line-height:21px;color:#4b5563;\">"+esc(value).replace(/\n/g,"<br>")+"</div></td></tr></table>";var html="<!--MV3NOTE-->"+box+"<!--/MV3NOTE-->";data=data.indexOf("<!--MV3NOTE_SLOT-->")!==-1?data.replace("<!--MV3NOTE_SLOT-->",html+"<!--MV3NOTE_SLOT-->"):data+html}e.setData(data)}var h='.$height.',n=0,t=setInterval(function(){n++;var f=document.getElementById("mailform");if(!f){if(n>60)clearInterval(t);return}var e=editorIn(f),ok=false;if(e){try{e.resize("100%",h,true);ok=true}catch(x){}}var box=f.querySelector(".cke");if(box&&!document.getElementById("mv3mail-preview-banner")){box.insertAdjacentHTML("beforebegin","<div id=\"mv3mail-note-composer\"><label for=\"mv3mail-oneoff-note\">Note pour cet envoi</label><textarea id=\"mv3mail-oneoff-note\" placeholder=\"Écrivez ici une information uniquement pour cet e-mail…\"></textarea><small>Cette note est ajoutée à l’e-mail actuel sans modifier le modèle permanent.</small></div><div id=\"mv3mail-preview-banner\"><b>APERÇU MV-3 PRO</b><span>Ce contenu sera envoyé avec le PDF</span></div>");document.getElementById("mv3mail-oneoff-note").addEventListener("input",function(){applyNote(f,this.value)})}f.querySelectorAll(".cke_contents,.cke_wysiwyg_frame,iframe.cke_wysiwyg_frame,textarea#message").forEach(function(el){el.style.setProperty("height",h+"px","important");el.style.setProperty("min-height",h+"px","important")});if(ok||n>60)clearInterval(t)},250)})();</script>';
}

/* ---------------------------------------------------------------------
 * Composants d'e-mail partagés
 *
 * Toutes les fonctions ci-dessous ne produisent QUE des balises autorisées
 * dans le corps CKEditor (table/tr/td/div/a avec attributs "style" en ligne).
 * Aucune balise <html>/<head>/<style> n'est utilisée : elle serait
 * silencieusement supprimée par CKEditor au moment de l'enregistrement du
 * formulaire d'envoi, ce qui annulerait la mise en forme avant même que
 * l'e-mail ne parte. C'est pour cette raison que la mise en page réactive
 * repose uniquement sur des tables fluides (width 100% + max-width) et sur
 * des commentaires conditionnels MSO, qui eux survivent au filtrage.
 * ------------------------------------------------------------------- */

/** Palette de marque unique, partagée par tous les e-mails et par le portail client. */
function mv3mail_email_theme()
{
    return array(
        'navy' => '#14274e', 'red' => '#da291c', 'red_soft' => '#fdeceb',
        'gold' => '#f3c45a', 'gold_soft' => '#fff3d6', 'gold_soft_text' => '#a45112',
        'bg' => '#eef1f6', 'line' => '#e2e6ee', 'muted' => '#6b7280', 'text' => '#111827',
    );
}

/** Enveloppe finale : préheader + fond + carte centrée de façon robuste (sans le
 * fragile duo de <td width="50%">) + mention légale sous la carte. */
function mv3mail_email_wrap($preheaderHtml, $cardRowsHtml, $legalHtml = '', $width = 680)
{
    $t = mv3mail_email_theme();
    $legal = $legalHtml !== '' ? '<table role="presentation" align="center" width="100%" border="0" cellpadding="0" cellspacing="0" style="width:100%;max-width:'.$width.'px;margin:0 auto;"><tr><td align="center" style="padding:18px 20px 0;font-size:11px;line-height:17px;color:#9aa2b1;text-align:center;">'.$legalHtml.'</td></tr></table>' : '';
    return '<div style="display:none;max-height:0;overflow:hidden;opacity:0;color:transparent;mso-hide:all;">'.$preheaderHtml.str_repeat('&nbsp;&zwnj;', 30).'</div>'
        .'<table role="presentation" width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="'.$t['bg'].'" style="width:100%;border-collapse:collapse;background:'.$t['bg'].';">'
        .'<tr><td align="center" style="padding:36px 16px;">'
        .'<!--[if mso]><table role="presentation" align="center" width="'.$width.'" style="width:'.$width.'px;"><tr><td><![endif]-->'
        .'<table role="presentation" align="center" width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#ffffff" style="width:100%;max-width:'.$width.'px;margin:0 auto;border-collapse:separate;background:#ffffff;border:1px solid '.$t['line'].';border-radius:20px;overflow:hidden;box-shadow:0 12px 30px rgba(20,39,78,.10);">'
        .$cardRowsHtml
        .'</table>'
        // Emplacement où la note ponctuelle (ajoutée depuis l'écran de composition) est
        // insérée par mv3mail_preview_assets(), afin qu'elle reste visuellement rattachée
        // à la carte plutôt que de retomber, isolée, tout en bas de l'e-mail.
        .'<!--MV3NOTE_SLOT-->'
        .'<!--[if mso]></td></tr></table><![endif]-->'
        .$legal
        .'</td></tr></table>';
}

/** En-tête de marque, identique sur les factures, commandes et devis. */
function mv3mail_email_brand_header()
{
    $t = mv3mail_email_theme();
    return '<tr><td height="6" bgcolor="'.$t['red'].'" style="height:6px;line-height:6px;font-size:0;background:'.$t['red'].';">&nbsp;</td></tr>'
        .'<tr><td align="center" bgcolor="'.$t['navy'].'" style="padding:36px 24px;background:'.$t['navy'].';">'
        .'<div style="font-size:30px;line-height:36px;font-weight:bold;letter-spacing:1px;color:#ffffff;text-align:center;">MV-3 <span style="color:#ef4b4b;">PRO</span></div>'
        .'<div style="padding-top:7px;font-size:12px;line-height:18px;letter-spacing:2px;color:#c3ccdc;text-align:center;">CARRELAGE&nbsp;&nbsp;&bull;&nbsp;&nbsp;PARQUET&nbsp;&nbsp;&bull;&nbsp;&nbsp;SANITAIRE</div>'
        .'</td></tr>';
}

/** Badge de catégorie + titre du document. */
function mv3mail_email_badge_title($badgeText, $titleHtml)
{
    $t = mv3mail_email_theme();
    return '<tr><td align="center" style="padding:38px 30px 10px;">'
        .'<table role="presentation" align="center" border="0" cellpadding="0" cellspacing="0" bgcolor="'.$t['red_soft'].'" style="margin:0 auto;background:'.$t['red_soft'].';border-radius:18px;"><tr><td style="padding:8px 16px;font-size:11px;line-height:14px;font-weight:bold;letter-spacing:1.6px;color:'.$t['red'].';">'.$badgeText.'</td></tr></table>'
        .'<div style="padding-top:14px;font-size:30px;line-height:38px;font-weight:bold;color:'.$t['navy'].';text-align:center;">'.$titleHtml.'</div>'
        .'</td></tr>';
}

/** Paragraphe de salutation. */
function mv3mail_email_greeting($customer, $message)
{
    return '<tr><td align="center" style="padding:10px 36px 30px;font-size:15px;line-height:25px;color:#4b5563;text-align:center;">Bonjour <strong style="color:#111827;">'.$customer.'</strong>,<br>'.$message.'</td></tr>';
}

/** Bandeau montant (navy + liseré or), avec pastille optionnelle (échéance / validité). */
function mv3mail_email_amount_panel($label, $amountValue, $pillLabel = '', $pillValue = '')
{
    $t = mv3mail_email_theme();
    $pill = '';
    if ($pillValue !== '') {
        $pill = '<tr><td align="center" style="padding:0 18px 26px;"><table role="presentation" align="center" border="0" cellpadding="0" cellspacing="0" bgcolor="'.$t['gold_soft'].'" style="margin:0 auto;background:'.$t['gold_soft'].';border-radius:20px;"><tr><td align="center" style="padding:9px 18px;font-size:12px;line-height:17px;font-weight:bold;color:'.$t['gold_soft_text'].';">'.$pillLabel.' '.$pillValue.'</td></tr></table></td></tr>';
    }
    return '<tr><td style="padding:0 28px 26px;"><table role="presentation" width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="'.$t['navy'].'" style="width:100%;border-collapse:separate;background:'.$t['navy'].';border-radius:16px;overflow:hidden;">'
        .'<tr><td height="4" bgcolor="'.$t['red'].'" style="height:4px;line-height:4px;font-size:0;background:'.$t['red'].';">&nbsp;</td></tr>'
        .'<tr><td align="center" style="padding:26px 18px 6px;"><div style="font-size:11px;line-height:16px;font-weight:bold;letter-spacing:1.6px;color:#b8c4d9;">'.$label.'</div><div style="padding-top:8px;font-size:44px;line-height:52px;font-weight:bold;color:'.$t['gold'].';">'.$amountValue.'</div></td></tr>'
        .$pill
        .'</table></td></tr>';
}

/** Encadré générique à en-tête (utilisé pour le tableau de détails). */
function mv3mail_email_box($titleText, $rowsHtml)
{
    if ($rowsHtml === '') return '';
    $t = mv3mail_email_theme();
    $header = $titleText !== '' ? '<tr><td colspan="2" style="padding:15px 16px;border-bottom:1px solid '.$t['line'].';font-size:14px;font-weight:bold;color:'.$t['navy'].';">'.$titleText.'</td></tr>' : '';
    return '<tr><td style="padding:0 28px 24px;"><table role="presentation" width="100%" border="0" cellpadding="0" cellspacing="0" style="width:100%;border-collapse:separate;border:1px solid '.$t['line'].';border-radius:12px;overflow:hidden;">'.$header.$rowsHtml.'</table></td></tr>';
}

/** Coordonnées bancaires — solution de repli pour le client qui préfère un virement manuel. */
function mv3mail_email_bank_block($bank, $iban)
{
    return '<tr><td style="padding:0 28px 24px;"><table role="presentation" width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#f7f9fb" style="width:100%;border-collapse:separate;background:#f7f9fb;border-left:4px solid #f3c45a;border-radius:10px;"><tr><td style="padding:17px 18px;"><div style="font-size:11px;line-height:15px;font-weight:bold;letter-spacing:1px;color:#9a6818;">PAIEMENT PAR VIREMENT</div><div style="padding-top:8px;font-size:13px;line-height:21px;color:#4b5563;">Banque&nbsp;: <strong style="color:#111827;">'.$bank.'</strong><br>IBAN&nbsp;: <strong style="color:#111827;">'.$iban.'</strong></div></td></tr></table></td></tr>';
}

/** Bouton d'appel à l'action principal (ex : "Voir et payer ma facture"). */
function mv3mail_email_cta($url, $label, $helper = '')
{
    $t = mv3mail_email_theme();
    $html = '<tr><td align="center" style="padding:4px 28px 34px;">'
        .'<table role="presentation" align="center" border="0" cellpadding="0" cellspacing="0" bgcolor="'.$t['red'].'" style="margin:0 auto;border-collapse:separate;background:'.$t['red'].';border-radius:10px;"><tr><td align="center" bgcolor="'.$t['red'].'" style="padding:17px 34px;background:'.$t['red'].';border-radius:10px;"><a href="'.$url.'" style="display:block;font-size:16px;line-height:22px;font-weight:bold;color:#ffffff;text-decoration:none;">'.$label.'</a></td></tr></table>';
    if ($helper !== '') $html .= '<div style="padding-top:16px;font-size:11px;line-height:18px;color:#8b93a3;">'.$helper.'</div>';
    return $html.'</td></tr>';
}

/** Ligne de contact ("une question ?"). */
function mv3mail_email_contact_row($email, $phone)
{
    return '<tr><td align="center" style="padding:0 30px 28px;font-size:13px;line-height:21px;color:#6b7280;text-align:center;">Une question ? R&eacute;pondez directement &agrave; cet e-mail ou contactez-nous &agrave; <a href="mailto:'.$email.'" style="font-weight:bold;color:#14274e;text-decoration:none;">'.$email.'</a> &nbsp;&bull;&nbsp; <strong style="color:#14274e;">'.$phone.'</strong></td></tr>';
}

/** Pied de marque (bandeau navy en bas de carte). */
function mv3mail_email_brand_footer($email, $phone, $attachmentNote)
{
    $t = mv3mail_email_theme();
    return '<tr><td align="center" bgcolor="'.$t['navy'].'" style="padding:26px 20px;background:'.$t['navy'].';text-align:center;">'
        .'<div style="font-size:18px;font-weight:bold;color:#ffffff;">MV-3 <span style="color:#ef4b4b;">PRO</span></div>'
        .'<div style="padding-top:8px;font-size:11px;line-height:18px;color:#c3ccdc;">'.$email.' &nbsp;&bull;&nbsp; '.$phone.'</div>'
        .($attachmentNote !== '' ? '<div style="padding-top:11px;font-size:10px;line-height:16px;color:#8b96ad;">'.$attachmentNote.'</div>' : '')
        .'</td></tr>';
}

function mv3mail_build_invoice_compact_html($invoice)
{
    global $conf, $langs;
    $ref = mv3mail_h($invoice->ref);
    $customer = mv3mail_h(is_object($invoice->thirdparty) ? $invoice->thirdparty->name : '');
    $invoiceDate = !empty($invoice->date) ? dol_print_date($invoice->date, '%d.%m.%Y') : '';
    $dueDate = !empty($invoice->date_lim_reglement) ? dol_print_date($invoice->date_lim_reglement, '%d.%m.%Y') : '';
    $amount = mv3mail_h(price((float) $invoice->total_ttc, 0, $langs, 1, -1, -1, ''));
    $currency = mv3mail_h($conf->currency);
    $portal = mv3mail_h(mv3mail_portal_url('inv', $invoice));
    $email = mv3mail_h(getDolGlobalString('MV3MAIL_EMAIL', 'info@mv-3pro.ch'));
    $phone = mv3mail_h(getDolGlobalString('MV3MAIL_PHONE', '+41 21 559 84 73'));
    $bank = mv3mail_h(getDolGlobalString('MV3MAIL_BANK_NAME', 'UBS - Morges'));
    $iban = mv3mail_h(getDolGlobalString('MV3MAIL_IBAN', 'CH29 3000 5204 2882 5201 N'));
    $project = mv3mail_get_project_data($invoice);

    $rows = mv3mail_detail_row('R&eacute;f&eacute;rence', $ref, true);
    if ($project['display'] !== '') $rows .= mv3mail_detail_row('Projet', mv3mail_h($project['display']));
    $rows .= mv3mail_detail_row('Date de facture', mv3mail_h($invoiceDate));
    $rows .= mv3mail_detail_row('Date d&rsquo;&eacute;ch&eacute;ance', mv3mail_h($dueDate), true, '#da291c');
    $rows .= mv3mail_detail_row('Total TTC', $amount.' '.$currency, true, '#14274e', true);

    $card = mv3mail_email_brand_header()
        .mv3mail_email_badge_title('VOTRE FACTURE EST DISPONIBLE', 'Facture '.$ref)
        .mv3mail_email_greeting($customer, 'Votre facture est disponible en pi&egrave;ce jointe et depuis votre espace client s&eacute;curis&eacute;.')
        .mv3mail_email_amount_panel('MONTANT &Agrave; R&Eacute;GLER', $amount.' '.$currency, '&Agrave; r&eacute;gler avant le', mv3mail_h($dueDate))
        .mv3mail_email_box('D&eacute;tails de la facture', $rows)
        .mv3mail_build_document_extrafields_section($invoice, 'Facture')
        .mv3mail_build_custom_note_html()
        .mv3mail_email_bank_block($bank, $iban)
        .mv3mail_email_cta($portal, 'Voir et payer ma facture &nbsp;&rarr;', 'Lien personnel et s&eacute;curis&eacute; &nbsp;&bull;&nbsp; facture PDF jointe')
        .mv3mail_email_contact_row($email, $phone)
        .mv3mail_email_brand_footer($email, $phone, 'Message g&eacute;n&eacute;r&eacute; automatiquement &middot; pi&egrave;ce jointe : '.$ref.'.pdf');

    $preheader = 'Facture '.$ref.' &middot; '.$amount.' '.$currency.($dueDate !== '' ? ' &middot; &eacute;ch&eacute;ance '.mv3mail_h($dueDate) : '');
    $legal = 'Facture &eacute;mise par MV-3 PRO. Merci de ne pas transmettre votre lien personnel &agrave; un tiers.';
    return mv3mail_email_wrap($preheader, $card, $legal);
}

/** Construit une section évolutive à partir des données standards et extrafields.
 * Une ligne vide n'est jamais affichée. */
function mv3mail_build_document_extrafields_section($document, $typeLabel)
{
    $rows = array();
    mv3mail_append_extrafields($rows, $document, '');

    if (!$rows) return '';
    $t = mv3mail_email_theme();
    $html = '<tr><td style="padding:0 28px 24px;"><table role="presentation" width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#f8fafc" style="width:100%;border-collapse:separate;background-color:#f8fafc;border:1px solid '.$t['line'].';border-radius:12px;overflow:hidden;"><tr><td colspan="2" bgcolor="#eef2f7" style="padding:15px 16px;border-bottom:1px solid '.$t['line'].';background-color:#eef2f7;"><div style="font-size:14px;font-weight:bold;color:'.$t['navy'].';">Informations compl&eacute;mentaires</div><div style="padding-top:3px;font-size:11px;line-height:16px;color:#6b7280;">Champs suppl&eacute;mentaires de la '.mv3mail_h(strtolower($typeLabel)).'</div></td></tr>';
    $index = 0;
    $count = count($rows);
    foreach ($rows as $label => $value) {
        $index++;
        $html .= mv3mail_detail_row($label, $value, false, '#111827', $index === $count);
    }
    return $html.'</table></td></tr>';
}

function mv3mail_append_extrafields(&$rows, $object, $prefix)
{
    global $langs;
    if (empty($object->array_options) || !is_array($object->array_options) || empty($object->table_element)) return;
    require_once DOL_DOCUMENT_ROOT.'/core/class/extrafields.class.php';
    $extra = new ExtraFields($object->db);
    $element = $object->table_element;
    $extra->fetch_name_optionals_label($element);
    foreach ($object->array_options as $optionKey => $rawValue) {
        if (strpos($optionKey, 'options_') !== 0 || $rawValue === '' || $rawValue === null || $rawValue === array()) continue;
        $key = substr($optionKey, 8);
        $label = isset($extra->attributes[$element]['label'][$key]) ? $extra->attributes[$element]['label'][$key] : $key;
        // Les conditions générales sont jointes au document et ne doivent pas
        // apparaître comme une ligne technique dans le corps de l'e-mail.
        if (preg_match('/(^|[^a-z])cgv([^a-z]|$)/i', (string) $key.' '.(string) $label)) continue;
        $translated = $langs->trans($label);
        if ($translated !== $label || strpos($label, ' ') !== false) $label = $translated;
        $formatted = $extra->showOutputField($key, $rawValue, '', $element, $langs, $object);
        if ($formatted !== '' && $formatted !== null) $rows[mv3mail_h(($prefix ? $prefix.' - ' : '').$label)] = $formatted;
    }
}

function mv3mail_build_sales_document_html($document, $typeLabel)
{
    global $conf, $langs;
    $ref = mv3mail_h($document->ref);
    $customer = mv3mail_h(is_object($document->thirdparty) ? $document->thirdparty->name : '');
    $date = !empty($document->date) ? dol_print_date($document->date, '%d.%m.%Y') : '';
    $amount = mv3mail_h(price((float) $document->total_ttc, 0, $langs, 1, -1, -1, ''));
    $currency = mv3mail_h($conf->currency);
    $isOrder = $typeLabel === 'Commande';
    $badge = $isOrder ? 'NOUVELLE COMMANDE' : 'NOUVEAU DEVIS';
    $message = $isOrder ? 'Votre confirmation de commande est disponible en pi&egrave;ce jointe.' : 'Votre devis est disponible en pi&egrave;ce jointe.';
    $secondLabel = $isOrder ? 'Date de livraison' : 'Valable jusqu&rsquo;au';
    $pillLabel = $isOrder ? 'Livraison pr&eacute;vue le' : 'Valable jusqu&rsquo;au';
    $secondRaw = $isOrder ? (!empty($document->date_livraison) ? $document->date_livraison : 0) : (!empty($document->fin_validite) ? $document->fin_validite : 0);
    $secondDate = $secondRaw ? dol_print_date($secondRaw, '%d.%m.%Y') : '';
    $email = mv3mail_h(getDolGlobalString('MV3MAIL_EMAIL', 'info@mv-3pro.ch'));
    $phone = mv3mail_h(getDolGlobalString('MV3MAIL_PHONE', '+41 21 559 84 73'));
    $project = mv3mail_get_project_data($document);

    $rows = mv3mail_detail_row('R&eacute;f&eacute;rence', $ref, true);
    if ($project['display'] !== '') $rows .= mv3mail_detail_row('Projet', mv3mail_h($project['display']));
    $rows .= mv3mail_detail_row('Date', mv3mail_h($date));
    if ($secondDate !== '') $rows .= mv3mail_detail_row($secondLabel, mv3mail_h($secondDate), true, '#da291c');
    $rows .= mv3mail_detail_row('Total TTC', $amount.' '.$currency, true, '#14274e', true);

    $card = mv3mail_email_brand_header()
        .mv3mail_email_badge_title($badge, mv3mail_h($typeLabel).' '.$ref)
        .mv3mail_email_greeting($customer, $message)
        .mv3mail_email_amount_panel('TOTAL TTC', $amount.' '.$currency, $secondDate !== '' ? $pillLabel : '', $secondDate !== '' ? mv3mail_h($secondDate) : '')
        .mv3mail_email_box('D&eacute;tails du document', $rows)
        .mv3mail_build_document_extrafields_section($document, $typeLabel)
        .mv3mail_build_custom_note_html()
        .mv3mail_email_contact_row($email, $phone)
        .mv3mail_email_brand_footer($email, $phone, 'Message g&eacute;n&eacute;r&eacute; automatiquement &middot; pi&egrave;ce jointe : '.$ref.'.pdf');

    $preheader = mv3mail_h($typeLabel).' '.$ref.' &middot; '.$amount.' '.$currency.($date !== '' ? ' &middot; '.mv3mail_h($date) : '');
    $legal = 'Cet e-mail concerne un document &eacute;mis par MV-3 PRO.';
    return mv3mail_email_wrap($preheader, $card, $legal);
}

function mv3mail_detail_row($label, $value, $bold = false, $color = '#111827', $last = false)
{
    $border = $last ? '' : 'border-bottom:1px solid #edf0f5;';
    return '<tr><td width="50%" style="padding:13px 16px;'.$border.'font-size:13px;color:#6b7280;">'.$label.'</td><td width="50%" align="right" style="padding:13px 16px;'.$border.'font-size:13px;'.($bold ? 'font-weight:bold;' : '').'color:'.$color.';">'.$value.'</td></tr>';
}
