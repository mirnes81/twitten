<?php
// Endpoint public pour les clients e-mail. Ne pas charger main.inc.php :
// Outlook doit pouvoir lire l'image sans session Dolibarr.
$amount = isset($_GET['amount']) ? preg_replace('/[^0-9.]/', '', (string) $_GET['amount']) : '';
$ref = isset($_GET['ref']) ? preg_replace('/[^A-Za-z0-9. _-]/', '', (string) $_GET['ref']) : '';
if ($amount === '' || $ref === '') {
    http_response_code(400);
    exit;
}

$sourceBase = 'https://crm.mv-3pro.ch/custom/swissbanking/qr_email.php';
$sourceUrl = $sourceBase.(strpos($sourceBase, '?') === false ? '?' : '&').'amount='.rawurlencode($amount).'&ref='.rawurlencode($ref);
$binary = '';
if (function_exists('curl_init')) {
    $curl = curl_init($sourceUrl);
    curl_setopt_array($curl, array(CURLOPT_RETURNTRANSFER => true, CURLOPT_FOLLOWLOCATION => true, CURLOPT_TIMEOUT => 12, CURLOPT_SSL_VERIFYPEER => true));
    $binary = (string) curl_exec($curl);
    curl_close($curl);
} elseif (ini_get('allow_url_fopen')) {
    $binary = (string) @file_get_contents($sourceUrl);
}

$image = $binary !== '' && function_exists('imagecreatefromstring') ? @imagecreatefromstring($binary) : false;
if (!$image) {
    header('Location: '.$sourceUrl, true, 302);
    exit;
}

imagesavealpha($image, true);
$width = imagesx($image);
$height = imagesy($image);
$side = max(30, (int) round(min($width, $height) * 0.19));
$x = (int) floor(($width - $side) / 2);
$y = (int) floor(($height - $side) / 2);
$white = imagecolorallocate($image, 255, 255, 255);
$swissRed = imagecolorallocate($image, 218, 41, 28);

// Zone blanche de protection, carré rouge suisse, puis croix blanche.
$quiet = max(3, (int) round($side * 0.12));
imagefilledrectangle($image, $x - $quiet, $y - $quiet, $x + $side + $quiet, $y + $side + $quiet, $white);
imagefilledrectangle($image, $x, $y, $x + $side, $y + $side, $swissRed);
$arm = max(3, (int) round($side * 0.20));
$long = (int) round($side * 0.68);
$cx = $x + (int) floor($side / 2);
$cy = $y + (int) floor($side / 2);
imagefilledrectangle($image, $cx - (int) floor($arm / 2), $cy - (int) floor($long / 2), $cx + (int) ceil($arm / 2), $cy + (int) ceil($long / 2), $white);
imagefilledrectangle($image, $cx - (int) floor($long / 2), $cy - (int) floor($arm / 2), $cx + (int) ceil($long / 2), $cy + (int) ceil($arm / 2), $white);

header('Content-Type: image/png');
header('Cache-Control: public, max-age=3600');
imagepng($image, null, 9);
imagedestroy($image);
