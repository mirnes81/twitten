# Mirnes Mail 2.4.0

Module Dolibarr 20 à 22 développé par [mirnes.ch](https://mirnes.ch), pour créer des e-mails professionnels de facture, commande et devis.

## Fonctionnement

- utilise le bouton natif **Envoyer email** de la facture ;
- injecte un HTML dynamique compatible Outlook dans le formulaire natif ;
- rattache explicitement le PDF officiel lorsque le modèle personnalisé neutralise le modèle d'e-mail Dolibarr ;
- conserve le PDF automatique, les destinataires, le SMTP, `BILL_SENTBYMAIL`, le compteur et la trace Agenda ;
- agrandit l'aperçu CKEditor (760 px par défaut), même lorsque Dolibarr réapplique sa hauteur après chargement ;
- construit le QR depuis le montant et la référence réels ;
- utilise trois présentations françaises distinctes : facture, commande et devis ;
- affiche la référence et le libellé du projet lié lorsqu’il existe ;
- utilise une présentation premium minimaliste, plus large et aérée, avec montant central prioritaire ;
- permet de rédiger dans la configuration une note facultative ajoutée automatiquement aux e-mails ;
- affiche uniquement les extrafields renseignés du document envoyé : facture pour facture, commande pour commande, devis pour devis ;
- affiche le QR et les coordonnées bancaires uniquement dans les e-mails de facture ;
- remplace le logo central du QR par un carré rouge suisse avec croix blanche, sans modifier les données de paiement ;
- masque systématiquement le champ CGV dans le corps des e-mails ;
- propose un e-mail compact avec un bouton vers un espace client sécurisé ;
- signe chaque lien avec un secret aléatoire propre à l'installation ;
- affiche sur la page client le QR, les extrafields du document et le téléchargement du PDF ;
- optimise l’espace client pour les smartphones et les commandes tactiles ;
- propose le paiement Visa/Mastercard avec le Hosted Checkout officiel SumUp ;
- conserve des liens signés stables après les mises à jour et réactivations du module ;
- invalide automatiquement OPcache afin que les nouveaux liens soient réellement générés ;
- remplace partout le favicon Dolibarr par le favicon MV-3 PRO ;
- migre automatiquement les anciens liens de portail connus vers la signature stable ;
- permet l'ouverture du portail par les clients sans compte Dolibarr, uniquement avec leur lien personnel signe ;
- permet de configurer QR, banque, IBAN, téléphone, e-mail et hauteur d'aperçu.

## Installation

1. Décompresser le ZIP dans `htdocs/custom/` afin d'obtenir `htdocs/custom/mv3mail/`.
2. Aller dans **Accueil > Configuration > Modules/Applications**.
3. Activer **Mirnes Mail**.
4. Ouvrir la configuration du module et vérifier les coordonnées.
5. Ouvrir une facture validée puis cliquer sur **Envoyer email**.

Le module ne remplace pas l'envoi Dolibarr : il modifie uniquement le contenu proposé dans le formulaire natif.

## Éditeur

Conception et développement : **mirnes.ch**.
