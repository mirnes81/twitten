<?php
if (!defined('NOREQUIREUSER')) define('NOREQUIREUSER', 1);
if (!defined('NOREQUIREDB')) define('NOREQUIREDB', 1);
if (!defined('NOREQUIRESOC')) define('NOREQUIRESOC', 1);
if (!defined('NOREQUIRETRAN')) define('NOREQUIRETRAN', 1);
if (!defined('NOCSRFCHECK')) define('NOCSRFCHECK', 1);
require '../../../main.inc.php';
header('Content-Type: text/css; charset=UTF-8');
$height = max(520, min(1200, (int) getDolGlobalString('MV3MAIL_PREVIEW_HEIGHT', '760')));
?>
/* Aperçu d'e-mail réellement lisible dans la fiche facture */
#mailform table.noborder { width: 100% !important; }
#mailform .cke { width: 100% !important; max-width: none !important; }
#mailform .cke_contents { height: <?php echo $height; ?>px !important; min-height: <?php echo $height; ?>px !important; }
#mailform .cke_wysiwyg_frame,
#mailform iframe.cke_wysiwyg_frame { height: 100% !important; min-height: <?php echo $height; ?>px !important; }
#mailform textarea#message { min-height: <?php echo $height; ?>px !important; width: 100% !important; font-family: Consolas, monospace; }
#mailform td:has(.cke) { padding-left: 0 !important; padding-right: 0 !important; }
@media (max-width: 800px) {
  #mailform .cke_contents, #mailform .cke_wysiwyg_frame, #mailform iframe.cke_wysiwyg_frame { min-height: 560px !important; height: 560px !important; }
}
