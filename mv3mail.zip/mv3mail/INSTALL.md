# Installation rapide

Copier le dossier `mv3mail` dans `htdocs/custom/`, activer le module, puis vérifier sa configuration.

Pré-requis : Dolibarr 20+, PHP 7.4+, module Factures activé.

## Paiement SumUp

1. Ouvrir les paramètres développeur du tableau de bord SumUp.
2. Créer une clé API restreinte autorisée à créer des paiements.
3. Dans la configuration **Mirnes Mail**, saisir le code marchand et la clé API.
4. Activer le paiement par carte SumUp.

La clé reste côté serveur. Le client saisit sa carte uniquement sur la page Hosted Checkout officielle de SumUp.

Module conçu et développé par **mirnes.ch**.
