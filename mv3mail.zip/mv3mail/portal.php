<?php
// Portail public par lien signe : le client n'a pas besoin d'un compte Dolibarr.
// Ces constantes doivent etre definies avant le chargement de main.inc.php.
if (!defined('NOLOGIN')) define('NOLOGIN', 1);
if (!defined('NOCSRFCHECK')) define('NOCSRFCHECK', 1);
if (!defined('NOIPCHECK')) define('NOIPCHECK', 1);
if (!defined('NOTOKENRENEWAL')) define('NOTOKENRENEWAL', 1);
require '../../main.inc.php';
require_once __DIR__.'/lib/mv3mail.lib.php';

$type = GETPOST('type', 'alpha');
$id = GETPOSTINT('id');
$token = GETPOST('token', 'aZ09');
$map = array('inv' => array('/compta/facture/class/facture.class.php', 'Facture', 'facture'));
if (!isset($map[$type]) || $id <= 0) { http_response_code(404); exit('Document introuvable'); }
require_once DOL_DOCUMENT_ROOT.$map[$type][0];
$document = new Facture($db);
if ($document->fetch($id) <= 0) { http_response_code(404); exit('Document introuvable'); }
$validToken = hash_equals(mv3mail_portal_token($type, $document), $token);
$legacyToken = mv3mail_portal_legacy_token($type, $document);
if (!$validToken && $legacyToken !== '') $validToken = hash_equals($legacyToken, $token);
$migratedLegacyLink = !$validToken && mv3mail_is_migrated_legacy_link($type, $document, $token);
if ($migratedLegacyLink) {
    header('Location: '.mv3mail_portal_url($type, $document), true, 302);
    exit;
}
if (!$validToken) {
    http_response_code(403);
    echo '<!doctype html><html lang="fr"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Lien expiré</title><body style="margin:0;background:#f3f5f9;font-family:Arial,sans-serif;color:#14274e"><div style="height:6px;background:#da291c"></div><div style="max-width:520px;margin:70px auto;padding:35px;background:#fff;border:1px solid #e3e7ee;border-radius:14px;text-align:center"><h1 style="margin-top:0">MV-3 <span style="color:#ef4b4b">PRO</span></h1><h2>Lien non valide</h2><p style="color:#697386;line-height:1.6">Ce lien a été créé avec une ancienne clé de sécurité. Veuillez demander un nouvel e-mail de facture.</p><a href="mailto:info@mv-3pro.ch" style="display:inline-block;margin-top:12px;padding:13px 20px;background:#da291c;color:#fff;text-decoration:none;border-radius:8px;font-weight:bold">Contacter MV-3 PRO</a></div></body></html>';
    exit;
}
header('X-Robots-Tag: noindex, nofollow, noarchive', true);
header('Cache-Control: private, no-store, max-age=0');
if (method_exists($document, 'fetch_thirdparty')) $document->fetch_thirdparty();
if (method_exists($document, 'fetch_optionals')) $document->fetch_optionals();

$sumupError = '';
if (GETPOST('action', 'alpha') === 'sumup_pay' && getDolGlobalInt('MV3MAIL_SUMUP_ENABLED') && hash_equals(mv3mail_portal_action_token($type, $document, 'sumup_pay'), GETPOST('pay_token', 'alphanohtml'))) {
    $returnUrl = mv3mail_portal_url($type, $document).'&sumup_return=1';
    $checkoutUrl = mv3mail_sumup_create_hosted_checkout($document, $returnUrl, $sumupError);
    if ($checkoutUrl !== '') { header('Location: '.$checkoutUrl, true, 303); exit; }
}

$pdf = mv3mail_find_document_pdf($document, $conf->facture->dir_output);
if (GETPOST('download', 'alpha') === 'pdf') {
    if (!$pdf || !is_readable($pdf)) { http_response_code(404); exit('PDF introuvable'); }
    header('Content-Type: application/pdf');
    header('Content-Disposition: attachment; filename="'.dol_sanitizeFileName($document->ref).'.pdf"');
    header('Content-Length: '.filesize($pdf));
    readfile($pdf); exit;
}

$customer = is_object($document->thirdparty) ? $document->thirdparty->name : '';
$amount = price((float) $document->total_ttc, 0, $langs, 1, -1, -1, '').' '.$conf->currency;
$due = !empty($document->date_lim_reglement) ? dol_print_date($document->date_lim_reglement, '%d.%m.%Y') : '';
$qr = dol_buildpath('/custom/mv3mail/qr_swiss.php', 2).'?amount='.rawurlencode((string) $document->total_ttc).'&ref='.rawurlencode($document->ref).'&style=portal-red';
$download = mv3mail_portal_url($type, $document).'&download=pdf';
$rows = array();
mv3mail_append_extrafields($rows, $document, '');
$project = mv3mail_get_project_data($document);
$sumupEnabled = getDolGlobalInt('MV3MAIL_SUMUP_ENABLED') && getDolGlobalString('MV3MAIL_SUMUP_API_KEY') !== '' && getDolGlobalString('MV3MAIL_SUMUP_MERCHANT_CODE') !== '';
?>
<!doctype html>
<html lang="fr"><head><meta charset="utf-8"><meta name="robots" content="noindex,nofollow,noarchive"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="color-scheme" content="light"><meta name="supported-color-schemes" content="light"><link rel="icon" type="image/svg+xml" href="<?php echo mv3mail_h(dol_buildpath('/custom/mv3mail/img/favicon.svg', 1)); ?>?v=213"><link rel="shortcut icon" type="image/svg+xml" href="<?php echo mv3mail_h(dol_buildpath('/custom/mv3mail/img/favicon.svg', 1)); ?>?v=213"><title><?php echo mv3mail_h('Facture '.$document->ref); ?></title>
<style>
:root{--navy:#14274e;--red:#da291c;--gold:#f3c45a;--bg:#eef1f6;--text:#172033;--muted:#697386;--line:#e2e6ee;color-scheme:light}*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--text);font-family:Arial,sans-serif;-webkit-text-size-adjust:100%}.top{height:6px;background:var(--red)}header{background:var(--navy);color:#fff;padding:25px max(20px,5vw);display:flex;justify-content:space-between;align-items:center}.logo{font-size:25px;font-weight:800}.logo span{color:#ef4b4b}.secure{font-size:12px;color:#cbd5e1}.wrap{max-width:1050px;margin:30px auto;padding:0 20px}.hero,.card{background:#fff;border:1px solid var(--line);border-radius:16px;box-shadow:0 8px 30px rgba(20,39,78,.07)}.hero{padding:30px;display:flex;justify-content:space-between;gap:25px;align-items:center}.badge{display:inline-block;padding:7px 12px;border-radius:20px;background:#fdeceb;color:var(--red);font-size:11px;font-weight:700;letter-spacing:.8px}.hero h1{margin:12px 0 5px;font-size:30px}.muted{color:var(--muted)}.amount{text-align:right}.amount strong{display:block;font-size:34px;color:var(--navy)}.grid{display:grid;grid-template-columns:1.1fr .9fr;gap:22px;margin-top:22px}.card{padding:25px}.qr{text-align:center}.qr img{width:210px;height:210px;border:1px solid var(--line);padding:12px}.btn{display:inline-flex;min-height:50px;align-items:center;justify-content:center;background:var(--red);color:#fff;text-decoration:none;padding:14px 20px;border:0;border-radius:9px;font:700 15px Arial,sans-serif;cursor:pointer;margin-top:15px}.btn-card{background:var(--navy);width:100%}.cards{font-size:12px;letter-spacing:.7px;margin-top:9px}.notice{padding:12px 14px;margin:0 0 18px;border-radius:9px;background:#fff4e5;color:#8a4b08}.success{background:#edf8f0;color:#176b32}.details .row{display:grid;grid-template-columns:1fr 1.4fr;gap:15px;padding:13px 0;border-bottom:1px solid var(--line)}.details .row span:first-child{color:var(--muted)}footer{text-align:center;padding:28px;color:var(--muted);font-size:12px}
@media(max-width:720px){header{padding:20px}.wrap{margin:18px auto;padding:0 12px}.hero,.card{border-radius:12px}.hero{display:block;padding:22px}.amount{text-align:left;margin-top:22px}.grid{grid-template-columns:1fr;gap:14px;margin-top:14px}.card{padding:20px}.hero h1{font-size:25px}.amount strong{font-size:29px}.qr img{width:190px;height:190px}.details .row{grid-template-columns:1fr;gap:5px}.btn{width:100%}.secure{font-size:11px}}
</style></head><body>
<div class="top"></div><header><div class="logo">MV-3 <span>PRO</span></div><div class="secure">Espace client sécurisé</div></header>
<main class="wrap">
<?php if (GETPOSTINT('sumup_return')) { ?><div class="notice success">Votre paiement a été traité par SumUp. La confirmation définitive reste disponible dans votre compte SumUp.</div><?php } ?>
<?php if ($sumupError !== '') { ?><div class="notice"><?php echo mv3mail_h($sumupError); ?></div><?php } ?>
<section class="hero"><div><span class="badge">FACTURE</span><h1><?php echo mv3mail_h($document->ref); ?></h1><div class="muted"><?php echo mv3mail_h($customer); ?></div></div><div class="amount"><span class="muted">Total TTC</span><strong><?php echo mv3mail_h($amount); ?></strong><?php if ($due) { ?><small>À régler avant le <?php echo mv3mail_h($due); ?></small><?php } ?></div></section>
<div class="grid"><section class="card qr"><h2>Choisissez votre paiement</h2>
<?php if ($sumupEnabled) { ?><form method="post"><input type="hidden" name="action" value="sumup_pay"><input type="hidden" name="pay_token" value="<?php echo mv3mail_h(mv3mail_portal_action_token($type, $document, 'sumup_pay')); ?>"><button class="btn btn-card" type="submit">Payer par carte avec SumUp</button><div class="cards muted">VISA · Mastercard · paiement sécurisé SumUp</div></form><?php } ?>
<p class="muted">Ou scannez le QR avec votre application e-banking.</p><img src="<?php echo mv3mail_h($qr); ?>" alt="QR de paiement"><br><a class="btn" href="<?php echo mv3mail_h($download); ?>">Télécharger la facture PDF</a></section>
<section class="card details"><h2>Informations</h2><div class="row"><span>Référence</span><strong><?php echo mv3mail_h($document->ref); ?></strong></div><div class="row"><span>Client</span><strong><?php echo mv3mail_h($customer); ?></strong></div><?php if ($project['display'] !== '') { ?><div class="row"><span>Projet</span><strong><?php echo mv3mail_h($project['display']); ?></strong></div><?php } ?><div class="row"><span>Montant TTC</span><strong><?php echo mv3mail_h($amount); ?></strong></div><?php foreach ($rows as $label => $value) { ?><div class="row"><span><?php echo $label; ?></span><strong><?php echo $value; ?></strong></div><?php } ?></section></div>
</main><footer>MV-3 PRO · info@mv-3pro.ch · +41 21 559 84 73</footer></body></html>
