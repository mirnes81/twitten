<?php
if (!defined('NOREQUIREUSER')) define('NOREQUIREUSER', 1);
if (!defined('NOREQUIREDB')) define('NOREQUIREDB', 1);
if (!defined('NOREQUIRESOC')) define('NOREQUIRESOC', 1);
if (!defined('NOREQUIRETRAN')) define('NOREQUIRETRAN', 1);
if (!defined('NOCSRFCHECK')) define('NOCSRFCHECK', 1);
require '../../../main.inc.php';
header('Content-Type: application/javascript; charset=UTF-8');
$height = max(520, min(1200, (int) getDolGlobalString('MV3MAIL_PREVIEW_HEIGHT', '760')));
?>
(function () {
    'use strict';
    var wantedHeight = <?php echo $height; ?>;
    var attempts = 0;

    function installMV3Favicon() {
        var href = <?php echo json_encode(dol_buildpath('/custom/mv3mail/img/favicon.svg', 1)); ?>;
        document.querySelectorAll('link[rel*="icon"], link[rel="apple-touch-icon"]').forEach(function (node) {
            node.parentNode.removeChild(node);
        });
        ['icon', 'shortcut icon', 'apple-touch-icon'].forEach(function (rel) {
            var link = document.createElement('link');
            link.rel = rel;
            link.type = 'image/svg+xml';
            link.href = href + '?v=213';
            document.head.appendChild(link);
        });
    }

    function enlargeMV3Editor() {
        attempts++;
        var mailForm = document.getElementById('mailform');
        if (!mailForm) return attempts < 40;

        var resized = false;
        if (window.CKEDITOR && window.CKEDITOR.instances) {
            Object.keys(window.CKEDITOR.instances).forEach(function (key) {
                var editor = window.CKEDITOR.instances[key];
                if (!editor || !editor.container || !mailForm.contains(editor.container.$)) return;
                try {
                    editor.resize('100%', wantedHeight, true);
                    resized = true;
                } catch (e) {}
            });
        }

        var selectors = ['.cke_contents', '.cke_wysiwyg_frame', 'iframe.cke_wysiwyg_frame', 'textarea#message'];
        selectors.forEach(function (selector) {
            mailForm.querySelectorAll(selector).forEach(function (node) {
                node.style.setProperty('height', wantedHeight + 'px', 'important');
                node.style.setProperty('min-height', wantedHeight + 'px', 'important');
            });
        });

        return !resized && attempts < 40;
    }

    function start() {
        installMV3Favicon();
        var timer = window.setInterval(function () {
            if (!enlargeMV3Editor()) window.clearInterval(timer);
        }, 250);
        enlargeMV3Editor();
    }

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start);
    else start();
}());
