<?php
require_once DOL_DOCUMENT_ROOT.'/core/class/commonhookactions.class.php';
require_once __DIR__.'/../lib/mv3mail.lib.php';

class ActionsMV3Mail extends CommonHookActions
{
    public $db;
    public $resprints = '';
    public $results = array();

    public function __construct($db)
    {
        $this->db = $db;
    }

    /** Injecte le HTML dans le formulaire natif Dolibarr. L'envoi, la pièce jointe,
     * le trigger BILL_SENTBYMAIL et la trace agenda restent gérés par le cœur. */
    public function getFormMail($parameters, &$formmail, &$action, $hookmanager)
    {
        if (!getDolGlobalInt('MV3MAIL_ENABLED_FOR_INVOICES', 1)) return 0;

        $trackid = isset($parameters['trackid']) ? (string) $parameters['trackid'] : '';
        if (!preg_match('/^(inv|ord|pro)([0-9]+)$/', $trackid, $m)) return 0;

        $prefix = $m[1];
        $id = (int) $m[2];
        if ($prefix === 'inv') {
            require_once DOL_DOCUMENT_ROOT.'/compta/facture/class/facture.class.php';
            $document = new Facture($this->db);
            $typeLabel = 'Facture';
            $outputDir = $GLOBALS['conf']->facture->dir_output;
        } elseif ($prefix === 'ord') {
            require_once DOL_DOCUMENT_ROOT.'/commande/class/commande.class.php';
            $document = new Commande($this->db);
            $typeLabel = 'Commande';
            $outputDir = $GLOBALS['conf']->commande->dir_output;
        } else {
            require_once DOL_DOCUMENT_ROOT.'/comm/propal/class/propal.class.php';
            $document = new Propal($this->db);
            $typeLabel = 'Devis';
            $outputDir = $GLOBALS['conf']->propal->dir_output;
        }
        if ($document->fetch($id) <= 0) return 0;
        if (method_exists($document, 'fetch_thirdparty')) $document->fetch_thirdparty();
        if (method_exists($document, 'fetch_optionals')) $document->fetch_optionals();
        if (method_exists($document, 'fetchProject')) $document->fetchProject();

        $formmail->param['models'] = 'none';
        $formmail->withbody = $prefix === 'inv' ? mv3mail_build_invoice_compact_html($document) : mv3mail_build_sales_document_html($document, $typeLabel);
        $formmail->withfckeditor = 1;
        $formmail->ckeditortoolbar = 'dolibarr_mailings';
        if (empty(GETPOST('subject', 'restricthtml'))) {
            $customer = is_object($document->thirdparty) ? $document->thirdparty->name : '';
            $formmail->withtopic = 'MV-3 PRO - '.$typeLabel.' '.$document->ref.($customer ? ' / '.$customer : '');
        }

        // get_form() efface d'abord la session en mode init, puis appelle ce hook.
        // Nous pouvons donc rattacher ici le PDF officiel sans perdre la trace native.
        if (GETPOST('mode', 'alpha') === 'init' || empty($formmail->get_attached_files()['paths'])) {
            $pdfPath = mv3mail_find_document_pdf($document, $outputDir);
            if ($pdfPath && is_readable($pdfPath)) {
                $formmail->add_attached_files($pdfPath, basename($pdfPath), 'application/pdf');
            }
        }

        // Injection directe : certains thèmes Dolibarr ne chargent pas les assets
        // JS/CSS déclarés par les modules sur la section presend.
        static $previewAssetsPrinted = false;
        if (!$previewAssetsPrinted) {
            $previewAssetsPrinted = true;
            print mv3mail_preview_assets();
        }
        return 0;
    }
}
