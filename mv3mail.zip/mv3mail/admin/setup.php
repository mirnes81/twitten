<?php
require '../../../main.inc.php';
require_once DOL_DOCUMENT_ROOT.'/core/lib/admin.lib.php';

// Les hébergements avec OPcache agressif peuvent conserver l'ancien générateur
// de liens après une mise à jour. L'ouverture de cette page force son rechargement.
if (function_exists('opcache_invalidate')) {
    @opcache_invalidate(__DIR__.'/../class/actions_mv3mail.class.php', true);
    @opcache_invalidate(__DIR__.'/../lib/mv3mail.lib.php', true);
    @opcache_invalidate(__DIR__.'/../portal.php', true);
    @opcache_invalidate(__DIR__.'/../qr_swiss.php', true);
}

if (!$user->admin) accessforbidden();
$langs->loadLangs(array('admin', 'mv3mail@mv3mail'));

$action = GETPOST('action', 'aZ09');
if ($action === 'save') {
    $keys = array('MV3MAIL_QR_BASE_URL', 'MV3MAIL_BANK_NAME', 'MV3MAIL_IBAN', 'MV3MAIL_PHONE', 'MV3MAIL_EMAIL', 'MV3MAIL_PREVIEW_HEIGHT', 'MV3MAIL_SUMUP_MERCHANT_CODE');
    foreach ($keys as $key) dolibarr_set_const($db, $key, GETPOST($key, 'restricthtml'), 'chaine', 0, '', $conf->entity);
    dolibarr_set_const($db, 'MV3MAIL_CUSTOM_NOTE', GETPOST('MV3MAIL_CUSTOM_NOTE', 'restricthtml'), 'chaine', 0, '', $conf->entity);
    dolibarr_set_const($db, 'MV3MAIL_ENABLED_FOR_INVOICES', GETPOSTINT('MV3MAIL_ENABLED_FOR_INVOICES') ? 1 : 0, 'yesno', 0, '', $conf->entity);
    dolibarr_set_const($db, 'MV3MAIL_SUMUP_ENABLED', GETPOSTINT('MV3MAIL_SUMUP_ENABLED') ? 1 : 0, 'yesno', 0, '', $conf->entity);
    $newApiKey = GETPOST('MV3MAIL_SUMUP_API_KEY', 'alphanohtml');
    if ($newApiKey !== '') dolibarr_set_const($db, 'MV3MAIL_SUMUP_API_KEY', $newApiKey, 'chaine', 0, '', 0);
    setEventMessages($langs->trans('SetupSaved'), null, 'mesgs');
}

llxHeader('', 'Mirnes Mail');
print load_fiche_titre('Mirnes Mail - Configuration', '', 'email');
print '<div class="opacitymedium" style="margin-bottom:16px">Module développé par <a href="https://mirnes.ch" target="_blank" rel="noopener">mirnes.ch</a> — modèles professionnels pour factures, commandes et devis.</div>';
print '<form method="POST" action="'.$_SERVER['PHP_SELF'].'">';
print '<input type="hidden" name="token" value="'.newToken().'">';
print '<input type="hidden" name="action" value="save">';
print '<table class="noborder centpercent">';
print '<tr class="liste_titre"><td>Paramètre</td><td>Valeur</td></tr>';
$fields = array(
 'MV3MAIL_QR_BASE_URL' => 'URL du générateur QR', 'MV3MAIL_BANK_NAME' => 'Banque',
 'MV3MAIL_IBAN' => 'IBAN', 'MV3MAIL_PHONE' => 'Téléphone', 'MV3MAIL_EMAIL' => 'E-mail',
 'MV3MAIL_PREVIEW_HEIGHT' => 'Hauteur de l’aperçu (px)'
);
print '<tr class="oddeven"><td>Activer sur les factures clients</td><td><input type="checkbox" name="MV3MAIL_ENABLED_FOR_INVOICES" value="1"'.(getDolGlobalInt('MV3MAIL_ENABLED_FOR_INVOICES', 1) ? ' checked' : '').'></td></tr>';
foreach ($fields as $key => $label) print '<tr class="oddeven"><td>'.$label.'</td><td><input class="minwidth500" type="text" name="'.$key.'" value="'.dol_escape_htmltag(getDolGlobalString($key)).'"></td></tr>';
print '<tr class="liste_titre"><td colspan="2">Texte ajouté aux e-mails</td></tr>';
print '<tr class="oddeven"><td>Note personnalisée<br><span class="opacitymedium">Facultative — ajoutée automatiquement aux factures, commandes et devis</span></td><td><textarea class="quatrevingtpercent" name="MV3MAIL_CUSTOM_NOTE" rows="6" placeholder="Exemple : Merci de rappeler la référence du document lors de votre paiement.">'.dol_escape_htmltag(getDolGlobalString('MV3MAIL_CUSTOM_NOTE')).'</textarea></td></tr>';
print '<tr class="liste_titre"><td colspan="2">Paiement en ligne SumUp</td></tr>';
print '<tr class="oddeven"><td>Activer le paiement par carte</td><td><input type="checkbox" name="MV3MAIL_SUMUP_ENABLED" value="1"'.(getDolGlobalInt('MV3MAIL_SUMUP_ENABLED') ? ' checked' : '').'></td></tr>';
print '<tr class="oddeven"><td>Code marchand SumUp</td><td><input class="minwidth500" type="text" name="MV3MAIL_SUMUP_MERCHANT_CODE" value="'.dol_escape_htmltag(getDolGlobalString('MV3MAIL_SUMUP_MERCHANT_CODE')).'" placeholder="MCXXXXXX"></td></tr>';
print '<tr class="oddeven"><td>Clé API SumUp</td><td><input class="minwidth500" type="password" autocomplete="new-password" name="MV3MAIL_SUMUP_API_KEY" value="" placeholder="'.(getDolGlobalString('MV3MAIL_SUMUP_API_KEY') !== '' ? 'Clé déjà enregistrée — laisser vide pour conserver' : 'sup_sk_…').'"></td></tr>';
print '</table><div class="center"><button class="button button-save" type="submit">'.$langs->trans('Save').'</button></div></form>';
llxFooter();
$db->close();
