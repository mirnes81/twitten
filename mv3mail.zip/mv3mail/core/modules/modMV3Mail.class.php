<?php
include_once DOL_DOCUMENT_ROOT.'/core/modules/DolibarrModules.class.php';
include_once DOL_DOCUMENT_ROOT.'/core/lib/admin.lib.php';

class modMV3Mail extends DolibarrModules
{
    public function __construct($db)
    {
        global $conf;
        $this->db = $db;
        $this->numero = 719340;
        $this->rights_class = 'mv3mail';
        $this->family = 'technic';
        $this->module_position = '90';
        $this->name = 'MirnesMail';
        $this->description = 'Modèles d’e-mails professionnels pour factures, commandes et devis';
		$this->version = '2.4.0';
        $this->const_name = 'MAIN_MODULE_MV3MAIL';
        $this->picto = 'email';
        $this->editor_name = 'mirnes.ch';
        $this->editor_url = 'https://mirnes.ch';
        $this->module_parts = array(
            'triggers' => 0,
            'hooks' => array('data' => array('formmail', 'invoicecard', 'ordercard', 'propalcard', 'globalcard'), 'entity' => '0'),
            'css' => array('/mv3mail/css/mv3mail.css.php'),
            'js' => array('/mv3mail/js/mv3mail.js.php'),
            'moduleforexternal' => 1
        );
        $this->dirs = array('/mv3mail/temp');
        $this->config_page_url = array('setup.php@mv3mail');
        $this->depends = array('modFacture');
        $this->langfiles = array('mv3mail@mv3mail');
        $this->phpmin = array(7, 4);
        $this->need_dolibarr_version = array(20, 0);
        $this->const = array(
            1 => array('MV3MAIL_ENABLED_FOR_INVOICES', 'yesno', '1', 'Activer le modèle MV3 pour les factures clients', 1, 'current', 1),
            2 => array('MV3MAIL_QR_BASE_URL', 'chaine', 'https://crm.mv-3pro.ch/custom/swissbanking/qr_email.php', 'URL du générateur QR', 1, 'current', 1),
            3 => array('MV3MAIL_BANK_NAME', 'chaine', 'UBS - Morges', 'Nom de la banque', 1, 'current', 1),
            4 => array('MV3MAIL_IBAN', 'chaine', 'CH29 3000 5204 2882 5201 N', 'IBAN', 1, 'current', 1),
            5 => array('MV3MAIL_PHONE', 'chaine', '+41 21 559 84 73', 'Téléphone', 1, 'current', 1),
            6 => array('MV3MAIL_EMAIL', 'chaine', 'info@mv-3pro.ch', 'Adresse e-mail', 1, 'current', 1),
            7 => array('MV3MAIL_PREVIEW_HEIGHT', 'chaine', '760', 'Hauteur de l’aperçu en pixels', 1, 'current', 1),
            8 => array('MV3MAIL_SUMUP_ENABLED', 'yesno', '0', 'Activer le paiement SumUp', 1, 'current', 1),
            9 => array('MV3MAIL_SUMUP_API_KEY', 'chaine', '', 'Clé API SumUp', 0, 'current', 1),
            10 => array('MV3MAIL_SUMUP_MERCHANT_CODE', 'chaine', '', 'Code marchand SumUp', 0, 'current', 1),
            11 => array('MV3MAIL_CUSTOM_NOTE', 'chaine', '', 'Note personnalisée ajoutée aux e-mails', 0, 'current', 1)
        );
        $this->rights = array();
        $this->menu = array();
    }

    public function init($options = '')
    {
        if (function_exists('opcache_invalidate')) {
            @opcache_invalidate(__DIR__.'/../../class/actions_mv3mail.class.php', true);
            @opcache_invalidate(__DIR__.'/../../lib/mv3mail.lib.php', true);
            @opcache_invalidate(__DIR__.'/../../portal.php', true);
        }
        $sql = array();
        $result = $this->_init($sql, $options);
        if ($result > 0 && getDolGlobalString('MV3MAIL_PORTAL_SECRET') === '') {
            try { $secret = bin2hex(random_bytes(32)); }
            catch (Exception $e) { $secret = hash('sha256', uniqid('mv3mail', true).microtime(true)); }
            dolibarr_set_const($this->db, 'MV3MAIL_PORTAL_SECRET', $secret, 'chaine', 0, '', 0);
        }
        return $result;
    }

    public function remove($options = '')
    {
        $sql = array();
        return $this->_remove($sql, $options);
    }
}
